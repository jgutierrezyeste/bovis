#GLPI Dump database on 2018-05-21 09:11

### Dump table glpi_alerts

DROP TABLE IF EXISTS `glpi_alerts`;
CREATE TABLE `glpi_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php ALERT_* constant',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`type`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_apiclients

DROP TABLE IF EXISTS `glpi_apiclients`;
CREATE TABLE `glpi_apiclients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `ipv4_range_start` bigint(20) DEFAULT NULL,
  `ipv4_range_end` bigint(20) DEFAULT NULL,
  `ipv6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token_date` datetime DEFAULT NULL,
  `dolog_method` tinyint(4) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_apiclients` VALUES ('1','0','1','full access from localhost',NULL,'1','2130706433','2130706433','::1','',NULL,'0',NULL);

### Dump table glpi_authldapreplicates

DROP TABLE IF EXISTS `glpi_authldapreplicates`;
CREATE TABLE `glpi_authldapreplicates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authldaps_id` (`authldaps_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authldaps

DROP TABLE IF EXISTS `glpi_authldaps`;
CREATE TABLE `glpi_authldaps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rootdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `condition` text COLLATE utf8_unicode_ci,
  `login_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid',
  `sync_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_tls` tinyint(1) NOT NULL DEFAULT '0',
  `group_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_condition` text COLLATE utf8_unicode_ci,
  `group_search_type` int(11) NOT NULL DEFAULT '0',
  `group_member_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email1_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_dn` tinyint(1) NOT NULL DEFAULT '1',
  `time_offset` int(11) NOT NULL DEFAULT '0' COMMENT 'in seconds',
  `deref_option` int(11) NOT NULL DEFAULT '0',
  `title_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_condition` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `rootdn_passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email3_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email4_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagesize` int(11) NOT NULL DEFAULT '0',
  `ldap_maxlimit` int(11) NOT NULL DEFAULT '0',
  `can_support_pagesize` tinyint(1) NOT NULL DEFAULT '0',
  `picture_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_default` (`is_default`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`),
  KEY `sync_field` (`sync_field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authmails

DROP TABLE IF EXISTS `glpi_authmails`;
CREATE TABLE `glpi_authmails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `connect_string` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_autoupdatesystems

DROP TABLE IF EXISTS `glpi_autoupdatesystems`;
CREATE TABLE `glpi_autoupdatesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklistedmailcontents

DROP TABLE IF EXISTS `glpi_blacklistedmailcontents`;
CREATE TABLE `glpi_blacklistedmailcontents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklists

DROP TABLE IF EXISTS `glpi_blacklists`;
CREATE TABLE `glpi_blacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_blacklists` VALUES ('1','1','empty IP','',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('2','1','localhost','127.0.0.1',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('3','1','zero IP','0.0.0.0',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('4','2','empty MAC','',NULL,NULL,NULL);

### Dump table glpi_budgets

DROP TABLE IF EXISTS `glpi_budgets`;
CREATE TABLE `glpi_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `budgettypes_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `is_template` (`is_template`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `locations_id` (`locations_id`),
  KEY `budgettypes_id` (`budgettypes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_budgettypes

DROP TABLE IF EXISTS `glpi_budgettypes`;
CREATE TABLE `glpi_budgettypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_businesscriticities

DROP TABLE IF EXISTS `glpi_businesscriticities`;
CREATE TABLE `glpi_businesscriticities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `businesscriticities_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`businesscriticities_id`,`name`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendars

DROP TABLE IF EXISTS `glpi_calendars`;
CREATE TABLE `glpi_calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `cache_duration` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendars` VALUES ('1','Default','0','1','Default calendar',NULL,'[0,43200,43200,43200,43200,43200,0]',NULL);

### Dump table glpi_calendars_holidays

DROP TABLE IF EXISTS `glpi_calendars_holidays`;
CREATE TABLE `glpi_calendars_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `holidays_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`calendars_id`,`holidays_id`),
  KEY `holidays_id` (`holidays_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendarsegments

DROP TABLE IF EXISTS `glpi_calendarsegments`;
CREATE TABLE `glpi_calendarsegments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `day` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'numer of the day based on date(w)',
  `begin` time DEFAULT NULL,
  `end` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendars_id` (`calendars_id`),
  KEY `day` (`day`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendarsegments` VALUES ('1','1','0','0','1','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('2','1','0','0','2','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('3','1','0','0','3','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('4','1','0','0','4','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('5','1','0','0','5','08:00:00','20:00:00');

### Dump table glpi_cartridgeitems

DROP TABLE IF EXISTS `glpi_cartridgeitems`;
CREATE TABLE `glpi_cartridgeitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `cartridgeitemtypes_id` (`cartridgeitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitems_printermodels

DROP TABLE IF EXISTS `glpi_cartridgeitems_printermodels`;
CREATE TABLE `glpi_cartridgeitems_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`printermodels_id`,`cartridgeitems_id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitemtypes

DROP TABLE IF EXISTS `glpi_cartridgeitemtypes`;
CREATE TABLE `glpi_cartridgeitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridges

DROP TABLE IF EXISTS `glpi_cartridges`;
CREATE TABLE `glpi_cartridges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printers_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_use` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `pages` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`),
  KEY `printers_id` (`printers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_certificates

DROP TABLE IF EXISTS `glpi_certificates`;
CREATE TABLE `glpi_certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `certificatetypes_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_certificatetypes (id)',
  `dns_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dns_suffix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_users (id)',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_groups (id)',
  `locations_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_locations (id)',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to glpi_manufacturers (id)',
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_autosign` tinyint(1) NOT NULL DEFAULT '0',
  `date_expiration` date DEFAULT NULL,
  `states_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to states (id)',
  `command` text COLLATE utf8_unicode_ci,
  `certificate_request` text COLLATE utf8_unicode_ci,
  `certificate_item` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_template` (`is_template`),
  KEY `is_deleted` (`is_deleted`),
  KEY `certificatetypes_id` (`certificatetypes_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `states_id` (`states_id`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_certificates_items

DROP TABLE IF EXISTS `glpi_certificates_items`;
CREATE TABLE `glpi_certificates_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `certificates_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various tables, according to itemtype (id)',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'see .class.php file',
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`certificates_id`,`itemtype`,`items_id`),
  KEY `device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_certificatetypes

DROP TABLE IF EXISTS `glpi_certificatetypes`;
CREATE TABLE `glpi_certificatetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changecosts

DROP TABLE IF EXISTS `glpi_changecosts`;
CREATE TABLE `glpi_changecosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `changes_id` (`changes_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes

DROP TABLE IF EXISTS `glpi_changes`;
CREATE TABLE `glpi_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `time_to_resolve` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `controlistcontent` longtext COLLATE utf8_unicode_ci,
  `rolloutplancontent` longtext COLLATE utf8_unicode_ci,
  `backoutplancontent` longtext COLLATE utf8_unicode_ci,
  `checklistcontent` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `time_to_resolve` (`time_to_resolve`),
  KEY `global_validation` (`global_validation`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_groups

DROP TABLE IF EXISTS `glpi_changes_groups`;
CREATE TABLE `glpi_changes_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_items

DROP TABLE IF EXISTS `glpi_changes_items`;
CREATE TABLE `glpi_changes_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_problems

DROP TABLE IF EXISTS `glpi_changes_problems`;
CREATE TABLE `glpi_changes_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `problems_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`problems_id`),
  KEY `problems_id` (`problems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_projects

DROP TABLE IF EXISTS `glpi_changes_projects`;
CREATE TABLE `glpi_changes_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`projects_id`),
  KEY `projects_id` (`projects_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_suppliers

DROP TABLE IF EXISTS `glpi_changes_suppliers`;
CREATE TABLE `glpi_changes_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_tickets

DROP TABLE IF EXISTS `glpi_changes_tickets`;
CREATE TABLE `glpi_changes_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_users

DROP TABLE IF EXISTS `glpi_changes_users`;
CREATE TABLE `glpi_changes_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changetasks

DROP TABLE IF EXISTS `glpi_changetasks`;
CREATE TABLE `glpi_changetasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `tasktemplates_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `changes_id` (`changes_id`),
  KEY `state` (`state`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `tasktemplates_id` (`tasktemplates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changevalidations

DROP TABLE IF EXISTS `glpi_changevalidations`;
CREATE TABLE `glpi_changevalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `changes_id` (`changes_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerantiviruses

DROP TABLE IF EXISTS `glpi_computerantiviruses`;
CREATE TABLE `glpi_computerantiviruses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `antivirus_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signature_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_uptodate` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_expiration` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `antivirus_version` (`antivirus_version`),
  KEY `signature_version` (`signature_version`),
  KEY `is_active` (`is_active`),
  KEY `is_uptodate` (`is_uptodate`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `is_deleted` (`is_deleted`),
  KEY `computers_id` (`computers_id`),
  KEY `date_expiration` (`date_expiration`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerdisks

DROP TABLE IF EXISTS `glpi_computerdisks`;
CREATE TABLE `glpi_computerdisks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mountpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesystems_id` int(11) NOT NULL DEFAULT '0',
  `totalsize` int(11) NOT NULL DEFAULT '0',
  `freesize` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `device` (`device`),
  KEY `mountpoint` (`mountpoint`),
  KEY `totalsize` (`totalsize`),
  KEY `freesize` (`freesize`),
  KEY `computers_id` (`computers_id`),
  KEY `filesystems_id` (`filesystems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computermodels

DROP TABLE IF EXISTS `glpi_computermodels`;
CREATE TABLE `glpi_computermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers

DROP TABLE IF EXISTS `glpi_computers`;
CREATE TABLE `glpi_computers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `autoupdatesystems_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `computermodels_id` int(11) NOT NULL DEFAULT '0',
  `computertypes_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `computermodels_id` (`computermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `computertypes_id` (`computertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `uuid` (`uuid`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_items

DROP TABLE IF EXISTS `glpi_computers_items`;
CREATE TABLE `glpi_computers_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to itemtype (ID)',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwarelicenses

DROP TABLE IF EXISTS `glpi_computers_softwarelicenses`;
CREATE TABLE `glpi_computers_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwarelicenses_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwarelicenses_id`),
  KEY `computers_id` (`computers_id`),
  KEY `softwarelicenses_id` (`softwarelicenses_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwareversions

DROP TABLE IF EXISTS `glpi_computers_softwareversions`;
CREATE TABLE `glpi_computers_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted_computer` tinyint(1) NOT NULL DEFAULT '0',
  `is_template_computer` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_install` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwareversions_id`),
  KEY `softwareversions_id` (`softwareversions_id`),
  KEY `computers_info` (`entities_id`,`is_template_computer`,`is_deleted_computer`),
  KEY `is_template` (`is_template_computer`),
  KEY `is_deleted` (`is_deleted_computer`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_install` (`date_install`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computertypes

DROP TABLE IF EXISTS `glpi_computertypes`;
CREATE TABLE `glpi_computertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computervirtualmachines

DROP TABLE IF EXISTS `glpi_computervirtualmachines`;
CREATE TABLE `glpi_computervirtualmachines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `virtualmachinestates_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinesystems_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinetypes_id` int(11) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vcpu` int(11) NOT NULL DEFAULT '0',
  `ram` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `virtualmachinestates_id` (`virtualmachinestates_id`),
  KEY `virtualmachinesystems_id` (`virtualmachinesystems_id`),
  KEY `vcpu` (`vcpu`),
  KEY `ram` (`ram`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `uuid` (`uuid`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_configs

DROP TABLE IF EXISTS `glpi_configs`;
CREATE TABLE `glpi_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `context` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`context`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_configs` VALUES ('1','core','version','9.2.2');
INSERT INTO `glpi_configs` VALUES ('2','core','show_jobs_at_login','0');
INSERT INTO `glpi_configs` VALUES ('3','core','cut','250');
INSERT INTO `glpi_configs` VALUES ('4','core','list_limit','15');
INSERT INTO `glpi_configs` VALUES ('5','core','list_limit_max','50');
INSERT INTO `glpi_configs` VALUES ('6','core','url_maxlength','30');
INSERT INTO `glpi_configs` VALUES ('7','core','event_loglevel','5');
INSERT INTO `glpi_configs` VALUES ('8','core','notifications_mailing','0');
INSERT INTO `glpi_configs` VALUES ('9','core','admin_email','admsys@localhost');
INSERT INTO `glpi_configs` VALUES ('10','core','admin_email_name','');
INSERT INTO `glpi_configs` VALUES ('11','core','admin_reply','');
INSERT INTO `glpi_configs` VALUES ('12','core','admin_reply_name','');
INSERT INTO `glpi_configs` VALUES ('13','core','mailing_signature','SIGNATURE');
INSERT INTO `glpi_configs` VALUES ('14','core','use_anonymous_helpdesk','0');
INSERT INTO `glpi_configs` VALUES ('15','core','use_anonymous_followups','0');
INSERT INTO `glpi_configs` VALUES ('16','core','language','es_ES');
INSERT INTO `glpi_configs` VALUES ('17','core','priority_1','#fff2f2');
INSERT INTO `glpi_configs` VALUES ('18','core','priority_2','#ffe0e0');
INSERT INTO `glpi_configs` VALUES ('19','core','priority_3','#ffcece');
INSERT INTO `glpi_configs` VALUES ('20','core','priority_4','#ffbfbf');
INSERT INTO `glpi_configs` VALUES ('21','core','priority_5','#ffadad');
INSERT INTO `glpi_configs` VALUES ('22','core','priority_6','#ff5555');
INSERT INTO `glpi_configs` VALUES ('23','core','date_tax','2005-12-31');
INSERT INTO `glpi_configs` VALUES ('24','core','cas_host','');
INSERT INTO `glpi_configs` VALUES ('25','core','cas_port','443');
INSERT INTO `glpi_configs` VALUES ('26','core','cas_uri','');
INSERT INTO `glpi_configs` VALUES ('27','core','cas_logout','');
INSERT INTO `glpi_configs` VALUES ('28','core','existing_auth_server_field_clean_domain','0');
INSERT INTO `glpi_configs` VALUES ('29','core','planning_begin','08:00:00');
INSERT INTO `glpi_configs` VALUES ('30','core','planning_end','20:00:00');
INSERT INTO `glpi_configs` VALUES ('31','core','utf8_conv','1');
INSERT INTO `glpi_configs` VALUES ('32','core','use_public_faq','0');
INSERT INTO `glpi_configs` VALUES ('33','core','url_base','http://192.168.0.169/Bovis/glpiBovis');
INSERT INTO `glpi_configs` VALUES ('34','core','show_link_in_mail','0');
INSERT INTO `glpi_configs` VALUES ('35','core','text_login','');
INSERT INTO `glpi_configs` VALUES ('36','core','founded_new_version','');
INSERT INTO `glpi_configs` VALUES ('37','core','dropdown_max','100');
INSERT INTO `glpi_configs` VALUES ('38','core','ajax_wildcard','*');
INSERT INTO `glpi_configs` VALUES ('42','core','ajax_limit_count','10');
INSERT INTO `glpi_configs` VALUES ('43','core','use_ajax_autocompletion','1');
INSERT INTO `glpi_configs` VALUES ('44','core','is_users_auto_add','1');
INSERT INTO `glpi_configs` VALUES ('45','core','date_format','0');
INSERT INTO `glpi_configs` VALUES ('46','core','number_format','0');
INSERT INTO `glpi_configs` VALUES ('47','core','csv_delimiter',';');
INSERT INTO `glpi_configs` VALUES ('48','core','is_ids_visible','0');
INSERT INTO `glpi_configs` VALUES ('50','core','smtp_mode','0');
INSERT INTO `glpi_configs` VALUES ('51','core','smtp_host','');
INSERT INTO `glpi_configs` VALUES ('52','core','smtp_port','25');
INSERT INTO `glpi_configs` VALUES ('53','core','smtp_username','');
INSERT INTO `glpi_configs` VALUES ('54','core','proxy_name','');
INSERT INTO `glpi_configs` VALUES ('55','core','proxy_port','8080');
INSERT INTO `glpi_configs` VALUES ('56','core','proxy_user','');
INSERT INTO `glpi_configs` VALUES ('57','core','add_followup_on_update_ticket','1');
INSERT INTO `glpi_configs` VALUES ('58','core','keep_tickets_on_delete','0');
INSERT INTO `glpi_configs` VALUES ('59','core','time_step','5');
INSERT INTO `glpi_configs` VALUES ('60','core','decimal_number','2');
INSERT INTO `glpi_configs` VALUES ('61','core','helpdesk_doc_url','');
INSERT INTO `glpi_configs` VALUES ('62','core','central_doc_url','');
INSERT INTO `glpi_configs` VALUES ('63','core','documentcategories_id_forticket','0');
INSERT INTO `glpi_configs` VALUES ('64','core','monitors_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('65','core','phones_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('66','core','peripherals_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('67','core','printers_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('68','core','use_log_in_files','1');
INSERT INTO `glpi_configs` VALUES ('69','core','time_offset','0');
INSERT INTO `glpi_configs` VALUES ('70','core','is_contact_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('71','core','is_user_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('72','core','is_group_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('73','core','is_location_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('74','core','state_autoupdate_mode','0');
INSERT INTO `glpi_configs` VALUES ('75','core','is_contact_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('76','core','is_user_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('77','core','is_group_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('78','core','is_location_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('79','core','state_autoclean_mode','0');
INSERT INTO `glpi_configs` VALUES ('80','core','use_flat_dropdowntree','0');
INSERT INTO `glpi_configs` VALUES ('81','core','use_autoname_by_entity','1');
INSERT INTO `glpi_configs` VALUES ('84','core','softwarecategories_id_ondelete','1');
INSERT INTO `glpi_configs` VALUES ('85','core','x509_email_field','');
INSERT INTO `glpi_configs` VALUES ('86','core','x509_cn_restrict','');
INSERT INTO `glpi_configs` VALUES ('87','core','x509_o_restrict','');
INSERT INTO `glpi_configs` VALUES ('88','core','x509_ou_restrict','');
INSERT INTO `glpi_configs` VALUES ('89','core','default_mailcollector_filesize_max','2097152');
INSERT INTO `glpi_configs` VALUES ('90','core','followup_private','0');
INSERT INTO `glpi_configs` VALUES ('91','core','task_private','0');
INSERT INTO `glpi_configs` VALUES ('92','core','default_software_helpdesk_visible','1');
INSERT INTO `glpi_configs` VALUES ('93','core','names_format','0');
INSERT INTO `glpi_configs` VALUES ('95','core','default_requesttypes_id','1');
INSERT INTO `glpi_configs` VALUES ('96','core','use_noright_users_add','1');
INSERT INTO `glpi_configs` VALUES ('97','core','cron_limit','5');
INSERT INTO `glpi_configs` VALUES ('98','core','priority_matrix','{\"1\":{\"1\":1,\"2\":1,\"3\":2,\"4\":2,\"5\":2},\"2\":{\"1\":1,\"2\":2,\"3\":2,\"4\":3,\"5\":3},\"3\":{\"1\":2,\"2\":2,\"3\":3,\"4\":4,\"5\":4},\"4\":{\"1\":2,\"2\":3,\"3\":4,\"4\":4,\"5\":5},\"5\":{\"1\":2,\"2\":3,\"3\":4,\"4\":5,\"5\":5}}');
INSERT INTO `glpi_configs` VALUES ('99','core','urgency_mask','62');
INSERT INTO `glpi_configs` VALUES ('100','core','impact_mask','62');
INSERT INTO `glpi_configs` VALUES ('101','core','user_deleted_ldap','0');
INSERT INTO `glpi_configs` VALUES ('102','core','auto_create_infocoms','0');
INSERT INTO `glpi_configs` VALUES ('103','core','use_slave_for_search','0');
INSERT INTO `glpi_configs` VALUES ('104','core','proxy_passwd','');
INSERT INTO `glpi_configs` VALUES ('105','core','smtp_passwd','');
INSERT INTO `glpi_configs` VALUES ('106','core','transfers_id_auto','0');
INSERT INTO `glpi_configs` VALUES ('107','core','show_count_on_tabs','1');
INSERT INTO `glpi_configs` VALUES ('108','core','refresh_ticket_list','0');
INSERT INTO `glpi_configs` VALUES ('109','core','set_default_tech','1');
INSERT INTO `glpi_configs` VALUES ('110','core','allow_search_view','2');
INSERT INTO `glpi_configs` VALUES ('111','core','allow_search_all','0');
INSERT INTO `glpi_configs` VALUES ('112','core','allow_search_global','1');
INSERT INTO `glpi_configs` VALUES ('113','core','display_count_on_home','5');
INSERT INTO `glpi_configs` VALUES ('114','core','use_password_security','0');
INSERT INTO `glpi_configs` VALUES ('115','core','password_min_length','8');
INSERT INTO `glpi_configs` VALUES ('116','core','password_need_number','1');
INSERT INTO `glpi_configs` VALUES ('117','core','password_need_letter','1');
INSERT INTO `glpi_configs` VALUES ('118','core','password_need_caps','1');
INSERT INTO `glpi_configs` VALUES ('119','core','password_need_symbol','1');
INSERT INTO `glpi_configs` VALUES ('120','core','use_check_pref','0');
INSERT INTO `glpi_configs` VALUES ('121','core','notification_to_myself','1');
INSERT INTO `glpi_configs` VALUES ('122','core','duedateok_color','#06ff00');
INSERT INTO `glpi_configs` VALUES ('123','core','duedatewarning_color','#ffb800');
INSERT INTO `glpi_configs` VALUES ('124','core','duedatecritical_color','#ff0000');
INSERT INTO `glpi_configs` VALUES ('125','core','duedatewarning_less','20');
INSERT INTO `glpi_configs` VALUES ('126','core','duedatecritical_less','5');
INSERT INTO `glpi_configs` VALUES ('127','core','duedatewarning_unit','%');
INSERT INTO `glpi_configs` VALUES ('128','core','duedatecritical_unit','%');
INSERT INTO `glpi_configs` VALUES ('129','core','realname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('130','core','firstname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('131','core','email1_ssofield','');
INSERT INTO `glpi_configs` VALUES ('132','core','email2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('133','core','email3_ssofield','');
INSERT INTO `glpi_configs` VALUES ('134','core','email4_ssofield','');
INSERT INTO `glpi_configs` VALUES ('135','core','phone_ssofield','');
INSERT INTO `glpi_configs` VALUES ('136','core','phone2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('137','core','mobile_ssofield','');
INSERT INTO `glpi_configs` VALUES ('138','core','comment_ssofield','');
INSERT INTO `glpi_configs` VALUES ('139','core','title_ssofield','');
INSERT INTO `glpi_configs` VALUES ('140','core','category_ssofield','');
INSERT INTO `glpi_configs` VALUES ('141','core','language_ssofield','');
INSERT INTO `glpi_configs` VALUES ('142','core','entity_ssofield','');
INSERT INTO `glpi_configs` VALUES ('143','core','registration_number_ssofield','');
INSERT INTO `glpi_configs` VALUES ('144','core','ssovariables_id','0');
INSERT INTO `glpi_configs` VALUES ('145','core','translate_kb','0');
INSERT INTO `glpi_configs` VALUES ('146','core','translate_dropdowns','0');
INSERT INTO `glpi_configs` VALUES ('147','core','pdffont','helvetica');
INSERT INTO `glpi_configs` VALUES ('148','core','keep_devices_when_purging_item','0');
INSERT INTO `glpi_configs` VALUES ('149','core','maintenance_mode','0');
INSERT INTO `glpi_configs` VALUES ('150','core','maintenance_text','');
INSERT INTO `glpi_configs` VALUES ('151','core','use_rich_text','0');
INSERT INTO `glpi_configs` VALUES ('152','core','attach_ticket_documents_to_mail','0');
INSERT INTO `glpi_configs` VALUES ('153','core','backcreated','0');
INSERT INTO `glpi_configs` VALUES ('154','core','task_state','1');
INSERT INTO `glpi_configs` VALUES ('155','core','layout','lefttab');
INSERT INTO `glpi_configs` VALUES ('156','core','ticket_timeline','1');
INSERT INTO `glpi_configs` VALUES ('157','core','ticket_timeline_keep_replaced_tabs','0');
INSERT INTO `glpi_configs` VALUES ('158','core','palette','auror');
INSERT INTO `glpi_configs` VALUES ('159','core','lock_use_lock_item','0');
INSERT INTO `glpi_configs` VALUES ('160','core','lock_autolock_mode','1');
INSERT INTO `glpi_configs` VALUES ('161','core','lock_directunlock_notification','0');
INSERT INTO `glpi_configs` VALUES ('162','core','lock_item_list','[]');
INSERT INTO `glpi_configs` VALUES ('163','core','lock_lockprofile_id','8');
INSERT INTO `glpi_configs` VALUES ('164','core','set_default_requester','1');
INSERT INTO `glpi_configs` VALUES ('165','core','highcontrast_css','0');
INSERT INTO `glpi_configs` VALUES ('166','core','smtp_check_certificate','1');
INSERT INTO `glpi_configs` VALUES ('167','core','enable_api','0');
INSERT INTO `glpi_configs` VALUES ('168','core','enable_api_login_credentials','0');
INSERT INTO `glpi_configs` VALUES ('169','core','enable_api_login_external_token','1');
INSERT INTO `glpi_configs` VALUES ('170','core','url_base_api','http://192.168.0.169/Bovis/glpiBovis/apirest.php/');
INSERT INTO `glpi_configs` VALUES ('171','core','login_remember_time','604800');
INSERT INTO `glpi_configs` VALUES ('172','core','login_remember_default','1');
INSERT INTO `glpi_configs` VALUES ('173','core','use_notifications','0');
INSERT INTO `glpi_configs` VALUES ('174','core','notifications_ajax','0');
INSERT INTO `glpi_configs` VALUES ('175','core','notifications_ajax_check_interval','5');
INSERT INTO `glpi_configs` VALUES ('176','core','notifications_ajax_sound',NULL);
INSERT INTO `glpi_configs` VALUES ('177','core','notifications_ajax_icon_url','/pics/glpi.png');
INSERT INTO `glpi_configs` VALUES ('178','core','dbversion','9.2.2');
INSERT INTO `glpi_configs` VALUES ('179','core','smtp_max_retries','5');
INSERT INTO `glpi_configs` VALUES ('180','core','smtp_sender',NULL);
INSERT INTO `glpi_configs` VALUES ('181','core','from_email',NULL);
INSERT INTO `glpi_configs` VALUES ('182','core','from_email_name',NULL);
INSERT INTO `glpi_configs` VALUES ('183','core','instance_uuid','grlrWJe7yCiArUYFivVR3UGZVxXu1yamhLROAwz3');
INSERT INTO `glpi_configs` VALUES ('184','core','registration_uuid','zYWFjipx67gNYt8fDMg2byMSssaBjaBuppOAcpII');
INSERT INTO `glpi_configs` VALUES ('185','core','smtp_retry_time','5');

### Dump table glpi_consumableitems

DROP TABLE IF EXISTS `glpi_consumableitems`;
CREATE TABLE `glpi_consumableitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `consumableitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `consumableitemtypes_id` (`consumableitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumableitemtypes

DROP TABLE IF EXISTS `glpi_consumableitemtypes`;
CREATE TABLE `glpi_consumableitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumables

DROP TABLE IF EXISTS `glpi_consumables`;
CREATE TABLE `glpi_consumables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `consumableitems_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_in` (`date_in`),
  KEY `date_out` (`date_out`),
  KEY `consumableitems_id` (`consumableitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts

DROP TABLE IF EXISTS `glpi_contacts`;
CREATE TABLE `glpi_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacttypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `contacttypes_id` (`contacttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts_suppliers

DROP TABLE IF EXISTS `glpi_contacts_suppliers`;
CREATE TABLE `glpi_contacts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contacts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contacts_id`),
  KEY `contacts_id` (`contacts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacttypes

DROP TABLE IF EXISTS `glpi_contacttypes`;
CREATE TABLE `glpi_contacttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contractcosts

DROP TABLE IF EXISTS `glpi_contractcosts`;
CREATE TABLE `glpi_contractcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `contracts_id` (`contracts_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts

DROP TABLE IF EXISTS `glpi_contracts`;
CREATE TABLE `glpi_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttypes_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `notice` int(11) NOT NULL DEFAULT '0',
  `periodicity` int(11) NOT NULL DEFAULT '0',
  `billing` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `accounting_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `week_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `week_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_saturday` tinyint(1) NOT NULL DEFAULT '0',
  `monday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `monday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_monday` tinyint(1) NOT NULL DEFAULT '0',
  `max_links_allowed` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `renewal` int(11) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `begin_date` (`begin_date`),
  KEY `name` (`name`),
  KEY `contracttypes_id` (`contracttypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `use_monday` (`use_monday`),
  KEY `use_saturday` (`use_saturday`),
  KEY `alert` (`alert`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_items

DROP TABLE IF EXISTS `glpi_contracts_items`;
CREATE TABLE `glpi_contracts_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`contracts_id`,`itemtype`,`items_id`),
  KEY `FK_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_suppliers

DROP TABLE IF EXISTS `glpi_contracts_suppliers`;
CREATE TABLE `glpi_contracts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contracts_id`),
  KEY `contracts_id` (`contracts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracttypes

DROP TABLE IF EXISTS `glpi_contracttypes`;
CREATE TABLE `glpi_contracttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_crontasklogs

DROP TABLE IF EXISTS `glpi_crontasklogs`;
CREATE TABLE `glpi_crontasklogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crontasks_id` int(11) NOT NULL,
  `crontasklogs_id` int(11) NOT NULL COMMENT 'id of ''start'' event',
  `date` datetime NOT NULL,
  `state` int(11) NOT NULL COMMENT '0:start, 1:run, 2:stop',
  `elapsed` float NOT NULL COMMENT 'time elapsed since start',
  `volume` int(11) NOT NULL COMMENT 'for statistics',
  `content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'message',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `crontasks_id` (`crontasks_id`),
  KEY `crontasklogs_id_state` (`crontasklogs_id`,`state`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_crontasklogs` VALUES ('1','18','0','2018-03-22 11:43:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('2','18','1','2018-03-22 11:43:48','2','0.023947','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('3','19','0','2018-03-26 09:30:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('4','19','3','2018-03-26 09:30:01','2','0.0503619','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('5','20','0','2018-04-09 11:44:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('6','20','5','2018-04-09 11:44:20','2','0.105435','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('7','21','0','2018-04-09 11:57:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('8','21','7','2018-04-09 11:57:46','2','0.00461984','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('9','22','0','2018-04-09 11:58:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('10','22','9','2018-04-09 11:58:06','2','0.00422597','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('11','23','0','2018-04-09 12:25:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('12','23','11','2018-04-09 12:25:56','2','0.0202959','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('13','24','0','2018-04-10 08:17:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('14','24','13','2018-04-10 08:17:29','1','0.0181639','1','Limpiar el archivo temporal 1 creado hace más de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('15','24','13','2018-04-10 08:17:29','2','0.0196609','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('16','25','0','2018-04-10 08:22:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('17','25','16','2018-04-10 08:22:43','2','0.003932','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('18','30','0','2018-04-10 08:22:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('19','5','0','2018-04-10 08:34:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('20','5','19','2018-04-10 08:34:30','2','0.00360489','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('21','6','0','2018-04-10 08:44:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('22','6','21','2018-04-10 08:44:39','2','0.00293303','0','Action completed, no processing required');

### Dump table glpi_crontasks

DROP TABLE IF EXISTS `glpi_crontasks`;
CREATE TABLE `glpi_crontasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'task name',
  `frequency` int(11) NOT NULL COMMENT 'second between launch',
  `param` int(11) DEFAULT NULL COMMENT 'task specify parameter',
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '0:disabled, 1:waiting, 2:running',
  `mode` int(11) NOT NULL DEFAULT '1' COMMENT '1:internal, 2:external',
  `allowmode` int(11) NOT NULL DEFAULT '3' COMMENT '1:internal, 2:external, 3:both',
  `hourmin` int(11) NOT NULL DEFAULT '0',
  `hourmax` int(11) NOT NULL DEFAULT '24',
  `logs_lifetime` int(11) NOT NULL DEFAULT '30' COMMENT 'number of days',
  `lastrun` datetime DEFAULT NULL COMMENT 'last run date',
  `lastcode` int(11) DEFAULT NULL COMMENT 'last run return code',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`name`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Task run by internal / external cron.';

INSERT INTO `glpi_crontasks` VALUES ('2','CartridgeItem','cartridge','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('3','ConsumableItem','consumable','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('4','SoftwareLicense','software','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('5','Contract','contract','86400',NULL,'1','1','3','0','24','30','2018-04-10 08:34:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('6','InfoCom','infocom','86400',NULL,'1','1','3','0','24','30','2018-04-10 08:44:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('7','CronTask','logs','86400','30','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('8','CronTask','optimize','604800',NULL,'1','1','3','0','24','30','2011-03-04 11:35:21',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('9','MailCollector','mailgate','600','10','1','1','3','0','24','30','2011-06-28 11:34:37',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('10','DBconnection','checkdbreplicate','300',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('11','CronTask','checkupdate','604800',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('12','CronTask','session','86400',NULL,'1','1','3','0','24','30','2011-08-30 08:22:27',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('13','CronTask','graph','3600',NULL,'1','1','3','0','24','30','2011-12-06 09:48:42',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('14','ReservationItem','reservation','3600',NULL,'1','1','3','0','24','30','2012-04-05 20:31:57',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('15','Ticket','closeticket','43200',NULL,'1','1','3','0','24','30','2014-01-15 14:35:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('16','Ticket','alertnotclosed','43200',NULL,'1','1','3','0','24','30','2014-04-16 15:32:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('17','SlaLevel_Ticket','slaticket','300',NULL,'1','1','3','0','24','30','2014-06-18 08:02:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('18','Ticket','createinquest','86400',NULL,'1','1','3','0','24','30','2018-03-22 11:43:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('19','Crontask','watcher','86400',NULL,'1','1','3','0','24','30','2018-03-26 09:30:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('20','TicketRecurrent','ticketrecurrent','3600',NULL,'1','1','3','0','24','30','2018-04-09 11:44:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('21','PlanningRecall','planningrecall','300',NULL,'1','1','3','0','24','30','2018-04-09 11:57:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('22','QueuedNotification','queuednotification','60','50','1','1','3','0','24','30','2018-04-09 11:58:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('23','QueuedNotification','queuednotificationclean','86400','30','1','1','3','0','24','30','2018-04-09 12:25:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('24','Crontask','temp','3600',NULL,'1','1','3','0','24','30','2018-04-10 08:17:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('25','MailCollector','mailgateerror','86400',NULL,'1','1','3','0','24','30','2018-04-10 08:22:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('26','Crontask','circularlogs','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('27','ObjectLock','unlockobject','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('28','SavedSearch','countAll','604800',NULL,'0','1','3','0','24','10',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('29','SavedSearch_Alert','savedsearchesalerts','86400',NULL,'0','1','3','0','24','10',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('30','Telemetry','telemetry','2592000',NULL,'2','1','3','0','24','10','2018-04-10 08:22:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('31','Certificate','certificate','86400',NULL,'0','1','3','0','24','10',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('32','OlaLevel_Ticket','olaticket','300',NULL,'1','1','3','0','24','30','2014-06-18 08:02:00',NULL,NULL,NULL,NULL);

### Dump table glpi_devicebatteries

DROP TABLE IF EXISTS `glpi_devicebatteries`;
CREATE TABLE `glpi_devicebatteries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `voltage` int(11) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `devicebatterytypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicebatterymodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicebatterymodels_id` (`devicebatterymodels_id`),
  KEY `devicebatterytypes_id` (`devicebatterytypes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicebatterymodels

DROP TABLE IF EXISTS `glpi_devicebatterymodels`;
CREATE TABLE `glpi_devicebatterymodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicebatterytypes

DROP TABLE IF EXISTS `glpi_devicebatterytypes`;
CREATE TABLE `glpi_devicebatterytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecasemodels

DROP TABLE IF EXISTS `glpi_devicecasemodels`;
CREATE TABLE `glpi_devicecasemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecases

DROP TABLE IF EXISTS `glpi_devicecases`;
CREATE TABLE `glpi_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecasetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicecasemodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicecasetypes_id` (`devicecasetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicecasemodels_id` (`devicecasemodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecasetypes

DROP TABLE IF EXISTS `glpi_devicecasetypes`;
CREATE TABLE `glpi_devicecasetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecontrolmodels

DROP TABLE IF EXISTS `glpi_devicecontrolmodels`;
CREATE TABLE `glpi_devicecontrolmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecontrols

DROP TABLE IF EXISTS `glpi_devicecontrols`;
CREATE TABLE `glpi_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_raid` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicecontrolmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicecontrolmodels_id` (`devicecontrolmodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicedrivemodels

DROP TABLE IF EXISTS `glpi_devicedrivemodels`;
CREATE TABLE `glpi_devicedrivemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicedrives

DROP TABLE IF EXISTS `glpi_devicedrives`;
CREATE TABLE `glpi_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_writer` tinyint(1) NOT NULL DEFAULT '1',
  `speed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicedrivemodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicedrivemodels_id` (`devicedrivemodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicefirmwaremodels

DROP TABLE IF EXISTS `glpi_devicefirmwaremodels`;
CREATE TABLE `glpi_devicefirmwaremodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicefirmwares

DROP TABLE IF EXISTS `glpi_devicefirmwares`;
CREATE TABLE `glpi_devicefirmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicefirmwaretypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicefirmwaremodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicefirmwaremodels_id` (`devicefirmwaremodels_id`),
  KEY `devicefirmwaretypes_id` (`devicefirmwaretypes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicefirmwaretypes

DROP TABLE IF EXISTS `glpi_devicefirmwaretypes`;
CREATE TABLE `glpi_devicefirmwaretypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicefirmwaretypes` VALUES ('1','BIOS',NULL,NULL,NULL);
INSERT INTO `glpi_devicefirmwaretypes` VALUES ('2','UEFI',NULL,NULL,NULL);
INSERT INTO `glpi_devicefirmwaretypes` VALUES ('3','Firmware',NULL,NULL,NULL);

### Dump table glpi_devicegenericmodels

DROP TABLE IF EXISTS `glpi_devicegenericmodels`;
CREATE TABLE `glpi_devicegenericmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegenerics

DROP TABLE IF EXISTS `glpi_devicegenerics`;
CREATE TABLE `glpi_devicegenerics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegenerictypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `devicegenericmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicegenerictypes_id` (`devicegenerictypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicegenericmodels_id` (`devicegenericmodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegenerictypes

DROP TABLE IF EXISTS `glpi_devicegenerictypes`;
CREATE TABLE `glpi_devicegenerictypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegraphiccardmodels

DROP TABLE IF EXISTS `glpi_devicegraphiccardmodels`;
CREATE TABLE `glpi_devicegraphiccardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegraphiccards

DROP TABLE IF EXISTS `glpi_devicegraphiccards`;
CREATE TABLE `glpi_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `memory_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicegraphiccardmodels_id` int(11) DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `chipset` (`chipset`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicegraphiccardmodels_id` (`devicegraphiccardmodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceharddrivemodels

DROP TABLE IF EXISTS `glpi_deviceharddrivemodels`;
CREATE TABLE `glpi_deviceharddrivemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceharddrives

DROP TABLE IF EXISTS `glpi_deviceharddrives`;
CREATE TABLE `glpi_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rpm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `capacity_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `deviceharddrivemodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `deviceharddrivemodels_id` (`deviceharddrivemodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememories

DROP TABLE IF EXISTS `glpi_devicememories`;
CREATE TABLE `glpi_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `size_default` int(11) NOT NULL DEFAULT '0',
  `devicememorytypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicememorymodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicememorytypes_id` (`devicememorytypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicememorymodels_id` (`devicememorymodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememorymodels

DROP TABLE IF EXISTS `glpi_devicememorymodels`;
CREATE TABLE `glpi_devicememorymodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememorytypes

DROP TABLE IF EXISTS `glpi_devicememorytypes`;
CREATE TABLE `glpi_devicememorytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicememorytypes` VALUES ('1','EDO',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('2','DDR',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('3','SDRAM',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('4','SDRAM-2',NULL,NULL,NULL);

### Dump table glpi_devicemotherboardmodels

DROP TABLE IF EXISTS `glpi_devicemotherboardmodels`;
CREATE TABLE `glpi_devicemotherboardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicemotherboards

DROP TABLE IF EXISTS `glpi_devicemotherboards`;
CREATE TABLE `glpi_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicemotherboardmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicemotherboardmodels_id` (`devicemotherboardmodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicenetworkcardmodels

DROP TABLE IF EXISTS `glpi_devicenetworkcardmodels`;
CREATE TABLE `glpi_devicenetworkcardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicenetworkcards

DROP TABLE IF EXISTS `glpi_devicenetworkcards`;
CREATE TABLE `glpi_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bandwidth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `mac_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicenetworkcardmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicenetworkcardmodels_id` (`devicenetworkcardmodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepcimodels

DROP TABLE IF EXISTS `glpi_devicepcimodels`;
CREATE TABLE `glpi_devicepcimodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepcis

DROP TABLE IF EXISTS `glpi_devicepcis`;
CREATE TABLE `glpi_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicepcimodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicepcimodels_id` (`devicepcimodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepowersupplies

DROP TABLE IF EXISTS `glpi_devicepowersupplies`;
CREATE TABLE `glpi_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_atx` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicepowersupplymodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicepowersupplymodels_id` (`devicepowersupplymodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepowersupplymodels

DROP TABLE IF EXISTS `glpi_devicepowersupplymodels`;
CREATE TABLE `glpi_devicepowersupplymodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceprocessormodels

DROP TABLE IF EXISTS `glpi_deviceprocessormodels`;
CREATE TABLE `glpi_deviceprocessormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceprocessors

DROP TABLE IF EXISTS `glpi_deviceprocessors`;
CREATE TABLE `glpi_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `frequency_default` int(11) NOT NULL DEFAULT '0',
  `nbcores_default` int(11) DEFAULT NULL,
  `nbthreads_default` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `deviceprocessormodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `deviceprocessormodels_id` (`deviceprocessormodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesensormodels

DROP TABLE IF EXISTS `glpi_devicesensormodels`;
CREATE TABLE `glpi_devicesensormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesensors

DROP TABLE IF EXISTS `glpi_devicesensors`;
CREATE TABLE `glpi_devicesensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesensortypes_id` int(11) NOT NULL DEFAULT '0',
  `devicesensormodels_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicesensortypes_id` (`devicesensortypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesensortypes

DROP TABLE IF EXISTS `glpi_devicesensortypes`;
CREATE TABLE `glpi_devicesensortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesimcards

DROP TABLE IF EXISTS `glpi_devicesimcards`;
CREATE TABLE `glpi_devicesimcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `voltage` int(11) DEFAULT NULL,
  `devicesimcardtypes_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `allow_voip` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `devicesimcardtypes_id` (`devicesimcardtypes_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `manufacturers_id` (`manufacturers_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesimcardtypes

DROP TABLE IF EXISTS `glpi_devicesimcardtypes`;
CREATE TABLE `glpi_devicesimcardtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicesimcardtypes` VALUES ('1','Full SIM',NULL,NULL,NULL);
INSERT INTO `glpi_devicesimcardtypes` VALUES ('2','Mini SIM',NULL,NULL,NULL);
INSERT INTO `glpi_devicesimcardtypes` VALUES ('3','Micro SIM',NULL,NULL,NULL);
INSERT INTO `glpi_devicesimcardtypes` VALUES ('4','Nano SIM',NULL,NULL,NULL);

### Dump table glpi_devicesoundcardmodels

DROP TABLE IF EXISTS `glpi_devicesoundcardmodels`;
CREATE TABLE `glpi_devicesoundcardmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesoundcards

DROP TABLE IF EXISTS `glpi_devicesoundcards`;
CREATE TABLE `glpi_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `devicesoundcardmodels_id` int(11) DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `devicesoundcardmodels_id` (`devicesoundcardmodels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_displaypreferences

DROP TABLE IF EXISTS `glpi_displaypreferences`;
CREATE TABLE `glpi_displaypreferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`,`num`),
  KEY `rank` (`rank`),
  KEY `num` (`num`),
  KEY `itemtype` (`itemtype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_displaypreferences` VALUES ('32','Computer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('34','Computer','45','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('33','Computer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('31','Computer','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('30','Computer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('86','DocumentType','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('49','Monitor','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('50','Monitor','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('51','Monitor','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('52','Monitor','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('44','Printer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('38','NetworkEquipment','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('39','NetworkEquipment','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('45','Printer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('46','Printer','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('63','Software','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('62','Software','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('61','Software','23','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('83','CartridgeItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('82','CartridgeItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('57','Peripheral','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('56','Peripheral','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('55','Peripheral','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('29','Computer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('35','Computer','3','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('36','Computer','19','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('37','Computer','17','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('40','NetworkEquipment','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('41','NetworkEquipment','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('42','NetworkEquipment','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('43','NetworkEquipment','19','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('47','Printer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('48','Printer','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('53','Monitor','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('54','Monitor','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('58','Peripheral','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('59','Peripheral','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('60','Peripheral','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('64','Contact','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('65','Contact','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('66','Contact','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('67','Contact','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('68','Contact','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('69','Supplier','9','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('70','Supplier','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('71','Supplier','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('72','Supplier','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('73','Supplier','10','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('74','Supplier','6','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('75','Contract','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('76','Contract','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('77','Contract','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('78','Contract','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('79','Contract','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('80','Contract','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('84','CartridgeItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('85','CartridgeItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('88','DocumentType','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('89','DocumentType','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('90','DocumentType','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('91','Document','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('92','Document','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('93','Document','7','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('94','Document','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('95','Document','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('96','User','34','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('98','User','5','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('99','User','6','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('100','User','3','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('101','ConsumableItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('102','ConsumableItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('103','ConsumableItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('104','ConsumableItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('105','NetworkEquipment','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('106','Printer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('107','Monitor','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('108','Peripheral','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('109','User','8','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('110','Phone','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('111','Phone','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('112','Phone','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('113','Phone','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('114','Phone','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('115','Phone','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('116','Phone','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('117','Group','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('118','AllAssets','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('119','ReservationItem','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('120','ReservationItem','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('125','Budget','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('122','Software','72','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('123','Software','163','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('124','Budget','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('126','Budget','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('127','Budget','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('128','Crontask','8','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('129','Crontask','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('130','Crontask','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('131','Crontask','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('132','RequestType','14','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('133','RequestType','15','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('134','NotificationTemplate','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('135','NotificationTemplate','16','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('136','Notification','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('137','Notification','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('138','Notification','2','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('139','Notification','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('140','Notification','80','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('141','Notification','86','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('142','MailCollector','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('143','MailCollector','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('144','AuthLDAP','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('145','AuthLDAP','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('146','AuthMail','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('147','AuthMail','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('210','IPNetwork','18','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('209','WifiNetwork','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('150','Profile','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('151','Profile','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('152','Profile','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('153','Transfer','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('154','TicketValidation','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('155','TicketValidation','2','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('156','TicketValidation','8','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('157','TicketValidation','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('158','TicketValidation','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('159','TicketValidation','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('160','NotImportedEmail','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('161','NotImportedEmail','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('162','NotImportedEmail','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('163','NotImportedEmail','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('164','NotImportedEmail','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('165','NotImportedEmail','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('166','RuleRightParameter','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('167','Ticket','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('168','Ticket','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('169','Ticket','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('170','Ticket','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('171','Ticket','4','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('172','Ticket','5','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('173','Ticket','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('174','Calendar','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('175','Holiday','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('176','Holiday','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('177','Holiday','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('178','SLA','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('179','Ticket','18','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('180','AuthLdap','30','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('181','AuthMail','6','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('208','FQDN','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('183','FieldUnicity','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('184','FieldUnicity','80','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('185','FieldUnicity','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('186','FieldUnicity','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('187','FieldUnicity','86','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('188','FieldUnicity','30','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('189','Problem','21','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('190','Problem','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('191','Problem','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('192','Problem','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('193','Problem','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('194','Problem','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('195','Problem','18','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('196','Vlan','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('197','TicketRecurrent','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('198','TicketRecurrent','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('199','TicketRecurrent','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('200','TicketRecurrent','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('201','TicketRecurrent','14','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('202','Reminder','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('203','Reminder','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('204','Reminder','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('205','Reminder','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('206','Reminder','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('207','Reminder','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('211','IPNetwork','10','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('212','IPNetwork','11','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('213','IPNetwork','12','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('214','IPNetwork','17','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('215','NetworkName','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('216','NetworkName','13','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('217','RSSFeed','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('218','RSSFeed','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('219','RSSFeed','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('220','RSSFeed','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('221','RSSFeed','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('222','RSSFeed','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('223','Blacklist','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('224','Blacklist','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('225','ReservationItem','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('226','QueueMail','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('227','QueueMail','7','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('228','QueueMail','20','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('229','QueueMail','21','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('230','QueueMail','22','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('231','QueueMail','15','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('232','Change','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('233','Change','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('234','Change','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('235','Change','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('236','Change','18','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('237','Project','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('238','Project','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('239','Project','12','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('240','Project','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('241','Project','15','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('242','Project','21','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('243','ProjectState','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('244','ProjectState','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('245','ProjectTask','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('246','ProjectTask','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('247','ProjectTask','14','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('248','ProjectTask','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('249','ProjectTask','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('250','ProjectTask','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('251','ProjectTask','13','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('252','CartridgeItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('253','ConsumableItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('254','ReservationItem','9','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('255','SoftwareLicense','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('256','SoftwareLicense','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('257','SoftwareLicense','10','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('258','SoftwareLicense','162','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('259','SoftwareLicense','5','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('260','SavedSearch','8','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('261','SavedSearch','9','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('262','SavedSearch','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('263','SavedSearch','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('264','SavedSearch','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('270','PluginComproveedoresComproveedore','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('269','PluginComproveedoresComproveedore','5','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('271','Supplier','29','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('272','Supplier','3','2','10');
INSERT INTO `glpi_displaypreferences` VALUES ('273','Supplier','4','3','10');
INSERT INTO `glpi_displaypreferences` VALUES ('274','Supplier','5','4','10');
INSERT INTO `glpi_displaypreferences` VALUES ('275','Supplier','6','6','10');
INSERT INTO `glpi_displaypreferences` VALUES ('276','Supplier','9','1','10');
INSERT INTO `glpi_displaypreferences` VALUES ('277','Supplier','10','5','10');
INSERT INTO `glpi_displaypreferences` VALUES ('278','Supplier','29','7','10');
INSERT INTO `glpi_displaypreferences` VALUES ('279','Supplier','8','8','10');
INSERT INTO `glpi_displaypreferences` VALUES ('280','User','20','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('281','User','9','3','0');

### Dump table glpi_documentcategories

DROP TABLE IF EXISTS `glpi_documentcategories`;
CREATE TABLE `glpi_documentcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`documentcategories_id`,`name`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_documents

DROP TABLE IF EXISTS `glpi_documents`;
CREATE TABLE `glpi_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'for display and transfert',
  `filepath` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'file storage path',
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `sha1sum` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_blacklisted` tinyint(1) NOT NULL DEFAULT '0',
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `users_id` (`users_id`),
  KEY `documentcategories_id` (`documentcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `sha1sum` (`sha1sum`),
  KEY `tag` (`tag`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documents` VALUES ('1','0','0','Documento: Proveedor - CONSTRUCCIONES ATILIANO Y ANTONIO','fotex.png','PNG/cb/c3ef5755739749c5daaf12356c868e7c7525db.PNG','0','image/png','2018-04-11 11:58:14',NULL,'0',NULL,'2','0','cbc3ef5755739749c5daaf12356c868e7c7525db','0','d91c07ab-ef23e180-5acddc3316c024.21668431','2018-04-11 11:58:14');

### Dump table glpi_documents_items

DROP TABLE IF EXISTS `glpi_documents_items`;
CREATE TABLE `glpi_documents_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `documents_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) DEFAULT '0',
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`documents_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`,`entities_id`,`is_recursive`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documents_items` VALUES ('1','1','1','Supplier','0','0','2018-04-11 11:58:14','2','0');

### Dump table glpi_documenttypes

DROP TABLE IF EXISTS `glpi_documenttypes`;
CREATE TABLE `glpi_documenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ext` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_uploadable` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ext`),
  KEY `name` (`name`),
  KEY `is_uploadable` (`is_uploadable`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documenttypes` VALUES ('1','JPEG','jpg','jpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('2','PNG','png','png-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('3','GIF','gif','gif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('4','BMP','bmp','bmp-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('5','Photoshop','psd','psd-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('6','TIFF','tif','tif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('7','AIFF','aiff','aiff-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('8','Windows Media','asf','asf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('9','Windows Media','avi','avi-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('44','C source','c','c-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('27','RealAudio','rm','rm-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('16','Midi','mid','mid-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('17','QuickTime','mov','mov-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('18','MP3','mp3','mp3-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('19','MPEG','mpg','mpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('20','Ogg Vorbis','ogg','ogg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('24','QuickTime','qt','qt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('10','BZip','bz2','bz2-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('25','RealAudio','ra','ra-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('26','RealAudio','ram','ram-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('11','Word','doc','doc-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('12','DjVu','djvu','','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('42','MNG','mng','','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('13','PostScript','eps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('14','GZ','gz','gz-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('37','WAV','wav','wav-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('15','HTML','html','html-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('34','Flash','swf','swf-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('21','PDF','pdf','pdf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('22','PowerPoint','ppt','ppt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('23','PostScript','ps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('40','Windows Media','wmv','wmv-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('28','RTF','rtf','rtf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('29','StarOffice','sdd','sdd-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('30','StarOffice','sdw','sdw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('31','Stuffit','sit','sit-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('43','Adobe Illustrator','ai','ai-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('32','OpenOffice Impress','sxi','sxi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('33','OpenOffice','sxw','sxw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('46','DVI','dvi','dvi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('35','TGZ','tgz','tgz-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('36','texte','txt','txt-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('49','RedHat/Mandrake/SuSE','rpm','rpm-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('38','Excel','xls','xls-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('39','XML','xml','xml-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('41','Zip','zip','zip-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('45','Debian','deb','deb-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('47','C header','h','h-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('48','Pascal','pas','pas-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('50','OpenOffice Calc','sxc','sxc-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('51','LaTeX','tex','tex-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('52','GIMP multi-layer','xcf','xcf-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('53','JPEG','jpeg','jpg-dist.png','','1','2005-03-07 22:23:17',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('54','Oasis Open Office Writer','odt','odt-dist.png','','1','2006-01-21 17:41:13',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('55','Oasis Open Office Calc','ods','ods-dist.png','','1','2006-01-21 17:41:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('56','Oasis Open Office Impress','odp','odp-dist.png','','1','2006-01-21 17:42:54',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('57','Oasis Open Office Impress Template','otp','odp-dist.png','','1','2006-01-21 17:43:58',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('58','Oasis Open Office Writer Template','ott','odt-dist.png','','1','2006-01-21 17:44:41',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('59','Oasis Open Office Calc Template','ots','ods-dist.png','','1','2006-01-21 17:45:30',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('60','Oasis Open Office Math','odf','odf-dist.png','','1','2006-01-21 17:48:05',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('61','Oasis Open Office Draw','odg','odg-dist.png','','1','2006-01-21 17:48:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('62','Oasis Open Office Draw Template','otg','odg-dist.png','','1','2006-01-21 17:49:46',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('63','Oasis Open Office Base','odb','odb-dist.png','','1','2006-01-21 18:03:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('64','Oasis Open Office HTML','oth','oth-dist.png','','1','2006-01-21 18:05:27',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('65','Oasis Open Office Writer Master','odm','odm-dist.png','','1','2006-01-21 18:06:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('66','Oasis Open Office Chart','odc','','','1','2006-01-21 18:07:48',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('67','Oasis Open Office Image','odi','','','1','2006-01-21 18:08:18',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('68','Word XML','docx','doc-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('69','Excel XML','xlsx','xls-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('70','PowerPoint XML','pptx','ppt-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('71','Comma-Separated Values','csv','csv-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('72','Scalable Vector Graphics','svg','svg-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);

### Dump table glpi_domains

DROP TABLE IF EXISTS `glpi_domains`;
CREATE TABLE `glpi_domains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_dropdowntranslations

DROP TABLE IF EXISTS `glpi_dropdowntranslations`;
CREATE TABLE `glpi_dropdowntranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`language`,`field`),
  KEY `typeid` (`itemtype`,`items_id`),
  KEY `language` (`language`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities

DROP TABLE IF EXISTS `glpi_entities`;
CREATE TABLE `glpi_entities` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notification_subject_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_dn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `mail_domain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_ldapfilter` text COLLATE utf8_unicode_ci,
  `mailing_signature` text COLLATE utf8_unicode_ci,
  `cartridges_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `consumables_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `use_licenses_alert` int(11) NOT NULL DEFAULT '-2',
  `send_licenses_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_certificates_alert` int(11) NOT NULL DEFAULT '-2',
  `send_certificates_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_contracts_alert` int(11) NOT NULL DEFAULT '-2',
  `send_contracts_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_infocoms_alert` int(11) NOT NULL DEFAULT '-2',
  `send_infocoms_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_reservations_alert` int(11) NOT NULL DEFAULT '-2',
  `autoclose_delay` int(11) NOT NULL DEFAULT '-2',
  `notclosed_delay` int(11) NOT NULL DEFAULT '-2',
  `calendars_id` int(11) NOT NULL DEFAULT '-2',
  `auto_assign_mode` int(11) NOT NULL DEFAULT '-2',
  `tickettype` int(11) NOT NULL DEFAULT '-2',
  `max_closedate` datetime DEFAULT NULL,
  `inquest_config` int(11) NOT NULL DEFAULT '-2',
  `inquest_rate` int(11) NOT NULL DEFAULT '0',
  `inquest_delay` int(11) NOT NULL DEFAULT '-10',
  `inquest_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autofill_warranty_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_use_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_buy_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_delivery_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_order_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '-2',
  `entities_id_software` int(11) NOT NULL DEFAULT '-2',
  `default_contract_alert` int(11) NOT NULL DEFAULT '-2',
  `default_infocom_alert` int(11) NOT NULL DEFAULT '-2',
  `default_cartridges_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `default_consumables_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `delay_send_emails` int(11) NOT NULL DEFAULT '-2',
  `is_notif_enable_default` int(11) NOT NULL DEFAULT '-2',
  `inquest_duration` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `autofill_decommission_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`name`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_entities` VALUES ('0','Root entity','-1','Root entity',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'0','0','0','0','0','0','0','0','0','0','0','-10','0','0','-10','1',NULL,'1','0','0',NULL,'0','0','0','0','0','1','-10','0','0','10','10','0','1','0',NULL,NULL,'0');

### Dump table glpi_entities_knowbaseitems

DROP TABLE IF EXISTS `glpi_entities_knowbaseitems`;
CREATE TABLE `glpi_entities_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_reminders

DROP TABLE IF EXISTS `glpi_entities_reminders`;
CREATE TABLE `glpi_entities_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_rssfeeds

DROP TABLE IF EXISTS `glpi_entities_rssfeeds`;
CREATE TABLE `glpi_entities_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_events

DROP TABLE IF EXISTS `glpi_events`;
CREATE TABLE `glpi_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `service` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `level` (`level`),
  KEY `item` (`type`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_events` VALUES ('1','-1','system','2018-03-22 11:44:00','login','3','glpi inició la sesión desde la IP 192.168.0.168');
INSERT INTO `glpi_events` VALUES ('2','-1','system','2018-04-10 08:27:31','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('3','1','suppliers','2018-04-10 08:36:33','financial','4','glpi añade el elemento CONSTRUCCIONES ATILIANO Y ANTONIO');
INSERT INTO `glpi_events` VALUES ('4','-1','system','2018-04-10 09:05:53','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('5','-1','system','2018-04-10 11:30:02','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('6','6','users','2018-04-10 11:39:51','setup','4','glpi añade el elemento usuario_proveedor1');
INSERT INTO `glpi_events` VALUES ('7','6','users','2018-04-10 11:41:46','setup','4','glpi añade un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('8','-1','system','2018-04-10 11:42:07','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('9','-1','system','2018-04-10 11:43:49','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('10','-1','system','2018-04-10 11:44:06','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('11','-1','system','2018-04-10 11:45:32','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('12','-1','system','2018-04-10 11:46:03','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('13','-1','system','2018-04-10 11:46:35','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('14','-1','system','2018-04-10 11:46:42','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('15','-1','system','2018-04-10 11:53:00','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('16','-1','system','2018-04-10 12:11:41','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('17','-1','system','2018-04-10 12:13:26','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('18','-1','system','2018-04-10 12:15:03','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('19','-1','system','2018-04-10 12:27:53','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('20','-1','system','2018-04-10 12:28:07','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('21','-1','system','2018-04-10 12:54:56','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('22','-1','system','2018-04-10 12:55:27','login','3','Fallo en el inicio de sesión de usuario proveedor uno desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('23','-1','system','2018-04-10 12:55:30','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('24','-1','system','2018-04-10 12:55:46','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('25','-1','system','2018-04-10 13:06:35','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('26','-1','system','2018-04-10 13:07:28','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('27','-1','system','2018-04-10 13:12:23','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('28','-1','system','2018-04-10 13:18:59','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('29','-1','system','2018-04-10 13:19:25','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('30','-1','system','2018-04-10 13:24:31','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('31','-1','system','2018-04-10 13:25:43','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('32','-1','system','2018-04-10 13:38:30','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('33','-1','system','2018-04-10 13:42:47','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('34','-1','system','2018-04-10 13:43:56','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('35','-1','system','2018-04-10 13:46:07','login','3','Fallo en el inicio de sesión de usuario_proveedor1 desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('36','-1','system','2018-04-10 13:46:12','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('37','-1','system','2018-04-10 13:46:29','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('38','-1','system','2018-04-10 13:47:08','login','3','Fallo en el inicio de sesión de usuario_proveedor1 desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('39','-1','system','2018-04-10 13:47:24','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('40','-1','system','2018-04-10 13:48:12','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('41','-1','system','2018-04-10 13:48:40','login','3','Fallo en el inicio de sesión de usuario_proveedor_1 desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('42','-1','system','2018-04-10 13:48:52','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('43','-1','system','2018-04-10 13:51:27','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('44','-1','system','2018-04-10 13:53:13','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('45','-1','system','2018-04-10 13:59:16','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('46','-1','system','2018-04-10 14:00:03','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('47','-1','system','2018-04-10 14:09:06','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('48','-1','system','2018-04-10 14:49:58','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('49','-1','system','2018-04-10 14:55:49','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('50','-1','system','2018-04-10 14:56:15','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('51','-1','system','2018-04-11 09:01:30','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('52','-1','system','2018-04-11 09:25:54','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('53','1','documents','2018-04-11 11:58:14','document','4','glpi añade un enlace con un elemento');
INSERT INTO `glpi_events` VALUES ('54','1','documents','2018-04-11 11:58:14','login','4','glpi añade el elemento Documento: Proveedor - CONSTRUCCIONES ATILIANO Y ANTONIO');
INSERT INTO `glpi_events` VALUES ('55','-1','system','2018-04-12 08:38:20','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('56','-1','system','2018-04-12 08:46:29','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('57','-1','system','2018-04-12 08:50:18','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('58','-1','system','2018-04-12 08:54:36','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('59','-1','system','2018-04-12 08:55:06','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('60','-1','system','2018-04-12 08:58:06','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('61','-1','system','2018-04-12 09:02:24','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('62','-1','system','2018-04-12 09:04:26','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('63','-1','system','2018-04-12 09:46:19','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('64','-1','system','2018-04-12 11:25:51','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('65','-1','system','2018-04-12 12:10:23','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('66','2','users','2018-04-12 12:20:37','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('67','-1','system','2018-04-12 12:24:18','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('68','-1','system','2018-04-12 12:25:08','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('69','-1','system','2018-04-12 12:30:28','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('70','-1','system','2018-04-12 12:31:24','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('71','-1','system','2018-04-12 12:36:53','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('72','-1','system','2018-04-12 12:38:44','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('73','1','State','2018-04-12 12:59:03','setup','4','glpi añade el elemento Alta');
INSERT INTO `glpi_events` VALUES ('74','-1','system','2018-04-12 13:07:42','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('75','-1','system','2018-04-12 13:07:58','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('76','-1','system','2018-04-12 13:11:02','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('77','-1','system','2018-04-12 13:13:14','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('78','1','knowbaseitem','2018-04-12 13:14:15','tools','5','glpi añade el elemento 1');
INSERT INTO `glpi_events` VALUES ('79','-1','system','2018-04-12 13:21:12','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('80','-1','system','2018-04-12 13:49:41','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('81','-1','system','2018-04-13 08:08:23','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('82','-1','system','2018-04-13 08:57:13','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('83','-1','system','2018-04-13 09:02:47','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('84','-1','system','2018-04-13 09:03:03','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('85','-1','system','2018-04-13 09:04:59','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('86','-1','system','2018-04-13 09:05:19','login','3','Fallo en el inicio de sesión de usuario_proveedor1 desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('87','-1','system','2018-04-13 09:05:23','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('88','7','users','2018-04-13 09:05:56','setup','4','glpi añade el elemento prov');
INSERT INTO `glpi_events` VALUES ('89','-1','system','2018-04-13 09:06:05','login','3','Fallo en el inicio de sesión de proc desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('90','-1','system','2018-04-13 09:06:15','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('91','-1','system','2018-04-13 09:11:43','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('92','-1','system','2018-04-13 09:24:35','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('93','-1','system','2018-04-13 09:25:42','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('94','-1','system','2018-04-13 09:26:12','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('95','-1','system','2018-04-13 09:29:53','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('96','-1','system','2018-04-13 09:31:10','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('97','-1','system','2018-04-13 09:32:12','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('98','-1','system','2018-04-13 09:32:36','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('99','-1','system','2018-04-13 09:33:28','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('100','-1','system','2018-04-13 09:40:08','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('101','-1','system','2018-04-13 09:40:58','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('102','-1','system','2018-04-13 10:09:17','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('103','-1','system','2018-04-13 10:11:14','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('104','-1','system','2018-04-13 10:11:48','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('105','-1','system','2018-04-13 10:15:23','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('106','-1','system','2018-04-13 10:15:39','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('107','-1','system','2018-04-13 10:18:52','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('108','-1','system','2018-04-13 10:19:08','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('109','-1','system','2018-04-13 10:19:28','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('110','-1','system','2018-04-13 10:19:50','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('111','-1','system','2018-04-13 11:06:43','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('112','-1','system','2018-04-13 11:07:03','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('113','-1','system','2018-04-13 11:08:39','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('114','-1','system','2018-04-13 11:10:45','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('115','-1','system','2018-04-13 11:11:29','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('116','-1','system','2018-04-13 11:12:01','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('117','-1','system','2018-04-13 11:12:18','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('118','-1','system','2018-04-13 11:12:37','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('119','-1','system','2018-04-13 11:13:57','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('120','-1','system','2018-04-13 11:16:12','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('121','-1','system','2018-04-13 11:16:41','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('122','-1','system','2018-04-13 11:17:09','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('123','-1','system','2018-04-13 11:19:15','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('124','-1','system','2018-04-13 11:20:25','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('125','-1','system','2018-04-13 11:20:51','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('126','-1','system','2018-04-13 11:21:09','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('127','-1','system','2018-04-13 11:21:26','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('128','-1','system','2018-04-13 11:21:54','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('129','-1','system','2018-04-13 11:32:15','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('130','-1','system','2018-04-13 11:34:33','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('131','-1','system','2018-04-13 11:35:14','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('132','-1','system','2018-04-13 11:35:42','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('133','-1','system','2018-04-13 11:36:15','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('134','-1','system','2018-04-13 11:40:00','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('135','-1','system','2018-04-13 11:41:02','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('136','-1','system','2018-04-13 11:49:53','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('137','-1','system','2018-04-13 11:56:06','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('138','-1','system','2018-04-13 11:58:18','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('139','-1','system','2018-04-13 12:09:21','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('140','-1','system','2018-04-13 12:09:29','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('141','-1','system','2018-04-13 12:25:24','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('142','-1','system','2018-04-13 12:26:19','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('143','-1','system','2018-04-13 12:27:47','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('144','-1','system','2018-04-13 12:28:17','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('145','-1','system','2018-04-13 12:29:16','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('146','-1','system','2018-04-13 12:29:34','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('147','-1','system','2018-04-13 12:30:10','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('148','-1','system','2018-04-13 12:32:26','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('149','-1','system','2018-04-13 12:33:48','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('150','-1','system','2018-04-13 12:34:08','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('151','-1','system','2018-04-13 12:34:15','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('152','-1','system','2018-04-13 12:37:28','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('153','-1','system','2018-04-13 12:39:03','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('154','-1','system','2018-04-13 12:39:28','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('155','-1','system','2018-04-13 12:45:34','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('156','-1','system','2018-04-13 12:50:32','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('157','-1','system','2018-04-13 12:50:53','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('158','-1','system','2018-04-13 12:52:13','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('159','-1','system','2018-04-13 12:52:22','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('160','-1','system','2018-04-13 13:08:00','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('161','-1','system','2018-04-13 13:12:36','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('162','-1','system','2018-04-13 13:13:50','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('163','-1','system','2018-04-13 13:21:11','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('164','1','reminder','2018-04-13 13:26:02','tools','4','prov añade el elemento Nueva nota');
INSERT INTO `glpi_events` VALUES ('165','1','reminder','2018-04-13 13:26:38','tools','4','prov actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('166','1','reminder','2018-04-13 13:26:59','tools','4','prov actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('167','-1','system','2018-04-13 13:31:48','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('168','-1','system','2018-04-13 13:43:14','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('169','-1','system','2018-04-13 13:58:33','login','3','PROV inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('170','-1','system','2018-04-13 13:59:31','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('171','-1','system','2018-04-13 14:00:34','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('172','-1','system','2018-04-13 14:00:39','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('173','-1','system','2018-04-13 14:09:21','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('174','-1','system','2018-04-16 08:07:05','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('175','-1','system','2018-04-16 08:09:49','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('176','-1','system','2018-04-16 08:24:00','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('177','-1','system','2018-04-16 14:48:58','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('178','7','users','2018-04-16 14:49:27','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('179','-1','system','2018-04-16 14:58:49','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('180','-1','system','2018-04-16 14:59:08','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('181','-1','system','2018-04-16 14:59:15','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('182','-1','system','2018-04-17 08:09:48','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('183','-1','system','2018-04-17 08:10:15','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('184','-1','system','2018-04-17 08:10:30','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('185','-1','system','2018-04-17 08:10:48','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('186','-1','system','2018-04-17 08:13:34','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('187','-1','system','2018-04-17 08:14:31','login','3','prov inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('188','-1','system','2018-04-17 08:21:36','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('189','8','users','2018-04-17 08:24:44','setup','4','glpi añade el elemento tec');
INSERT INTO `glpi_events` VALUES ('190','-1','system','2018-04-17 13:40:21','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('191','-1','system','2018-04-17 14:44:53','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('192','-1','system','2018-04-18 08:11:21','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('193','-1','system','2018-04-18 08:11:35','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('194','-1','system','2018-04-18 08:21:26','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('195','-1','system','2018-04-18 08:21:45','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('196','-1','system','2018-04-18 08:23:04','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('197','-1','system','2018-04-18 08:36:46','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('198','-1','system','2018-04-18 11:05:57','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('199','-1','system','2018-04-18 11:15:06','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('200','-1','system','2018-04-18 11:15:40','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('201','-1','system','2018-04-18 14:21:31','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('202','-1','system','2018-04-18 14:24:39','login','3','Fallo en el inicio de sesión de dtorvisco desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('203','-1','system','2018-04-18 14:24:51','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('204','-1','system','2018-04-18 14:37:50','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('205','-1','system','2018-04-19 08:06:49','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('206','1','UserTitle','2018-04-19 08:16:17','setup','4','glpi añade el elemento Director Geneal');
INSERT INTO `glpi_events` VALUES ('207','7','users','2018-04-19 08:16:22','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('208','2','UserTitle','2018-04-19 08:18:00','setup','4','glpi añade el elemento Representante');
INSERT INTO `glpi_events` VALUES ('209','9','users','2018-04-19 08:18:25','setup','4','glpi añade el elemento prov 2');
INSERT INTO `glpi_events` VALUES ('210','9','users','2018-04-19 08:19:02','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('211','9','users','2018-04-19 08:24:04','setup','4','glpi añade un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('212','9','users','2018-04-19 08:24:26','setup','4','glpi añade un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('213','9','users','2018-04-19 08:24:31','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('214','-1','system','2018-04-19 08:24:42','login','3','prov 2 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('215','-1','system','2018-04-19 08:24:56','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('216','9','users','2018-04-19 08:25:05','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('217','-1','system','2018-04-19 08:36:51','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('218','-1','system','2018-04-19 08:37:23','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('219','-1','system','2018-04-19 08:38:31','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('220','-1','system','2018-04-19 08:38:57','login','3','Fallo en el inicio de sesión de glpiprov desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('221','-1','system','2018-04-19 08:39:02','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('222','-1','system','2018-04-19 08:51:22','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('223','-1','system','2018-04-19 08:54:24','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('224','-1','system','2018-04-19 08:59:02','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('225','-1','system','2018-04-19 08:59:25','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('226','-1','system','2018-04-19 09:00:08','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('227','-1','system','2018-04-19 09:00:50','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('228','-1','system','2018-04-19 09:07:01','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('229','-1','system','2018-04-19 09:07:12','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('230','-1','system','2018-04-19 09:07:49','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('231','-1','system','2018-04-20 13:33:51','login','3','prov inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('232','-1','system','2018-04-20 13:34:02','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('233','-1','system','2018-04-20 13:38:12','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('234','-1','system','2018-04-20 13:38:20','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('235','-1','system','2018-04-20 13:38:26','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('236','-1','system','2018-04-20 13:38:40','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('237','-1','system','2018-04-20 13:38:51','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('238','-1','system','2018-04-20 13:38:57','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('239','-1','system','2018-04-20 13:39:09','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('240','-1','system','2018-04-20 13:39:15','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('241','-1','system','2018-04-20 14:11:55','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('242','10','users','2018-04-20 14:22:18','setup','4','glpi añade el elemento tec1');
INSERT INTO `glpi_events` VALUES ('243','10','users','2018-04-20 14:22:29','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('244','6','users','2018-04-20 14:22:50','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('245','-1','system','2018-04-20 14:23:16','login','3','tec1 inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('246','-1','system','2018-04-20 14:23:38','login','3','glpi inició la sesión desde la IP 192.168.0.158');
INSERT INTO `glpi_events` VALUES ('247','2','suppliers','2018-04-20 14:37:22','financial','4','glpi añade el elemento Construcciones Lopez');
INSERT INTO `glpi_events` VALUES ('248','-1','system','2018-04-23 10:31:14','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('249','-1','system','2018-04-23 10:31:21','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('250','-1','system','2018-04-23 11:05:46','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('251','11','users','2018-04-23 11:30:28','setup','4','glpi añade el elemento prov 5');
INSERT INTO `glpi_events` VALUES ('252','6','users','2018-04-23 11:38:31','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('253','-1','system','2018-04-23 11:38:43','login','3','usuario_proveedor1 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('254','-1','system','2018-04-23 11:39:35','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('255','-1','system','2018-04-23 12:09:02','login','3','prov 2 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('256','-1','system','2018-04-23 12:09:28','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('257','12','users','2018-04-23 12:10:37','setup','4','glpi añade el elemento prov 6');
INSERT INTO `glpi_events` VALUES ('258','12','users','2018-04-23 12:11:05','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('259','-1','system','2018-04-23 12:50:00','login','3','prov inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('260','-1','system','2018-04-23 12:53:42','login','3','Fallo en el inicio de sesión de prov2 desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('261','-1','system','2018-04-23 12:53:49','login','3','Fallo en el inicio de sesión de prov2 desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('262','-1','system','2018-04-23 12:54:36','login','3','prov inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('263','-1','system','2018-04-23 12:54:54','login','3','Fallo en el inicio de sesión de prov2 desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('264','-1','system','2018-04-23 12:55:00','login','3','prov 2 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('265','-1','system','2018-04-23 12:55:07','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('266','7','users','2018-04-23 12:55:34','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('267','9','users','2018-04-23 12:55:53','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('268','2','users','2018-04-23 12:57:40','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('269','5','users','2018-04-23 12:57:54','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('270','3','users','2018-04-23 12:58:06','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('271','4','users','2018-04-23 12:58:16','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('272','-1','system','2018-04-23 13:31:50','login','3','Fallo en el inicio de sesión de prov2 desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('273','-1','system','2018-04-23 13:32:03','login','3','prov 2 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('274','-1','system','2018-04-23 13:35:35','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('275','-1','system','2018-04-23 13:35:42','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('276','-1','system','2018-04-23 13:36:20','login','3','prov 2 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('277','-1','system','2018-04-23 13:38:28','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('278','-1','system','2018-04-23 13:38:35','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('279','-1','system','2018-04-23 13:38:58','login','3','prov 2 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('280','-1','system','2018-04-24 08:11:22','login','3','prov 2 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('281','-1','system','2018-04-24 12:19:47','login','3','Fallo en el inicio de sesión de prov desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('282','-1','system','2018-04-24 12:19:54','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('283','-1','system','2018-04-25 09:25:45','login','3','Fallo en el inicio de sesión de glpi desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('284','-1','system','2018-04-25 09:27:38','login','3','Fallo en el inicio de sesión de glpi desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('285','-1','system','2018-04-25 09:28:39','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('286','-1','system','2018-04-25 09:42:54','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('287','-1','system','2018-04-26 08:29:49','login','3','prov 2 inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('288','-1','system','2018-04-26 08:30:07','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('289','-1','system','2018-04-26 08:49:14','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('290','-1','system','2018-04-26 09:42:48','login','3','Fallo en el inicio de sesión de  desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('291','-1','system','2018-04-26 09:42:55','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('292','-1','system','2018-04-26 09:44:36','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('293','-1','system','2018-04-26 07:46:41','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('294','-1','system','2018-04-26 08:24:21','login','3','Fallo en el inicio de sesión de glpi desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('295','-1','system','2018-04-26 08:24:32','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('296','2','suppliers','2018-04-26 08:25:06','financial','4','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('297','-1','system','2018-04-26 11:11:25','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('298','-1','system','2018-04-26 11:12:38','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('299','-1','system','2018-04-26 11:13:59','login','3','Fallo en el inicio de sesión de glpi desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('300','-1','system','2018-04-26 11:14:09','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('301','-1','system','2018-04-26 11:53:04','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('302','-1','system','2018-04-26 11:53:36','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('303','-1','system','2018-04-26 11:54:12','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('304','-1','system','2018-04-26 11:54:34','login','3','Fallo en el inicio de sesión de prov2 desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('305','-1','system','2018-04-26 11:54:44','login','3','prov inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('306','-1','system','2018-04-26 11:55:19','login','3','Fallo en el inicio de sesión de tec desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('307','-1','system','2018-04-26 11:55:29','login','3','tec1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('308','-1','system','2018-04-26 11:56:34','login','3','Fallo en el inicio de sesión de tec desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('309','-1','system','2018-04-26 11:56:46','login','3','tec1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('310','-1','system','2018-04-26 12:07:20','login','3','prov inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('311','-1','system','2018-04-26 12:39:40','login','3','tec1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('312','1','PhoneModel','2018-04-26 12:40:45','setup','4','tec1 añade el elemento SAMSUNG');
INSERT INTO `glpi_events` VALUES ('313','2','PhoneModel','2018-04-26 12:40:49','setup','4','tec1 añade el elemento NOKIA');
INSERT INTO `glpi_events` VALUES ('314','3','PhoneModel','2018-04-26 12:40:55','setup','4','tec1 añade el elemento WIKO');
INSERT INTO `glpi_events` VALUES ('315','10','users','2018-04-26 13:01:24','setup','5','tec1 actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('316','10','users','2018-04-26 13:01:42','setup','5','tec1 actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('317','-1','system','2018-04-26 22:26:55','login','3','glpi inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('318','-1','system','2018-04-27 09:57:46','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('319','13','users','2018-04-27 10:09:35','setup','4','glpi añade el elemento usuestrategico1');
INSERT INTO `glpi_events` VALUES ('320','14','users','2018-04-27 10:09:55','setup','4','glpi añade el elemento usufinanciero1');
INSERT INTO `glpi_events` VALUES ('321','15','users','2018-04-27 10:10:18','setup','4','glpi añade el elemento usugeneral1');
INSERT INTO `glpi_events` VALUES ('322','16','users','2018-04-27 10:10:38','setup','4','glpi añade el elemento usuproveedor1');
INSERT INTO `glpi_events` VALUES ('323','17','users','2018-04-27 10:12:02','setup','4','glpi añade el elemento usuproyecto1');
INSERT INTO `glpi_events` VALUES ('324','-1','system','2018-04-27 10:24:09','login','3','usugeneral1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('325','-1','system','2018-04-27 10:26:02','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('326','-1','system','2018-04-27 10:26:31','login','3','usuproveedor1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('327','-1','system','2018-04-27 13:26:05','login','3','glpi inició la sesión desde la IP 192.168.0.161');
INSERT INTO `glpi_events` VALUES ('328','-1','system','2018-04-30 08:27:15','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('329','-1','system','2018-04-30 09:06:58','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('330','-1','system','2018-04-30 09:12:06','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('331','-1','system','2018-04-30 09:16:51','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('332','-1','system','2018-04-30 12:01:31','login','3','tec1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('333','-1','system','2018-04-30 12:04:33','login','3','prov inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('334','-1','system','2018-04-30 12:09:50','login','3','Fallo en el inicio de sesión de tec desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('335','-1','system','2018-04-30 12:09:59','login','3','tec1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('336','-1','system','2018-04-30 12:16:47','login','3','prov inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('337','7','users','2018-04-30 12:36:59','setup','5','prov actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('338','-1','system','2018-04-30 13:47:19','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('339','1','SupplierType','2018-04-30 13:52:34','setup','4','glpi añade el elemento SOCIEDAD ANÓNIMA - SA');
INSERT INTO `glpi_events` VALUES ('340','2','SupplierType','2018-04-30 13:52:42','setup','4','glpi añade el elemento SOCIEDAD LIMITADA - SL');
INSERT INTO `glpi_events` VALUES ('341','3','SupplierType','2018-04-30 13:52:56','setup','4','glpi añade el elemento SOCIEDAD LIMITADA UNIPERSONAL - SLU');
INSERT INTO `glpi_events` VALUES ('342','3','suppliers','2018-04-30 13:53:04','financial','4','glpi añade el elemento ACCIONA CONSTRUCCIÓN, S.A.');
INSERT INTO `glpi_events` VALUES ('343','18','users','2018-04-30 14:08:23','setup','4','glpi añade el elemento luiscastillac');
INSERT INTO `glpi_events` VALUES ('344','3','UserTitle','2018-04-30 14:09:47','setup','4','glpi añade el elemento Dpto. Estudios');
INSERT INTO `glpi_events` VALUES ('345','4','UserTitle','2018-04-30 14:09:54','setup','4','glpi añade el elemento Dpto. Técnico');
INSERT INTO `glpi_events` VALUES ('346','5','UserTitle','2018-04-30 14:10:01','setup','4','glpi añade el elemento Dpto. Comercial');
INSERT INTO `glpi_events` VALUES ('347','6','UserTitle','2018-04-30 14:10:24','setup','4','glpi añade el elemento Representante');
INSERT INTO `glpi_events` VALUES ('348','18','users','2018-04-30 14:10:28','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('349','19','users','2018-04-30 14:12:15','setup','4','glpi añade el elemento areyq');
INSERT INTO `glpi_events` VALUES ('350','-1','system','2018-05-02 08:36:33','login','3','prov inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('351','-1','system','2018-05-02 08:36:56','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('352','-1','system','2018-05-03 08:27:41','login','3','glpi inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('353','-1','system','2018-05-03 08:28:27','login','3','glpi inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('354','-1','system','2018-05-03 13:24:23','login','3','glpi inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('355','19','users','2018-05-03 13:26:10','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('356','18','users','2018-05-03 13:26:26','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('357','20','users','2018-05-03 13:31:58','setup','4','glpi añade el elemento cesaralberto.orozco.reguero@acciona.com');
INSERT INTO `glpi_events` VALUES ('358','19','users','2018-05-03 13:32:25','setup','4','glpi añade un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('359','19','users','2018-05-03 13:32:40','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('360','20','users','2018-05-03 13:32:53','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('361','-1','system','2018-05-04 08:36:04','login','3','glpi inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('362','3','suppliers','2018-05-04 08:37:33','financial','4','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('363','2','reminder','2018-05-04 09:25:45','tools','4','glpi añade el elemento NECESIDAD CERTIFICADOS');
INSERT INTO `glpi_events` VALUES ('364','2','reminder','2018-05-04 09:32:42','tools','4','glpi añade un objetivo');
INSERT INTO `glpi_events` VALUES ('365','-1','system','2018-05-04 12:04:10','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('366','-1','system','2018-05-07 08:23:22','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('367','-1','system','2018-05-07 08:46:52','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('368','-1','system','2018-05-08 13:23:09','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('369','-1','system','2018-05-11 06:09:52','login','3','Fallo en el inicio de sesión de  desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('370','-1','system','2018-05-11 06:10:11','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('371','-1','system','2018-05-11 06:11:29','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('372','2','users','2018-05-11 08:23:11','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('373','3','users','2018-05-11 08:23:36','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('374','4','users','2018-05-11 08:24:01','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('375','-1','system','2018-05-11 11:43:27','login','3','usuestrategico1 inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('376','-1','system','2018-05-11 11:43:51','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('377','-1','system','2018-05-11 12:22:12','login','3','usuestrategico1 inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('378','-1','system','2018-05-11 12:32:03','login','3','usuestrategico1 inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('379','-1','system','2018-05-14 07:31:24','login','3','Fallo en el inicio de sesión de  desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('380','-1','system','2018-05-14 07:31:34','login','3','glpi inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('381','-1','system','2018-05-14 09:37:49','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('382','-1','system','2018-05-15 11:49:38','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('383','-1','system','2018-05-15 12:15:51','login','3','usuestrategico1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('384','-1','system','2018-05-15 12:20:36','login','3','usuestrategico1 inició la sesión desde la IP 192.168.0.117');
INSERT INTO `glpi_events` VALUES ('385','3','reminder','2018-05-15 12:21:29','tools','4','usuestrategico1 añade el elemento Recordatorio de pruebas');
INSERT INTO `glpi_events` VALUES ('386','1','project','2018-05-15 13:19:17','maintain','4','usuestrategico1 añade el elemento SANTIAGO BERNABEU');
INSERT INTO `glpi_events` VALUES ('387','1','project','2018-05-15 13:20:15','maintain','4','usuestrategico1 añade una tarea');
INSERT INTO `glpi_events` VALUES ('388','1','project','2018-05-15 13:21:14','maintain','4','usuestrategico1 añade una tarea');
INSERT INTO `glpi_events` VALUES ('389','1','projecttask','2018-05-15 13:22:49','maintain','4','usuestrategico1 añade un miembro del equipo');
INSERT INTO `glpi_events` VALUES ('390','-1','system','2018-05-17 09:04:41','login','3','usuestrategico1 inició la sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('391','-1','system','2018-05-17 11:38:38','login','3','glpi inició la sesión desde la IP 192.168.0.34');
INSERT INTO `glpi_events` VALUES ('392','-1','system','2018-05-20 22:30:13','login','3','glpi inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('393','-1','system','2018-05-20 22:53:31','login','3','glpi inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('394','-1','system','2018-05-20 22:53:46','login','3','usuestrategico1 inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('395','-1','system','2018-05-21 07:39:06','login','3','usuestrategico1 inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('396','1','project','2018-05-21 07:41:32','maintain','4','usuestrategico1 actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('397','-1','system','2018-05-21 07:42:37','login','3','glpi inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('398','-1','system','2018-05-21 07:44:21','login','3','usuestrategico1 inició la sesión desde la IP 90.77.8.59');
INSERT INTO `glpi_events` VALUES ('399','-1','system','2018-05-21 08:17:49','login','3','glpi inició la sesión desde la IP 192.168.0.34');

### Dump table glpi_fieldblacklists

DROP TABLE IF EXISTS `glpi_fieldblacklists`;
CREATE TABLE `glpi_fieldblacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_fieldunicities

DROP TABLE IF EXISTS `glpi_fieldunicities`;
CREATE TABLE `glpi_fieldunicities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `fields` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `action_refuse` tinyint(1) NOT NULL DEFAULT '0',
  `action_notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Stores field unicity criterias';


### Dump table glpi_filesystems

DROP TABLE IF EXISTS `glpi_filesystems`;
CREATE TABLE `glpi_filesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_filesystems` VALUES ('1','ext',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('2','ext2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('3','ext3',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('4','ext4',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('5','FAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('6','FAT32',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('7','VFAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('8','HFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('9','HPFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('10','HTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('11','JFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('12','JFS2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('13','NFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('14','NTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('15','ReiserFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('16','SMBFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('17','UDF',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('18','UFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('19','XFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('20','ZFS',NULL,NULL,NULL);

### Dump table glpi_fqdns

DROP TABLE IF EXISTS `glpi_fqdns`;
CREATE TABLE `glpi_fqdns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `fqdn` (`fqdn`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups

DROP TABLE IF EXISTS `glpi_groups`;
CREATE TABLE `glpi_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `ldap_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_value` text COLLATE utf8_unicode_ci,
  `ldap_group_dn` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_requester` tinyint(1) NOT NULL DEFAULT '1',
  `is_assign` tinyint(1) NOT NULL DEFAULT '1',
  `is_task` tinyint(1) NOT NULL DEFAULT '1',
  `is_notify` tinyint(1) NOT NULL DEFAULT '1',
  `is_itemgroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_usergroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_manager` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `ldap_field` (`ldap_field`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `ldap_value` (`ldap_value`(200)),
  KEY `ldap_group_dn` (`ldap_group_dn`(200)),
  KEY `groups_id` (`groups_id`),
  KEY `is_requester` (`is_requester`),
  KEY `is_assign` (`is_assign`),
  KEY `is_notify` (`is_notify`),
  KEY `is_itemgroup` (`is_itemgroup`),
  KEY `is_usergroup` (`is_usergroup`),
  KEY `is_manager` (`is_manager`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_knowbaseitems

DROP TABLE IF EXISTS `glpi_groups_knowbaseitems`;
CREATE TABLE `glpi_groups_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_problems

DROP TABLE IF EXISTS `glpi_groups_problems`;
CREATE TABLE `glpi_groups_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_reminders

DROP TABLE IF EXISTS `glpi_groups_reminders`;
CREATE TABLE `glpi_groups_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_rssfeeds

DROP TABLE IF EXISTS `glpi_groups_rssfeeds`;
CREATE TABLE `glpi_groups_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_tickets

DROP TABLE IF EXISTS `glpi_groups_tickets`;
CREATE TABLE `glpi_groups_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_users

DROP TABLE IF EXISTS `glpi_groups_users`;
CREATE TABLE `glpi_groups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `is_manager` tinyint(1) NOT NULL DEFAULT '0',
  `is_userdelegate` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`groups_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_manager` (`is_manager`),
  KEY `is_userdelegate` (`is_userdelegate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_holidays

DROP TABLE IF EXISTS `glpi_holidays`;
CREATE TABLE `glpi_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_perpetual` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `is_perpetual` (`is_perpetual`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_infocoms

DROP TABLE IF EXISTS `glpi_infocoms`;
CREATE TABLE `glpi_infocoms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `buy_date` date DEFAULT NULL,
  `use_date` date DEFAULT NULL,
  `warranty_duration` int(11) NOT NULL DEFAULT '0',
  `warranty_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `immo_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `warranty_value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `sink_time` int(11) NOT NULL DEFAULT '0',
  `sink_type` int(11) NOT NULL DEFAULT '0',
  `sink_coeff` float NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `bill` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `inventory_date` date DEFAULT NULL,
  `warranty_date` date DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `decommission_date` datetime DEFAULT NULL,
  `businesscriticities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  KEY `buy_date` (`buy_date`),
  KEY `alert` (`alert`),
  KEY `budgets_id` (`budgets_id`),
  KEY `suppliers_id` (`suppliers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `businesscriticities_id` (`businesscriticities_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_interfacetypes

DROP TABLE IF EXISTS `glpi_interfacetypes`;
CREATE TABLE `glpi_interfacetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_interfacetypes` VALUES ('1','IDE',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('2','SATA',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('3','SCSI',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('4','USB',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('5','AGP','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('6','PCI','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('7','PCIe','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('8','PCI-X','',NULL,NULL);

### Dump table glpi_ipaddresses

DROP TABLE IF EXISTS `glpi_ipaddresses`;
CREATE TABLE `glpi_ipaddresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `binary_0` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_1` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_2` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_3` int(10) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `mainitems_id` int(11) NOT NULL DEFAULT '0',
  `mainitemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `textual` (`name`),
  KEY `binary` (`binary_0`,`binary_1`,`binary_2`,`binary_3`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `mainitem` (`mainitemtype`,`mainitems_id`,`is_deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipaddresses_ipnetworks

DROP TABLE IF EXISTS `glpi_ipaddresses_ipnetworks`;
CREATE TABLE `glpi_ipaddresses_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddresses_id` int(11) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ipaddresses_id`,`ipnetworks_id`),
  KEY `ipnetworks_id` (`ipnetworks_id`),
  KEY `ipaddresses_id` (`ipaddresses_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks

DROP TABLE IF EXISTS `glpi_ipnetworks`;
CREATE TABLE `glpi_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `addressable` tinyint(1) NOT NULL DEFAULT '0',
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_0` int(10) unsigned NOT NULL DEFAULT '0',
  `address_1` int(10) unsigned NOT NULL DEFAULT '0',
  `address_2` int(10) unsigned NOT NULL DEFAULT '0',
  `address_3` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `netmask_0` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_1` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_2` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_3` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateway_0` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_1` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_2` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_3` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_definition` (`entities_id`,`address`,`netmask`),
  KEY `address` (`address_0`,`address_1`,`address_2`,`address_3`),
  KEY `netmask` (`netmask_0`,`netmask_1`,`netmask_2`,`netmask_3`),
  KEY `gateway` (`gateway_0`,`gateway_1`,`gateway_2`,`gateway_3`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks_vlans

DROP TABLE IF EXISTS `glpi_ipnetworks_vlans`;
CREATE TABLE `glpi_ipnetworks_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `link` (`ipnetworks_id`,`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicebatteries

DROP TABLE IF EXISTS `glpi_items_devicebatteries`;
CREATE TABLE `glpi_items_devicebatteries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicebatteries_id` int(11) NOT NULL DEFAULT '0',
  `manufacturing_date` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicebatteries_id` (`devicebatteries_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecases

DROP TABLE IF EXISTS `glpi_items_devicecases`;
CREATE TABLE `glpi_items_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecases_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecases_id` (`devicecases_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecontrols

DROP TABLE IF EXISTS `glpi_items_devicecontrols`;
CREATE TABLE `glpi_items_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecontrols_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecontrols_id` (`devicecontrols_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicedrives

DROP TABLE IF EXISTS `glpi_items_devicedrives`;
CREATE TABLE `glpi_items_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicedrives_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicedrives_id` (`devicedrives_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicefirmwares

DROP TABLE IF EXISTS `glpi_items_devicefirmwares`;
CREATE TABLE `glpi_items_devicefirmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicefirmwares_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicefirmwares_id` (`devicefirmwares_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicegenerics

DROP TABLE IF EXISTS `glpi_items_devicegenerics`;
CREATE TABLE `glpi_items_devicegenerics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegenerics_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicegenerics_id` (`devicegenerics_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicegraphiccards

DROP TABLE IF EXISTS `glpi_items_devicegraphiccards`;
CREATE TABLE `glpi_items_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegraphiccards_id` int(11) NOT NULL DEFAULT '0',
  `memory` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicegraphiccards_id` (`devicegraphiccards_id`),
  KEY `specificity` (`memory`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceharddrives

DROP TABLE IF EXISTS `glpi_items_deviceharddrives`;
CREATE TABLE `glpi_items_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceharddrives_id` int(11) NOT NULL DEFAULT '0',
  `capacity` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceharddrives_id` (`deviceharddrives_id`),
  KEY `specificity` (`capacity`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicememories

DROP TABLE IF EXISTS `glpi_items_devicememories`;
CREATE TABLE `glpi_items_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicememories_id` int(11) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicememories_id` (`devicememories_id`),
  KEY `specificity` (`size`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicemotherboards

DROP TABLE IF EXISTS `glpi_items_devicemotherboards`;
CREATE TABLE `glpi_items_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicemotherboards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicemotherboards_id` (`devicemotherboards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicenetworkcards

DROP TABLE IF EXISTS `glpi_items_devicenetworkcards`;
CREATE TABLE `glpi_items_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicenetworkcards_id` (`devicenetworkcards_id`),
  KEY `specificity` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepcis

DROP TABLE IF EXISTS `glpi_items_devicepcis`;
CREATE TABLE `glpi_items_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepcis_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepcis_id` (`devicepcis_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepowersupplies

DROP TABLE IF EXISTS `glpi_items_devicepowersupplies`;
CREATE TABLE `glpi_items_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepowersupplies_id` (`devicepowersupplies_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceprocessors

DROP TABLE IF EXISTS `glpi_items_deviceprocessors`;
CREATE TABLE `glpi_items_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceprocessors_id` int(11) NOT NULL DEFAULT '0',
  `frequency` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `nbcores` int(11) DEFAULT NULL,
  `nbthreads` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceprocessors_id` (`deviceprocessors_id`),
  KEY `specificity` (`frequency`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `nbcores` (`nbcores`),
  KEY `nbthreads` (`nbthreads`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesensors

DROP TABLE IF EXISTS `glpi_items_devicesensors`;
CREATE TABLE `glpi_items_devicesensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesensors_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicesensors_id` (`devicesensors_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesimcards

DROP TABLE IF EXISTS `glpi_items_devicesimcards`;
CREATE TABLE `glpi_items_devicesimcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to itemtype (id)',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `devicesimcards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `lines_id` int(11) NOT NULL DEFAULT '0',
  `pin` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pin2` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `puk` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `puk2` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `msin` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `devicesimcards_id` (`devicesimcards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `states_id` (`states_id`),
  KEY `locations_id` (`locations_id`),
  KEY `lines_id` (`lines_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesoundcards

DROP TABLE IF EXISTS `glpi_items_devicesoundcards`;
CREATE TABLE `glpi_items_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesoundcards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicesoundcards_id` (`devicesoundcards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `otherserial` (`otherserial`),
  KEY `locations_id` (`locations_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_operatingsystems

DROP TABLE IF EXISTS `glpi_items_operatingsystems`;
CREATE TABLE `glpi_items_operatingsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemversions_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemservicepacks_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemarchitectures_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemkernelversions_id` int(11) NOT NULL DEFAULT '0',
  `license_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `operatingsystemeditions_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`items_id`,`itemtype`,`operatingsystems_id`,`operatingsystemarchitectures_id`),
  KEY `items_id` (`items_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `operatingsystemservicepacks_id` (`operatingsystemservicepacks_id`),
  KEY `operatingsystemversions_id` (`operatingsystemversions_id`),
  KEY `operatingsystemarchitectures_id` (`operatingsystemarchitectures_id`),
  KEY `operatingsystemkernelversions_id` (`operatingsystemkernelversions_id`),
  KEY `operatingsystemeditions_id` (`operatingsystemeditions_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_problems

DROP TABLE IF EXISTS `glpi_items_problems`;
CREATE TABLE `glpi_items_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_projects

DROP TABLE IF EXISTS `glpi_items_projects`;
CREATE TABLE `glpi_items_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_tickets

DROP TABLE IF EXISTS `glpi_items_tickets`;
CREATE TABLE `glpi_items_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_itilcategories

DROP TABLE IF EXISTS `glpi_itilcategories`;
CREATE TABLE `glpi_itilcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `tickettemplates_id_incident` int(11) NOT NULL DEFAULT '0',
  `tickettemplates_id_demand` int(11) NOT NULL DEFAULT '0',
  `is_incident` int(11) NOT NULL DEFAULT '1',
  `is_request` int(11) NOT NULL DEFAULT '1',
  `is_problem` int(11) NOT NULL DEFAULT '1',
  `is_change` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `tickettemplates_id_incident` (`tickettemplates_id_incident`),
  KEY `tickettemplates_id_demand` (`tickettemplates_id_demand`),
  KEY `is_incident` (`is_incident`),
  KEY `is_request` (`is_request`),
  KEY `is_problem` (`is_problem`),
  KEY `is_change` (`is_change`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitemcategories

DROP TABLE IF EXISTS `glpi_knowbaseitemcategories`;
CREATE TABLE `glpi_knowbaseitemcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`knowbaseitemcategories_id`,`name`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems

DROP TABLE IF EXISTS `glpi_knowbaseitems`;
CREATE TABLE `glpi_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `is_faq` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `is_faq` (`is_faq`),
  KEY `date_mod` (`date_mod`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_knowbaseitems` VALUES ('1','0','Nuevo elemento','&lt;h1&gt;&lt;strong&gt;base  de conocimiento items&lt;/strong&gt;&lt;/h1&gt;&lt;div&gt; &lt;/div&gt;&lt;div style=\"padding-left: 60px;\"&gt;&lt;strong&gt;fasdf  &lt;em&gt;asdf asdf &lt;/em&gt;&lt;/strong&gt;&lt;/div&gt;','0','2','1','2018-04-12 13:14:15','2018-04-12 13:14:15',NULL,NULL);

### Dump table glpi_knowbaseitems_comments

DROP TABLE IF EXISTS `glpi_knowbaseitems_comments`;
CREATE TABLE `glpi_knowbaseitems_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `parent_comment_id` int(11) DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_items

DROP TABLE IF EXISTS `glpi_knowbaseitems_items`;
CREATE TABLE `glpi_knowbaseitems_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`knowbaseitems_id`),
  KEY `itemtype` (`itemtype`),
  KEY `item_id` (`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_profiles

DROP TABLE IF EXISTS `glpi_knowbaseitems_profiles`;
CREATE TABLE `glpi_knowbaseitems_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_revisions

DROP TABLE IF EXISTS `glpi_knowbaseitems_revisions`;
CREATE TABLE `glpi_knowbaseitems_revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL,
  `revision` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`knowbaseitems_id`,`revision`,`language`),
  KEY `revision` (`revision`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_users

DROP TABLE IF EXISTS `glpi_knowbaseitems_users`;
CREATE TABLE `glpi_knowbaseitems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitemtranslations

DROP TABLE IF EXISTS `glpi_knowbaseitemtranslations`;
CREATE TABLE `glpi_knowbaseitemtranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item` (`knowbaseitems_id`,`language`),
  KEY `users_id` (`users_id`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_lineoperators

DROP TABLE IF EXISTS `glpi_lineoperators`;
CREATE TABLE `glpi_lineoperators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci,
  `mcc` int(11) DEFAULT NULL,
  `mnc` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`mcc`,`mnc`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_lines

DROP TABLE IF EXISTS `glpi_lines`;
CREATE TABLE `glpi_lines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `caller_num` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `caller_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `lineoperators_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `linetypes_id` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `users_id` (`users_id`),
  KEY `lineoperators_id` (`lineoperators_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_linetypes

DROP TABLE IF EXISTS `glpi_linetypes`;
CREATE TABLE `glpi_linetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links

DROP TABLE IF EXISTS `glpi_links`;
CREATE TABLE `glpi_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `open_window` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links_itemtypes

DROP TABLE IF EXISTS `glpi_links_itemtypes`;
CREATE TABLE `glpi_links_itemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `links_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`links_id`),
  KEY `links_id` (`links_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_locations

DROP TABLE IF EXISTS `glpi_locations`;
CREATE TABLE `glpi_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `building` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `altitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`locations_id`,`name`),
  KEY `locations_id` (`locations_id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_logs

DROP TABLE IF EXISTS `glpi_logs`;
CREATE TABLE `glpi_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype_link` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `linked_action` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php HISTORY_* constant',
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `id_search_option` int(11) NOT NULL DEFAULT '0' COMMENT 'see search.constant.php for value',
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `itemtype_link` (`itemtype_link`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `id_search_option` (`id_search_option`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_logs` VALUES ('1','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','26','127','0');
INSERT INTO `glpi_logs` VALUES ('2','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','20','127','0');
INSERT INTO `glpi_logs` VALUES ('3','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','27','127','0');
INSERT INTO `glpi_logs` VALUES ('4','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','129','31','0');
INSERT INTO `glpi_logs` VALUES ('5','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','21','127','0');
INSERT INTO `glpi_logs` VALUES ('6','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','23','127','0');
INSERT INTO `glpi_logs` VALUES ('7','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','25','127','0');
INSERT INTO `glpi_logs` VALUES ('8','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','28','127','0');
INSERT INTO `glpi_logs` VALUES ('9','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','24','127','0');
INSERT INTO `glpi_logs` VALUES ('10','Profile','3','','0','glpi (2)','2018-04-10 08:29:36','22','127','0');
INSERT INTO `glpi_logs` VALUES ('11','Profile','3','','0','glpi (2)','2018-04-10 08:30:18','87','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('12','Profile','3','','0','glpi (2)','2018-04-10 08:30:18','115','1151','0');
INSERT INTO `glpi_logs` VALUES ('13','Profile','3','','0','glpi (2)','2018-04-10 08:30:18','79','3073','0');
INSERT INTO `glpi_logs` VALUES ('14','Profile','3','','0','glpi (2)','2018-04-10 08:30:18','112','1151','0');
INSERT INTO `glpi_logs` VALUES ('15','Profile','3','','0','glpi (2)','2018-04-10 08:30:18','85','1','0');
INSERT INTO `glpi_logs` VALUES ('16','Profile','3','','0','glpi (2)','2018-04-10 08:30:18','102','259103','0');
INSERT INTO `glpi_logs` VALUES ('17','Profile','3','','0','glpi (2)','2018-04-10 08:30:18','119','31','0');
INSERT INTO `glpi_logs` VALUES ('18','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','26','255','0');
INSERT INTO `glpi_logs` VALUES ('19','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','20','255','0');
INSERT INTO `glpi_logs` VALUES ('20','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','27','255','0');
INSERT INTO `glpi_logs` VALUES ('21','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','129','159','0');
INSERT INTO `glpi_logs` VALUES ('22','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','21','255','0');
INSERT INTO `glpi_logs` VALUES ('23','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','23','255','0');
INSERT INTO `glpi_logs` VALUES ('24','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','25','255','0');
INSERT INTO `glpi_logs` VALUES ('25','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','28','255','0');
INSERT INTO `glpi_logs` VALUES ('26','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','24','255','0');
INSERT INTO `glpi_logs` VALUES ('27','Profile','4','','0','glpi (2)','2018-04-10 08:31:52','22','255','0');
INSERT INTO `glpi_logs` VALUES ('28','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','87','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('29','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','115','1279','0');
INSERT INTO `glpi_logs` VALUES ('30','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','79','3073','0');
INSERT INTO `glpi_logs` VALUES ('31','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','112','1279','0');
INSERT INTO `glpi_logs` VALUES ('32','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','85','1','0');
INSERT INTO `glpi_logs` VALUES ('33','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','102','259231','0');
INSERT INTO `glpi_logs` VALUES ('34','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','119','31','0');
INSERT INTO `glpi_logs` VALUES ('35','Profile','4','','0','glpi (2)','2018-04-10 08:32:07','103','31','0');
INSERT INTO `glpi_logs` VALUES ('36','Profile','4','','0','glpi (2)','2018-04-10 08:35:12','101','255','0');
INSERT INTO `glpi_logs` VALUES ('37','Profile','4','','0','glpi (2)','2018-04-10 08:35:12','32','255','127');
INSERT INTO `glpi_logs` VALUES ('38','Profile','4','','0','glpi (2)','2018-04-10 08:35:12','31','255','127');
INSERT INTO `glpi_logs` VALUES ('39','Profile','4','','0','glpi (2)','2018-04-10 08:35:12','33','31','0');
INSERT INTO `glpi_logs` VALUES ('40','Supplier','1','0','20','glpi (2)','2018-04-10 08:36:33','0','','');
INSERT INTO `glpi_logs` VALUES ('41','User','6','Profile','17','glpi (2)','2018-04-10 11:39:51','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('42','User','6','0','20','glpi (2)','2018-04-10 11:39:51','0','','');
INSERT INTO `glpi_logs` VALUES ('43','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','backup (863)');
INSERT INTO `glpi_logs` VALUES ('44','ProfileRight','863','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('45','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','bookmark_public (864)');
INSERT INTO `glpi_logs` VALUES ('46','ProfileRight','864','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('47','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','budget (865)');
INSERT INTO `glpi_logs` VALUES ('48','ProfileRight','865','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('49','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','calendar (866)');
INSERT INTO `glpi_logs` VALUES ('50','ProfileRight','866','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('51','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','cartridge (867)');
INSERT INTO `glpi_logs` VALUES ('52','ProfileRight','867','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('53','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','certificate (868)');
INSERT INTO `glpi_logs` VALUES ('54','ProfileRight','868','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('55','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','change (869)');
INSERT INTO `glpi_logs` VALUES ('56','ProfileRight','869','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('57','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','changevalidation (870)');
INSERT INTO `glpi_logs` VALUES ('58','ProfileRight','870','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('59','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','computer (871)');
INSERT INTO `glpi_logs` VALUES ('60','ProfileRight','871','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('61','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','config (872)');
INSERT INTO `glpi_logs` VALUES ('62','ProfileRight','872','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('63','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','consumable (873)');
INSERT INTO `glpi_logs` VALUES ('64','ProfileRight','873','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('65','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','contact_enterprise (874)');
INSERT INTO `glpi_logs` VALUES ('66','ProfileRight','874','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('67','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','contract (875)');
INSERT INTO `glpi_logs` VALUES ('68','ProfileRight','875','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('69','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','device (876)');
INSERT INTO `glpi_logs` VALUES ('70','ProfileRight','876','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('71','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','devicesimcard_pinpuk (877)');
INSERT INTO `glpi_logs` VALUES ('72','ProfileRight','877','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('73','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','document (878)');
INSERT INTO `glpi_logs` VALUES ('74','ProfileRight','878','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('75','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','domain (879)');
INSERT INTO `glpi_logs` VALUES ('76','ProfileRight','879','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('77','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','dropdown (880)');
INSERT INTO `glpi_logs` VALUES ('78','ProfileRight','880','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('79','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','entity (881)');
INSERT INTO `glpi_logs` VALUES ('80','ProfileRight','881','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('81','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','followup (882)');
INSERT INTO `glpi_logs` VALUES ('82','ProfileRight','882','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('83','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','group (883)');
INSERT INTO `glpi_logs` VALUES ('84','ProfileRight','883','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('85','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','infocom (884)');
INSERT INTO `glpi_logs` VALUES ('86','ProfileRight','884','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('87','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','internet (885)');
INSERT INTO `glpi_logs` VALUES ('88','ProfileRight','885','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('89','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','itilcategory (886)');
INSERT INTO `glpi_logs` VALUES ('90','ProfileRight','886','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('91','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','knowbase (887)');
INSERT INTO `glpi_logs` VALUES ('92','ProfileRight','887','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('93','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','knowbasecategory (888)');
INSERT INTO `glpi_logs` VALUES ('94','ProfileRight','888','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('95','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','license (889)');
INSERT INTO `glpi_logs` VALUES ('96','ProfileRight','889','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('97','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','line (890)');
INSERT INTO `glpi_logs` VALUES ('98','ProfileRight','890','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('99','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','lineoperator (891)');
INSERT INTO `glpi_logs` VALUES ('100','ProfileRight','891','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('101','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','link (892)');
INSERT INTO `glpi_logs` VALUES ('102','ProfileRight','892','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('103','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','location (893)');
INSERT INTO `glpi_logs` VALUES ('104','ProfileRight','893','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('105','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','logs (894)');
INSERT INTO `glpi_logs` VALUES ('106','ProfileRight','894','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('107','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','monitor (895)');
INSERT INTO `glpi_logs` VALUES ('108','ProfileRight','895','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('109','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','netpoint (896)');
INSERT INTO `glpi_logs` VALUES ('110','ProfileRight','896','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('111','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','networking (897)');
INSERT INTO `glpi_logs` VALUES ('112','ProfileRight','897','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('113','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','notification (898)');
INSERT INTO `glpi_logs` VALUES ('114','ProfileRight','898','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('115','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','password_update (899)');
INSERT INTO `glpi_logs` VALUES ('116','ProfileRight','899','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('117','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','peripheral (900)');
INSERT INTO `glpi_logs` VALUES ('118','ProfileRight','900','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('119','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','phone (901)');
INSERT INTO `glpi_logs` VALUES ('120','ProfileRight','901','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('121','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','planning (902)');
INSERT INTO `glpi_logs` VALUES ('122','ProfileRight','902','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('123','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','printer (903)');
INSERT INTO `glpi_logs` VALUES ('124','ProfileRight','903','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('125','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','problem (904)');
INSERT INTO `glpi_logs` VALUES ('126','ProfileRight','904','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('127','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','profile (905)');
INSERT INTO `glpi_logs` VALUES ('128','ProfileRight','905','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('129','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','project (906)');
INSERT INTO `glpi_logs` VALUES ('130','ProfileRight','906','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('131','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','projecttask (907)');
INSERT INTO `glpi_logs` VALUES ('132','ProfileRight','907','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('133','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','queuednotification (908)');
INSERT INTO `glpi_logs` VALUES ('134','ProfileRight','908','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('135','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','reminder_public (909)');
INSERT INTO `glpi_logs` VALUES ('136','ProfileRight','909','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('137','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','reports (910)');
INSERT INTO `glpi_logs` VALUES ('138','ProfileRight','910','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('139','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','reservation (911)');
INSERT INTO `glpi_logs` VALUES ('140','ProfileRight','911','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('141','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rssfeed_public (912)');
INSERT INTO `glpi_logs` VALUES ('142','ProfileRight','912','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('143','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_dictionnary_dropdown (913)');
INSERT INTO `glpi_logs` VALUES ('144','ProfileRight','913','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('145','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_dictionnary_printer (914)');
INSERT INTO `glpi_logs` VALUES ('146','ProfileRight','914','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('147','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_dictionnary_software (915)');
INSERT INTO `glpi_logs` VALUES ('148','ProfileRight','915','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('149','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_import (916)');
INSERT INTO `glpi_logs` VALUES ('150','ProfileRight','916','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('151','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_ldap (917)');
INSERT INTO `glpi_logs` VALUES ('152','ProfileRight','917','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('153','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_mailcollector (918)');
INSERT INTO `glpi_logs` VALUES ('154','ProfileRight','918','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('155','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_softwarecategories (919)');
INSERT INTO `glpi_logs` VALUES ('156','ProfileRight','919','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('157','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','rule_ticket (920)');
INSERT INTO `glpi_logs` VALUES ('158','ProfileRight','920','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('159','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','search_config (921)');
INSERT INTO `glpi_logs` VALUES ('160','ProfileRight','921','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('161','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','show_group_hardware (922)');
INSERT INTO `glpi_logs` VALUES ('162','ProfileRight','922','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('163','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','slm (923)');
INSERT INTO `glpi_logs` VALUES ('164','ProfileRight','923','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('165','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','software (924)');
INSERT INTO `glpi_logs` VALUES ('166','ProfileRight','924','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('167','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','solutiontemplate (925)');
INSERT INTO `glpi_logs` VALUES ('168','ProfileRight','925','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('169','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','state (926)');
INSERT INTO `glpi_logs` VALUES ('170','ProfileRight','926','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('171','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','statistic (927)');
INSERT INTO `glpi_logs` VALUES ('172','ProfileRight','927','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('173','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','task (928)');
INSERT INTO `glpi_logs` VALUES ('174','ProfileRight','928','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('175','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','taskcategory (929)');
INSERT INTO `glpi_logs` VALUES ('176','ProfileRight','929','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('177','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','ticket (930)');
INSERT INTO `glpi_logs` VALUES ('178','ProfileRight','930','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('179','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','ticketcost (931)');
INSERT INTO `glpi_logs` VALUES ('180','ProfileRight','931','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('181','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','ticketrecurrent (932)');
INSERT INTO `glpi_logs` VALUES ('182','ProfileRight','932','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('183','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','tickettemplate (933)');
INSERT INTO `glpi_logs` VALUES ('184','ProfileRight','933','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('185','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','ticketvalidation (934)');
INSERT INTO `glpi_logs` VALUES ('186','ProfileRight','934','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('187','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','transfer (935)');
INSERT INTO `glpi_logs` VALUES ('188','ProfileRight','935','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('189','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','typedoc (936)');
INSERT INTO `glpi_logs` VALUES ('190','ProfileRight','936','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('191','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','user (937)');
INSERT INTO `glpi_logs` VALUES ('192','ProfileRight','937','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('193','Profile','9','ProfileRight','17','glpi (2)','2018-04-10 11:41:05','0','','global_validation (938)');
INSERT INTO `glpi_logs` VALUES ('194','ProfileRight','938','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('195','Profile','9','0','20','glpi (2)','2018-04-10 11:41:05','0','','');
INSERT INTO `glpi_logs` VALUES ('196','User','6','Profile','17','glpi (2)','2018-04-10 11:41:46','0','','proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('197','User','6','Profile','19','glpi (2)','2018-04-10 11:41:53','0','Self-Service (1)','');
INSERT INTO `glpi_logs` VALUES ('198','Profile','9','','0','glpi (2)','2018-04-10 11:45:21','108','&nbsp; (0)','Default (1)');
INSERT INTO `glpi_logs` VALUES ('199','Profile','9','','0','glpi (2)','2018-04-10 11:45:21','87','','[]');
INSERT INTO `glpi_logs` VALUES ('200','Profile','9','','0','glpi (2)','2018-04-10 11:45:21','102','0','2053');
INSERT INTO `glpi_logs` VALUES ('201','Profile','9','','0','glpi (2)','2018-04-10 11:46:27','102','2053','4');
INSERT INTO `glpi_logs` VALUES ('202','Profile','9','','0','glpi (2)','2018-04-10 13:59:35','118','0','1');
INSERT INTO `glpi_logs` VALUES ('203','Profile','9','','0','glpi (2)','2018-04-10 13:59:38','118','1','0');
INSERT INTO `glpi_logs` VALUES ('204','Profile','9','','0','glpi (2)','2018-04-10 13:59:47','102','4','0');
INSERT INTO `glpi_logs` VALUES ('205','Document','1','Supplier','15','glpi (2)','2018-04-11 11:58:14','0','','CONSTRUCCIONES ATILIANO Y ANTONIO (1)');
INSERT INTO `glpi_logs` VALUES ('206','Supplier','1','Document','15','glpi (2)','2018-04-11 11:58:14','0','','Documento: Proveedor - CONSTRUCCIONES ATILIANO Y ANTONIO (1)');
INSERT INTO `glpi_logs` VALUES ('207','Document','1','0','20','glpi (2)','2018-04-11 11:58:14','0','','');
INSERT INTO `glpi_logs` VALUES ('208','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 09:25:56','0','plugin_appliances (942)','');
INSERT INTO `glpi_logs` VALUES ('209','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 09:25:56','0','','plugin_appliances (957)');
INSERT INTO `glpi_logs` VALUES ('210','ProfileRight','957','0','20','glpi (2)','2018-04-12 09:25:56','0','','');
INSERT INTO `glpi_logs` VALUES ('211','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 09:25:56','0','plugin_appliances_open_ticket (951)','');
INSERT INTO `glpi_logs` VALUES ('212','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 09:25:56','0','','plugin_appliances_open_ticket (958)');
INSERT INTO `glpi_logs` VALUES ('213','ProfileRight','958','0','20','glpi (2)','2018-04-12 09:25:56','0','','');
INSERT INTO `glpi_logs` VALUES ('214','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 11:16:30','0','plugin_comproveedores (962)','');
INSERT INTO `glpi_logs` VALUES ('215','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 11:16:30','0','','plugin_comproveedores (977)');
INSERT INTO `glpi_logs` VALUES ('220','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 11:33:00','0','plugin_comproveedores (977)','');
INSERT INTO `glpi_logs` VALUES ('217','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 11:16:30','0','plugin_comproveedores_open_ticket (971)','');
INSERT INTO `glpi_logs` VALUES ('218','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 11:16:30','0','','plugin_comproveedores_open_ticket (978)');
INSERT INTO `glpi_logs` VALUES ('223','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 11:33:00','0','plugin_comproveedores_open_ticket (978)','');
INSERT INTO `glpi_logs` VALUES ('221','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 11:33:00','0','','plugin_comproveedores (979)');
INSERT INTO `glpi_logs` VALUES ('226','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 12:12:50','0','plugin_comproveedores (979)','');
INSERT INTO `glpi_logs` VALUES ('224','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 11:33:00','0','','plugin_comproveedores_open_ticket (980)');
INSERT INTO `glpi_logs` VALUES ('229','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 12:12:50','0','plugin_comproveedores_open_ticket (980)','');
INSERT INTO `glpi_logs` VALUES ('227','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 12:12:50','0','','plugin_comproveedores (981)');
INSERT INTO `glpi_logs` VALUES ('233','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 12:38:54','0','plugin_comproveedores (981)','');
INSERT INTO `glpi_logs` VALUES ('230','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 12:12:50','0','','plugin_comproveedores_open_ticket (982)');
INSERT INTO `glpi_logs` VALUES ('236','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 12:38:54','0','plugin_comproveedores_open_ticket (982)','');
INSERT INTO `glpi_logs` VALUES ('232','User','2','','0','glpi (2)','2018-04-12 12:20:37','20','&nbsp; (0)','Super-Admin (4)');
INSERT INTO `glpi_logs` VALUES ('234','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 12:38:54','0','','plugin_comproveedores (984)');
INSERT INTO `glpi_logs` VALUES ('241','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 13:20:34','0','plugin_comproveedores (984)','');
INSERT INTO `glpi_logs` VALUES ('237','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 12:38:54','0','','plugin_comproveedores_open_ticket (985)');
INSERT INTO `glpi_logs` VALUES ('244','Profile','4','ProfileRight','19','glpi (2)','2018-04-12 13:20:34','0','plugin_comproveedores_open_ticket (985)','');
INSERT INTO `glpi_logs` VALUES ('239','State','1','0','20','glpi (2)','2018-04-12 12:59:03','0','','');
INSERT INTO `glpi_logs` VALUES ('240','KnowbaseItem','1','0','20','glpi (2)','2018-04-12 13:14:15','0','','');
INSERT INTO `glpi_logs` VALUES ('242','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 13:20:34','0','','plugin_comproveedores (986)');
INSERT INTO `glpi_logs` VALUES ('247','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 08:28:44','0','plugin_comproveedores (986)','');
INSERT INTO `glpi_logs` VALUES ('245','Profile','4','ProfileRight','17','glpi (2)','2018-04-12 13:20:34','0','','plugin_comproveedores_open_ticket (987)');
INSERT INTO `glpi_logs` VALUES ('250','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 08:28:44','0','plugin_comproveedores_open_ticket (987)','');
INSERT INTO `glpi_logs` VALUES ('248','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 08:28:44','0','','plugin_comproveedores (988)');
INSERT INTO `glpi_logs` VALUES ('253','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 09:05:04','0','plugin_comproveedores (988)','');
INSERT INTO `glpi_logs` VALUES ('251','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 08:28:44','0','','plugin_comproveedores_open_ticket (989)');
INSERT INTO `glpi_logs` VALUES ('256','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 09:05:04','0','plugin_comproveedores_open_ticket (989)','');
INSERT INTO `glpi_logs` VALUES ('254','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 09:05:04','0','','plugin_comproveedores (990)');
INSERT INTO `glpi_logs` VALUES ('261','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 09:18:47','0','plugin_comproveedores (990)','');
INSERT INTO `glpi_logs` VALUES ('257','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 09:05:04','0','','plugin_comproveedores_open_ticket (991)');
INSERT INTO `glpi_logs` VALUES ('264','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 09:18:47','0','plugin_comproveedores_open_ticket (991)','');
INSERT INTO `glpi_logs` VALUES ('259','User','7','Profile','17','glpi (2)','2018-04-13 09:05:56','0','','proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('260','User','7','0','20','glpi (2)','2018-04-13 09:05:56','0','','');
INSERT INTO `glpi_logs` VALUES ('262','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 09:18:47','0','','plugin_comproveedores (992)');
INSERT INTO `glpi_logs` VALUES ('267','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 09:19:44','0','plugin_comproveedores (992)','');
INSERT INTO `glpi_logs` VALUES ('265','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 09:18:47','0','','plugin_comproveedores_open_ticket (993)');
INSERT INTO `glpi_logs` VALUES ('270','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 09:19:44','0','plugin_comproveedores_open_ticket (993)','');
INSERT INTO `glpi_logs` VALUES ('268','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 09:19:44','0','','plugin_comproveedores (994)');
INSERT INTO `glpi_logs` VALUES ('287','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 12:38:53','0','plugin_comproveedores (994)','');
INSERT INTO `glpi_logs` VALUES ('271','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 09:19:44','0','','plugin_comproveedores_open_ticket (995)');
INSERT INTO `glpi_logs` VALUES ('290','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 12:38:53','0','plugin_comproveedores_open_ticket (995)','');
INSERT INTO `glpi_logs` VALUES ('273','Profile','9','','0','glpi (2)','2018-04-13 09:31:54','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('274','Profile','9','','0','glpi (2)','2018-04-13 09:33:05','2','central','helpdesk');
INSERT INTO `glpi_logs` VALUES ('275','Profile','9','','0','glpi (2)','2018-04-13 10:19:03','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('276','Profile','9','','0','glpi (2)','2018-04-13 10:19:39','118','0','1');
INSERT INTO `glpi_logs` VALUES ('277','Profile','9','','0','glpi (2)','2018-04-13 10:19:39','201','1','0');
INSERT INTO `glpi_logs` VALUES ('278','Profile','9','','0','glpi (2)','2018-04-13 11:06:55','118','1','0');
INSERT INTO `glpi_logs` VALUES ('279','Profile','9','','0','glpi (2)','2018-04-13 11:06:55','201','0','1');
INSERT INTO `glpi_logs` VALUES ('280','Profile','9','','0','glpi (2)','2018-04-13 11:35:56','2','central','helpdesk');
INSERT INTO `glpi_logs` VALUES ('281','Profile','9','','0','glpi (2)','2018-04-13 11:36:08','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('282','Profile','9','','0','glpi (2)','2018-04-13 12:29:28','2','central','helpdesk');
INSERT INTO `glpi_logs` VALUES ('283','Profile','9','','0','glpi (2)','2018-04-13 12:30:18','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('284','Profile','9','','0','glpi (2)','2018-04-13 12:32:22','102','0','13');
INSERT INTO `glpi_logs` VALUES ('285','Profile','9','','0','glpi (2)','2018-04-13 12:34:01','102','13','0');
INSERT INTO `glpi_logs` VALUES ('286','Profile','9','','0','glpi (2)','2018-04-13 12:34:34','1','proveedores','Proveedores');
INSERT INTO `glpi_logs` VALUES ('288','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 12:38:53','0','','plugin_comproveedores (996)');
INSERT INTO `glpi_logs` VALUES ('293','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 12:50:37','0','plugin_comproveedores (996)','');
INSERT INTO `glpi_logs` VALUES ('291','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 12:38:53','0','','plugin_comproveedores_open_ticket (997)');
INSERT INTO `glpi_logs` VALUES ('296','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 12:50:37','0','plugin_comproveedores_open_ticket (997)','');
INSERT INTO `glpi_logs` VALUES ('294','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 12:50:37','0','','plugin_comproveedores (998)');
INSERT INTO `glpi_logs` VALUES ('299','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 13:11:28','0','plugin_comproveedores (998)','');
INSERT INTO `glpi_logs` VALUES ('297','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 12:50:37','0','','plugin_comproveedores_open_ticket (999)');
INSERT INTO `glpi_logs` VALUES ('302','Profile','4','ProfileRight','19','glpi (2)','2018-04-13 13:11:28','0','plugin_comproveedores_open_ticket (999)','');
INSERT INTO `glpi_logs` VALUES ('300','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 13:11:28','0','','plugin_comproveedores (1000)');
INSERT INTO `glpi_logs` VALUES ('310','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:50:54','0','plugin_comproveedores (1000)','');
INSERT INTO `glpi_logs` VALUES ('303','Profile','4','ProfileRight','17','glpi (2)','2018-04-13 13:11:28','0','','plugin_comproveedores_open_ticket (1001)');
INSERT INTO `glpi_logs` VALUES ('313','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:50:54','0','plugin_comproveedores_open_ticket (1001)','');
INSERT INTO `glpi_logs` VALUES ('305','Reminder','1','0','20','juan (7)','2018-04-13 13:26:02','0','','');
INSERT INTO `glpi_logs` VALUES ('306','Reminder','1','','0','juan (7)','2018-04-13 13:26:38','5','','2018-04-02 00:00');
INSERT INTO `glpi_logs` VALUES ('307','Reminder','1','','0','juan (7)','2018-04-13 13:26:38','6','','2026-04-15 00:00');
INSERT INTO `glpi_logs` VALUES ('308','Reminder','1','','0','juan (7)','2018-04-13 13:26:59','1','Nueva nota','Construcción del Hospital');
INSERT INTO `glpi_logs` VALUES ('309','User','7','','0','glpi (2)','2018-04-16 14:49:27','20','&nbsp; (0)','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('311','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:50:54','0','','plugin_comproveedores (1002)');
INSERT INTO `glpi_logs` VALUES ('316','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:53:10','0','plugin_comproveedores (1002)','');
INSERT INTO `glpi_logs` VALUES ('314','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:50:54','0','','plugin_comproveedores_open_ticket (1003)');
INSERT INTO `glpi_logs` VALUES ('319','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:53:10','0','plugin_comproveedores_open_ticket (1003)','');
INSERT INTO `glpi_logs` VALUES ('317','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:53:10','0','','plugin_comproveedores (1004)');
INSERT INTO `glpi_logs` VALUES ('322','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:55:33','0','plugin_comproveedores (1004)','');
INSERT INTO `glpi_logs` VALUES ('320','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:53:10','0','','plugin_comproveedores_open_ticket (1005)');
INSERT INTO `glpi_logs` VALUES ('325','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:55:33','0','plugin_comproveedores_open_ticket (1005)','');
INSERT INTO `glpi_logs` VALUES ('323','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:55:33','0','','plugin_comproveedores (1006)');
INSERT INTO `glpi_logs` VALUES ('328','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:56:23','0','plugin_comproveedores (1006)','');
INSERT INTO `glpi_logs` VALUES ('326','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:55:33','0','','plugin_comproveedores_open_ticket (1007)');
INSERT INTO `glpi_logs` VALUES ('331','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:56:23','0','plugin_comproveedores_open_ticket (1007)','');
INSERT INTO `glpi_logs` VALUES ('329','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:56:23','0','','plugin_comproveedores (1008)');
INSERT INTO `glpi_logs` VALUES ('334','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:58:29','0','plugin_comproveedores (1008)','');
INSERT INTO `glpi_logs` VALUES ('332','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:56:23','0','','plugin_comproveedores_open_ticket (1009)');
INSERT INTO `glpi_logs` VALUES ('337','Profile','4','ProfileRight','19','glpi (2)','2018-04-16 14:58:29','0','plugin_comproveedores_open_ticket (1009)','');
INSERT INTO `glpi_logs` VALUES ('335','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:58:29','0','','plugin_comproveedores (1010)');
INSERT INTO `glpi_logs` VALUES ('555','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 08:12:03','0','plugin_comproveedores (1010)','');
INSERT INTO `glpi_logs` VALUES ('338','Profile','4','ProfileRight','17','glpi (2)','2018-04-16 14:58:29','0','','plugin_comproveedores_open_ticket (1011)');
INSERT INTO `glpi_logs` VALUES ('558','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 08:12:03','0','plugin_comproveedores_open_ticket (1011)','');
INSERT INTO `glpi_logs` VALUES ('340','Profile','9','','0','glpi (2)','2018-04-17 08:10:44','201','0','1');
INSERT INTO `glpi_logs` VALUES ('341','User','8','Profile','17','glpi (2)','2018-04-17 08:24:44','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('342','User','8','0','20','glpi (2)','2018-04-17 08:24:44','0','','');
INSERT INTO `glpi_logs` VALUES ('343','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','backup (1012)');
INSERT INTO `glpi_logs` VALUES ('344','ProfileRight','1012','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('345','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','bookmark_public (1013)');
INSERT INTO `glpi_logs` VALUES ('346','ProfileRight','1013','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('347','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','budget (1014)');
INSERT INTO `glpi_logs` VALUES ('348','ProfileRight','1014','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('349','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','calendar (1015)');
INSERT INTO `glpi_logs` VALUES ('350','ProfileRight','1015','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('351','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','cartridge (1016)');
INSERT INTO `glpi_logs` VALUES ('352','ProfileRight','1016','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('353','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','certificate (1017)');
INSERT INTO `glpi_logs` VALUES ('354','ProfileRight','1017','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('355','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','change (1018)');
INSERT INTO `glpi_logs` VALUES ('356','ProfileRight','1018','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('357','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','changevalidation (1019)');
INSERT INTO `glpi_logs` VALUES ('358','ProfileRight','1019','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('359','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','computer (1020)');
INSERT INTO `glpi_logs` VALUES ('360','ProfileRight','1020','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('361','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','config (1021)');
INSERT INTO `glpi_logs` VALUES ('362','ProfileRight','1021','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('363','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','consumable (1022)');
INSERT INTO `glpi_logs` VALUES ('364','ProfileRight','1022','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('365','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','contact_enterprise (1023)');
INSERT INTO `glpi_logs` VALUES ('366','ProfileRight','1023','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('367','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','contract (1024)');
INSERT INTO `glpi_logs` VALUES ('368','ProfileRight','1024','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('369','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','device (1025)');
INSERT INTO `glpi_logs` VALUES ('370','ProfileRight','1025','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('371','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','devicesimcard_pinpuk (1026)');
INSERT INTO `glpi_logs` VALUES ('372','ProfileRight','1026','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('373','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','document (1027)');
INSERT INTO `glpi_logs` VALUES ('374','ProfileRight','1027','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('375','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','domain (1028)');
INSERT INTO `glpi_logs` VALUES ('376','ProfileRight','1028','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('377','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','dropdown (1029)');
INSERT INTO `glpi_logs` VALUES ('378','ProfileRight','1029','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('379','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','entity (1030)');
INSERT INTO `glpi_logs` VALUES ('380','ProfileRight','1030','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('381','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','followup (1031)');
INSERT INTO `glpi_logs` VALUES ('382','ProfileRight','1031','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('383','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','group (1032)');
INSERT INTO `glpi_logs` VALUES ('384','ProfileRight','1032','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('385','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','infocom (1033)');
INSERT INTO `glpi_logs` VALUES ('386','ProfileRight','1033','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('387','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','internet (1034)');
INSERT INTO `glpi_logs` VALUES ('388','ProfileRight','1034','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('389','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','itilcategory (1035)');
INSERT INTO `glpi_logs` VALUES ('390','ProfileRight','1035','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('391','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','knowbase (1036)');
INSERT INTO `glpi_logs` VALUES ('392','ProfileRight','1036','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('393','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','knowbasecategory (1037)');
INSERT INTO `glpi_logs` VALUES ('394','ProfileRight','1037','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('395','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','license (1038)');
INSERT INTO `glpi_logs` VALUES ('396','ProfileRight','1038','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('397','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','line (1039)');
INSERT INTO `glpi_logs` VALUES ('398','ProfileRight','1039','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('399','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','lineoperator (1040)');
INSERT INTO `glpi_logs` VALUES ('400','ProfileRight','1040','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('401','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','link (1041)');
INSERT INTO `glpi_logs` VALUES ('402','ProfileRight','1041','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('403','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','location (1042)');
INSERT INTO `glpi_logs` VALUES ('404','ProfileRight','1042','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('405','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','logs (1043)');
INSERT INTO `glpi_logs` VALUES ('406','ProfileRight','1043','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('407','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','monitor (1044)');
INSERT INTO `glpi_logs` VALUES ('408','ProfileRight','1044','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('409','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','netpoint (1045)');
INSERT INTO `glpi_logs` VALUES ('410','ProfileRight','1045','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('411','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','networking (1046)');
INSERT INTO `glpi_logs` VALUES ('412','ProfileRight','1046','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('413','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','notification (1047)');
INSERT INTO `glpi_logs` VALUES ('414','ProfileRight','1047','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('415','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','password_update (1048)');
INSERT INTO `glpi_logs` VALUES ('416','ProfileRight','1048','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('417','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','peripheral (1049)');
INSERT INTO `glpi_logs` VALUES ('418','ProfileRight','1049','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('419','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','phone (1050)');
INSERT INTO `glpi_logs` VALUES ('420','ProfileRight','1050','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('421','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','planning (1051)');
INSERT INTO `glpi_logs` VALUES ('422','ProfileRight','1051','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('423','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','plugin_appliances (1052)');
INSERT INTO `glpi_logs` VALUES ('424','ProfileRight','1052','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('425','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','plugin_appliances_open_ticket (1053)');
INSERT INTO `glpi_logs` VALUES ('426','ProfileRight','1053','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('427','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','plugin_comproveedores (1054)');
INSERT INTO `glpi_logs` VALUES ('428','ProfileRight','1054','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('429','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','plugin_comproveedores_open_ticket (1055)');
INSERT INTO `glpi_logs` VALUES ('430','ProfileRight','1055','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('431','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','printer (1056)');
INSERT INTO `glpi_logs` VALUES ('432','ProfileRight','1056','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('433','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','problem (1057)');
INSERT INTO `glpi_logs` VALUES ('434','ProfileRight','1057','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('435','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','profile (1058)');
INSERT INTO `glpi_logs` VALUES ('436','ProfileRight','1058','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('437','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','project (1059)');
INSERT INTO `glpi_logs` VALUES ('438','ProfileRight','1059','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('439','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','projecttask (1060)');
INSERT INTO `glpi_logs` VALUES ('440','ProfileRight','1060','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('441','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','queuednotification (1061)');
INSERT INTO `glpi_logs` VALUES ('442','ProfileRight','1061','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('443','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','reminder_public (1062)');
INSERT INTO `glpi_logs` VALUES ('444','ProfileRight','1062','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('445','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','reports (1063)');
INSERT INTO `glpi_logs` VALUES ('446','ProfileRight','1063','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('447','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','reservation (1064)');
INSERT INTO `glpi_logs` VALUES ('448','ProfileRight','1064','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('449','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rssfeed_public (1065)');
INSERT INTO `glpi_logs` VALUES ('450','ProfileRight','1065','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('451','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_dictionnary_dropdown (1066)');
INSERT INTO `glpi_logs` VALUES ('452','ProfileRight','1066','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('453','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_dictionnary_printer (1067)');
INSERT INTO `glpi_logs` VALUES ('454','ProfileRight','1067','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('455','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_dictionnary_software (1068)');
INSERT INTO `glpi_logs` VALUES ('456','ProfileRight','1068','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('457','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_import (1069)');
INSERT INTO `glpi_logs` VALUES ('458','ProfileRight','1069','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('459','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_ldap (1070)');
INSERT INTO `glpi_logs` VALUES ('460','ProfileRight','1070','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('461','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_mailcollector (1071)');
INSERT INTO `glpi_logs` VALUES ('462','ProfileRight','1071','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('463','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_softwarecategories (1072)');
INSERT INTO `glpi_logs` VALUES ('464','ProfileRight','1072','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('465','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','rule_ticket (1073)');
INSERT INTO `glpi_logs` VALUES ('466','ProfileRight','1073','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('467','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','search_config (1074)');
INSERT INTO `glpi_logs` VALUES ('468','ProfileRight','1074','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('469','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','show_group_hardware (1075)');
INSERT INTO `glpi_logs` VALUES ('470','ProfileRight','1075','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('471','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','slm (1076)');
INSERT INTO `glpi_logs` VALUES ('472','ProfileRight','1076','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('473','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','software (1077)');
INSERT INTO `glpi_logs` VALUES ('474','ProfileRight','1077','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('475','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','solutiontemplate (1078)');
INSERT INTO `glpi_logs` VALUES ('476','ProfileRight','1078','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('477','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','state (1079)');
INSERT INTO `glpi_logs` VALUES ('478','ProfileRight','1079','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('479','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','statistic (1080)');
INSERT INTO `glpi_logs` VALUES ('480','ProfileRight','1080','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('481','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','task (1081)');
INSERT INTO `glpi_logs` VALUES ('482','ProfileRight','1081','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('483','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','taskcategory (1082)');
INSERT INTO `glpi_logs` VALUES ('484','ProfileRight','1082','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('485','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','ticket (1083)');
INSERT INTO `glpi_logs` VALUES ('486','ProfileRight','1083','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('487','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','ticketcost (1084)');
INSERT INTO `glpi_logs` VALUES ('488','ProfileRight','1084','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('489','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','ticketrecurrent (1085)');
INSERT INTO `glpi_logs` VALUES ('490','ProfileRight','1085','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('491','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','tickettemplate (1086)');
INSERT INTO `glpi_logs` VALUES ('492','ProfileRight','1086','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('493','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','ticketvalidation (1087)');
INSERT INTO `glpi_logs` VALUES ('494','ProfileRight','1087','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('495','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','transfer (1088)');
INSERT INTO `glpi_logs` VALUES ('496','ProfileRight','1088','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('497','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','typedoc (1089)');
INSERT INTO `glpi_logs` VALUES ('498','ProfileRight','1089','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('499','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','user (1090)');
INSERT INTO `glpi_logs` VALUES ('500','ProfileRight','1090','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('501','Profile','10','ProfileRight','17','glpi (2)','2018-04-17 08:25:43','0','','global_validation (1091)');
INSERT INTO `glpi_logs` VALUES ('502','ProfileRight','1091','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('503','Profile','10','0','20','glpi (2)','2018-04-17 08:25:43','0','','');
INSERT INTO `glpi_logs` VALUES ('504','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','26','0','127');
INSERT INTO `glpi_logs` VALUES ('505','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','20','0','127');
INSERT INTO `glpi_logs` VALUES ('506','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','27','0','127');
INSERT INTO `glpi_logs` VALUES ('507','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','129','0','31');
INSERT INTO `glpi_logs` VALUES ('508','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','21','0','127');
INSERT INTO `glpi_logs` VALUES ('509','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','23','0','127');
INSERT INTO `glpi_logs` VALUES ('510','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','25','0','127');
INSERT INTO `glpi_logs` VALUES ('511','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','28','0','127');
INSERT INTO `glpi_logs` VALUES ('512','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','24','0','127');
INSERT INTO `glpi_logs` VALUES ('513','Profile','10','','0','glpi (2)','2018-04-17 08:26:21','22','0','127');
INSERT INTO `glpi_logs` VALUES ('514','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','86','0','3');
INSERT INTO `glpi_logs` VALUES ('515','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','87','','[]');
INSERT INTO `glpi_logs` VALUES ('516','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','115','0','1151');
INSERT INTO `glpi_logs` VALUES ('517','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','79','0','3073');
INSERT INTO `glpi_logs` VALUES ('518','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','112','0','1151');
INSERT INTO `glpi_logs` VALUES ('519','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','85','0','1');
INSERT INTO `glpi_logs` VALUES ('520','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','102','0','261151');
INSERT INTO `glpi_logs` VALUES ('521','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','119','0','23');
INSERT INTO `glpi_logs` VALUES ('522','Profile','10','','0','glpi (2)','2018-04-17 08:26:43','103','0','23');
INSERT INTO `glpi_logs` VALUES ('523','Profile','10','','0','glpi (2)','2018-04-17 08:26:50','101','0','127');
INSERT INTO `glpi_logs` VALUES ('524','Profile','10','','0','glpi (2)','2018-04-17 08:26:50','32','0','127');
INSERT INTO `glpi_logs` VALUES ('525','Profile','10','','0','glpi (2)','2018-04-17 08:26:50','31','0','127');
INSERT INTO `glpi_logs` VALUES ('526','Profile','10','','0','glpi (2)','2018-04-17 08:26:50','33','0','23');
INSERT INTO `glpi_logs` VALUES ('527','Profile','10','','0','glpi (2)','2018-04-17 08:26:58','64','0','23');
INSERT INTO `glpi_logs` VALUES ('528','Profile','10','','0','glpi (2)','2018-04-17 08:26:58','34','0','15383');
INSERT INTO `glpi_logs` VALUES ('529','Profile','10','','0','glpi (2)','2018-04-17 08:26:58','63','0','23');
INSERT INTO `glpi_logs` VALUES ('530','Profile','10','','0','glpi (2)','2018-04-17 08:26:58','38','0','1');
INSERT INTO `glpi_logs` VALUES ('531','Profile','10','','0','glpi (2)','2018-04-17 08:26:58','36','0','1055');
INSERT INTO `glpi_logs` VALUES ('532','Profile','10','','0','glpi (2)','2018-04-17 08:26:58','120','0','23');
INSERT INTO `glpi_logs` VALUES ('533','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','62','0','1045');
INSERT INTO `glpi_logs` VALUES ('534','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','59','0','3191');
INSERT INTO `glpi_logs` VALUES ('535','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','58','0','119');
INSERT INTO `glpi_logs` VALUES ('536','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','61','0','1');
INSERT INTO `glpi_logs` VALUES ('537','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','55','0','23');
INSERT INTO `glpi_logs` VALUES ('538','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','91','0','23');
INSERT INTO `glpi_logs` VALUES ('539','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','90','0','23');
INSERT INTO `glpi_logs` VALUES ('540','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','49','0','23');
INSERT INTO `glpi_logs` VALUES ('541','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','50','0','23');
INSERT INTO `glpi_logs` VALUES ('542','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','105','0','23');
INSERT INTO `glpi_logs` VALUES ('543','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','51','0','23');
INSERT INTO `glpi_logs` VALUES ('544','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','48','0','1047');
INSERT INTO `glpi_logs` VALUES ('545','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','60','0','23');
INSERT INTO `glpi_logs` VALUES ('546','Profile','10','','0','glpi (2)','2018-04-17 08:27:06','56','0','7199');
INSERT INTO `glpi_logs` VALUES ('547','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','107','0','23');
INSERT INTO `glpi_logs` VALUES ('548','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','47','0','3');
INSERT INTO `glpi_logs` VALUES ('549','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','44','0','23');
INSERT INTO `glpi_logs` VALUES ('550','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','42','0','23');
INSERT INTO `glpi_logs` VALUES ('551','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','46','0','23');
INSERT INTO `glpi_logs` VALUES ('552','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','106','0','23');
INSERT INTO `glpi_logs` VALUES ('553','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','52','0','3072');
INSERT INTO `glpi_logs` VALUES ('554','Profile','10','','0','glpi (2)','2018-04-17 08:27:20','45','0','23');
INSERT INTO `glpi_logs` VALUES ('556','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 08:12:03','0','','plugin_comproveedores (1092)');
INSERT INTO `glpi_logs` VALUES ('561','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 11:06:02','0','plugin_comproveedores (1092)','');
INSERT INTO `glpi_logs` VALUES ('559','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 08:12:03','0','','plugin_comproveedores_open_ticket (1093)');
INSERT INTO `glpi_logs` VALUES ('564','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 11:06:02','0','plugin_comproveedores_open_ticket (1093)','');
INSERT INTO `glpi_logs` VALUES ('562','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 11:06:02','0','','plugin_comproveedores (1094)');
INSERT INTO `glpi_logs` VALUES ('567','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 11:07:42','0','plugin_comproveedores (1094)','');
INSERT INTO `glpi_logs` VALUES ('565','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 11:06:02','0','','plugin_comproveedores_open_ticket (1095)');
INSERT INTO `glpi_logs` VALUES ('570','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 11:07:42','0','plugin_comproveedores_open_ticket (1095)','');
INSERT INTO `glpi_logs` VALUES ('568','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 11:07:42','0','','plugin_comproveedores (1096)');
INSERT INTO `glpi_logs` VALUES ('573','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 11:14:36','0','plugin_comproveedores (1096)','');
INSERT INTO `glpi_logs` VALUES ('571','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 11:07:42','0','','plugin_comproveedores_open_ticket (1097)');
INSERT INTO `glpi_logs` VALUES ('576','Profile','4','ProfileRight','19','glpi (2)','2018-04-18 11:14:36','0','plugin_comproveedores_open_ticket (1097)','');
INSERT INTO `glpi_logs` VALUES ('574','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 11:14:36','0','','plugin_comproveedores (1098)');
INSERT INTO `glpi_logs` VALUES ('755','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 13:34:18','0','plugin_comproveedores (1098)','');
INSERT INTO `glpi_logs` VALUES ('577','Profile','4','ProfileRight','17','glpi (2)','2018-04-18 11:14:36','0','','plugin_comproveedores_open_ticket (1099)');
INSERT INTO `glpi_logs` VALUES ('758','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 13:34:18','0','plugin_comproveedores_open_ticket (1099)','');
INSERT INTO `glpi_logs` VALUES ('579','UserTitle','1','0','20','glpi (2)','2018-04-19 08:16:17','0','','');
INSERT INTO `glpi_logs` VALUES ('580','User','7','','0','glpi (2)','2018-04-19 08:16:22','81','&nbsp; (0)','Director Geneal (1)');
INSERT INTO `glpi_logs` VALUES ('581','UserTitle','2','0','20','glpi (2)','2018-04-19 08:18:00','0','','');
INSERT INTO `glpi_logs` VALUES ('582','User','9','Profile','17','glpi (2)','2018-04-19 08:18:25','0','','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('583','User','9','0','20','glpi (2)','2018-04-19 08:18:25','0','','');
INSERT INTO `glpi_logs` VALUES ('584','User','9','','0','glpi (2)','2018-04-19 08:19:02','20','&nbsp; (0)','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('585','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','backup (1100)');
INSERT INTO `glpi_logs` VALUES ('586','ProfileRight','1100','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('587','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','bookmark_public (1101)');
INSERT INTO `glpi_logs` VALUES ('588','ProfileRight','1101','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('589','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','budget (1102)');
INSERT INTO `glpi_logs` VALUES ('590','ProfileRight','1102','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('591','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','calendar (1103)');
INSERT INTO `glpi_logs` VALUES ('592','ProfileRight','1103','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('593','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','cartridge (1104)');
INSERT INTO `glpi_logs` VALUES ('594','ProfileRight','1104','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('595','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','certificate (1105)');
INSERT INTO `glpi_logs` VALUES ('596','ProfileRight','1105','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('597','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','change (1106)');
INSERT INTO `glpi_logs` VALUES ('598','ProfileRight','1106','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('599','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','changevalidation (1107)');
INSERT INTO `glpi_logs` VALUES ('600','ProfileRight','1107','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('601','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','computer (1108)');
INSERT INTO `glpi_logs` VALUES ('602','ProfileRight','1108','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('603','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','config (1109)');
INSERT INTO `glpi_logs` VALUES ('604','ProfileRight','1109','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('605','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','consumable (1110)');
INSERT INTO `glpi_logs` VALUES ('606','ProfileRight','1110','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('607','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','contact_enterprise (1111)');
INSERT INTO `glpi_logs` VALUES ('608','ProfileRight','1111','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('609','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','contract (1112)');
INSERT INTO `glpi_logs` VALUES ('610','ProfileRight','1112','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('611','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','device (1113)');
INSERT INTO `glpi_logs` VALUES ('612','ProfileRight','1113','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('613','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','devicesimcard_pinpuk (1114)');
INSERT INTO `glpi_logs` VALUES ('614','ProfileRight','1114','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('615','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','document (1115)');
INSERT INTO `glpi_logs` VALUES ('616','ProfileRight','1115','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('617','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','domain (1116)');
INSERT INTO `glpi_logs` VALUES ('618','ProfileRight','1116','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('619','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','dropdown (1117)');
INSERT INTO `glpi_logs` VALUES ('620','ProfileRight','1117','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('621','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','entity (1118)');
INSERT INTO `glpi_logs` VALUES ('622','ProfileRight','1118','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('623','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','followup (1119)');
INSERT INTO `glpi_logs` VALUES ('624','ProfileRight','1119','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('625','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','group (1120)');
INSERT INTO `glpi_logs` VALUES ('626','ProfileRight','1120','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('627','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','infocom (1121)');
INSERT INTO `glpi_logs` VALUES ('628','ProfileRight','1121','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('629','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','internet (1122)');
INSERT INTO `glpi_logs` VALUES ('630','ProfileRight','1122','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('631','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','itilcategory (1123)');
INSERT INTO `glpi_logs` VALUES ('632','ProfileRight','1123','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('633','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','knowbase (1124)');
INSERT INTO `glpi_logs` VALUES ('634','ProfileRight','1124','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('635','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','knowbasecategory (1125)');
INSERT INTO `glpi_logs` VALUES ('636','ProfileRight','1125','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('637','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','license (1126)');
INSERT INTO `glpi_logs` VALUES ('638','ProfileRight','1126','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('639','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','line (1127)');
INSERT INTO `glpi_logs` VALUES ('640','ProfileRight','1127','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('641','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','lineoperator (1128)');
INSERT INTO `glpi_logs` VALUES ('642','ProfileRight','1128','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('643','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','link (1129)');
INSERT INTO `glpi_logs` VALUES ('644','ProfileRight','1129','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('645','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','location (1130)');
INSERT INTO `glpi_logs` VALUES ('646','ProfileRight','1130','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('647','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','logs (1131)');
INSERT INTO `glpi_logs` VALUES ('648','ProfileRight','1131','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('649','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','monitor (1132)');
INSERT INTO `glpi_logs` VALUES ('650','ProfileRight','1132','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('651','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','netpoint (1133)');
INSERT INTO `glpi_logs` VALUES ('652','ProfileRight','1133','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('653','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','networking (1134)');
INSERT INTO `glpi_logs` VALUES ('654','ProfileRight','1134','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('655','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','notification (1135)');
INSERT INTO `glpi_logs` VALUES ('656','ProfileRight','1135','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('657','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','password_update (1136)');
INSERT INTO `glpi_logs` VALUES ('658','ProfileRight','1136','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('659','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','peripheral (1137)');
INSERT INTO `glpi_logs` VALUES ('660','ProfileRight','1137','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('661','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','phone (1138)');
INSERT INTO `glpi_logs` VALUES ('662','ProfileRight','1138','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('663','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','planning (1139)');
INSERT INTO `glpi_logs` VALUES ('664','ProfileRight','1139','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('665','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','plugin_appliances (1140)');
INSERT INTO `glpi_logs` VALUES ('666','ProfileRight','1140','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('667','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','plugin_appliances_open_ticket (1141)');
INSERT INTO `glpi_logs` VALUES ('668','ProfileRight','1141','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('669','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','plugin_comproveedores (1142)');
INSERT INTO `glpi_logs` VALUES ('670','ProfileRight','1142','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('671','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','plugin_comproveedores_open_ticket (1143)');
INSERT INTO `glpi_logs` VALUES ('672','ProfileRight','1143','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('673','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','printer (1144)');
INSERT INTO `glpi_logs` VALUES ('674','ProfileRight','1144','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('675','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','problem (1145)');
INSERT INTO `glpi_logs` VALUES ('676','ProfileRight','1145','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('677','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','profile (1146)');
INSERT INTO `glpi_logs` VALUES ('678','ProfileRight','1146','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('679','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','project (1147)');
INSERT INTO `glpi_logs` VALUES ('680','ProfileRight','1147','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('681','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','projecttask (1148)');
INSERT INTO `glpi_logs` VALUES ('682','ProfileRight','1148','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('683','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','queuednotification (1149)');
INSERT INTO `glpi_logs` VALUES ('684','ProfileRight','1149','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('685','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','reminder_public (1150)');
INSERT INTO `glpi_logs` VALUES ('686','ProfileRight','1150','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('687','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','reports (1151)');
INSERT INTO `glpi_logs` VALUES ('688','ProfileRight','1151','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('689','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','reservation (1152)');
INSERT INTO `glpi_logs` VALUES ('690','ProfileRight','1152','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('691','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rssfeed_public (1153)');
INSERT INTO `glpi_logs` VALUES ('692','ProfileRight','1153','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('693','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_dictionnary_dropdown (1154)');
INSERT INTO `glpi_logs` VALUES ('694','ProfileRight','1154','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('695','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_dictionnary_printer (1155)');
INSERT INTO `glpi_logs` VALUES ('696','ProfileRight','1155','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('697','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_dictionnary_software (1156)');
INSERT INTO `glpi_logs` VALUES ('698','ProfileRight','1156','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('699','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_import (1157)');
INSERT INTO `glpi_logs` VALUES ('700','ProfileRight','1157','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('701','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_ldap (1158)');
INSERT INTO `glpi_logs` VALUES ('702','ProfileRight','1158','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('703','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_mailcollector (1159)');
INSERT INTO `glpi_logs` VALUES ('704','ProfileRight','1159','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('705','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_softwarecategories (1160)');
INSERT INTO `glpi_logs` VALUES ('706','ProfileRight','1160','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('707','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','rule_ticket (1161)');
INSERT INTO `glpi_logs` VALUES ('708','ProfileRight','1161','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('709','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','search_config (1162)');
INSERT INTO `glpi_logs` VALUES ('710','ProfileRight','1162','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('711','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','show_group_hardware (1163)');
INSERT INTO `glpi_logs` VALUES ('712','ProfileRight','1163','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('713','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','slm (1164)');
INSERT INTO `glpi_logs` VALUES ('714','ProfileRight','1164','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('715','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','software (1165)');
INSERT INTO `glpi_logs` VALUES ('716','ProfileRight','1165','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('717','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','solutiontemplate (1166)');
INSERT INTO `glpi_logs` VALUES ('718','ProfileRight','1166','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('719','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','state (1167)');
INSERT INTO `glpi_logs` VALUES ('720','ProfileRight','1167','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('721','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','statistic (1168)');
INSERT INTO `glpi_logs` VALUES ('722','ProfileRight','1168','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('723','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','task (1169)');
INSERT INTO `glpi_logs` VALUES ('724','ProfileRight','1169','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('725','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','taskcategory (1170)');
INSERT INTO `glpi_logs` VALUES ('726','ProfileRight','1170','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('727','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','ticket (1171)');
INSERT INTO `glpi_logs` VALUES ('728','ProfileRight','1171','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('729','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','ticketcost (1172)');
INSERT INTO `glpi_logs` VALUES ('730','ProfileRight','1172','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('731','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','ticketrecurrent (1173)');
INSERT INTO `glpi_logs` VALUES ('732','ProfileRight','1173','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('733','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','tickettemplate (1174)');
INSERT INTO `glpi_logs` VALUES ('734','ProfileRight','1174','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('735','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','ticketvalidation (1175)');
INSERT INTO `glpi_logs` VALUES ('736','ProfileRight','1175','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('737','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','transfer (1176)');
INSERT INTO `glpi_logs` VALUES ('738','ProfileRight','1176','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('739','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','typedoc (1177)');
INSERT INTO `glpi_logs` VALUES ('740','ProfileRight','1177','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('741','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','user (1178)');
INSERT INTO `glpi_logs` VALUES ('742','ProfileRight','1178','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('743','Profile','11','ProfileRight','17','glpi (2)','2018-04-19 08:22:55','0','','global_validation (1179)');
INSERT INTO `glpi_logs` VALUES ('744','ProfileRight','1179','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('745','Profile','11','0','20','glpi (2)','2018-04-19 08:22:55','0','','');
INSERT INTO `glpi_logs` VALUES ('746','Profile','11','','0','glpi (2)','2018-04-19 08:23:12','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('747','Profile','11','','0','glpi (2)','2018-04-19 08:23:17','2','central','helpdesk');
INSERT INTO `glpi_logs` VALUES ('748','Profile','11','','0','glpi (2)','2018-04-19 08:23:23','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('749','Profile','11','','0','glpi (2)','2018-04-19 08:23:31','20','0','127');
INSERT INTO `glpi_logs` VALUES ('750','User','9','Profile','17','glpi (2)','2018-04-19 08:24:04','0','','perfil prueba 1 (11)');
INSERT INTO `glpi_logs` VALUES ('751','User','9','Profile','19','glpi (2)','2018-04-19 08:24:16','0','perfil prueba 1 (11)','');
INSERT INTO `glpi_logs` VALUES ('752','User','9','Profile','17','glpi (2)','2018-04-19 08:24:26','0','','perfil prueba 1 (11)');
INSERT INTO `glpi_logs` VALUES ('753','User','9','','0','glpi (2)','2018-04-19 08:24:31','20','Proveedores (9)','perfil prueba 1 (11)');
INSERT INTO `glpi_logs` VALUES ('754','User','9','','0','glpi (2)','2018-04-19 08:25:05','20','perfil prueba 1 (11)','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('756','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 13:34:18','0','','plugin_comproveedores (1180)');
INSERT INTO `glpi_logs` VALUES ('761','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 13:40:08','0','plugin_comproveedores (1180)','');
INSERT INTO `glpi_logs` VALUES ('759','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 13:34:18','0','','plugin_comproveedores_open_ticket (1181)');
INSERT INTO `glpi_logs` VALUES ('764','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 13:40:08','0','plugin_comproveedores_open_ticket (1181)','');
INSERT INTO `glpi_logs` VALUES ('762','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 13:40:08','0','','plugin_comproveedores (1182)');
INSERT INTO `glpi_logs` VALUES ('767','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 13:48:37','0','plugin_comproveedores (1182)','');
INSERT INTO `glpi_logs` VALUES ('765','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 13:40:08','0','','plugin_comproveedores_open_ticket (1183)');
INSERT INTO `glpi_logs` VALUES ('770','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 13:48:37','0','plugin_comproveedores_open_ticket (1183)','');
INSERT INTO `glpi_logs` VALUES ('768','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 13:48:37','0','','plugin_comproveedores (1184)');
INSERT INTO `glpi_logs` VALUES ('773','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 14:16:51','0','plugin_comproveedores (1184)','');
INSERT INTO `glpi_logs` VALUES ('771','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 13:48:37','0','','plugin_comproveedores_open_ticket (1185)');
INSERT INTO `glpi_logs` VALUES ('776','Profile','4','ProfileRight','19','glpi (2)','2018-04-20 14:16:51','0','plugin_comproveedores_open_ticket (1185)','');
INSERT INTO `glpi_logs` VALUES ('774','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 14:16:51','0','','plugin_comproveedores (1186)');
INSERT INTO `glpi_logs` VALUES ('1190','Profile','4','ProfileRight','19','glpi (2)','2018-04-26 08:37:20','0','plugin_comproveedores (1186)','');
INSERT INTO `glpi_logs` VALUES ('777','Profile','4','ProfileRight','17','glpi (2)','2018-04-20 14:16:51','0','','plugin_comproveedores_open_ticket (1187)');
INSERT INTO `glpi_logs` VALUES ('1193','Profile','4','ProfileRight','19','glpi (2)','2018-04-26 08:37:20','0','plugin_comproveedores_open_ticket (1187)','');
INSERT INTO `glpi_logs` VALUES ('779','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','backup (1188)');
INSERT INTO `glpi_logs` VALUES ('780','ProfileRight','1188','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('781','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','bookmark_public (1189)');
INSERT INTO `glpi_logs` VALUES ('782','ProfileRight','1189','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('783','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','budget (1190)');
INSERT INTO `glpi_logs` VALUES ('784','ProfileRight','1190','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('785','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','calendar (1191)');
INSERT INTO `glpi_logs` VALUES ('786','ProfileRight','1191','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('787','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','cartridge (1192)');
INSERT INTO `glpi_logs` VALUES ('788','ProfileRight','1192','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('789','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','certificate (1193)');
INSERT INTO `glpi_logs` VALUES ('790','ProfileRight','1193','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('791','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','change (1194)');
INSERT INTO `glpi_logs` VALUES ('792','ProfileRight','1194','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('793','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','changevalidation (1195)');
INSERT INTO `glpi_logs` VALUES ('794','ProfileRight','1195','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('795','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','computer (1196)');
INSERT INTO `glpi_logs` VALUES ('796','ProfileRight','1196','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('797','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','config (1197)');
INSERT INTO `glpi_logs` VALUES ('798','ProfileRight','1197','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('799','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','consumable (1198)');
INSERT INTO `glpi_logs` VALUES ('800','ProfileRight','1198','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('801','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','contact_enterprise (1199)');
INSERT INTO `glpi_logs` VALUES ('802','ProfileRight','1199','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('803','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','contract (1200)');
INSERT INTO `glpi_logs` VALUES ('804','ProfileRight','1200','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('805','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','device (1201)');
INSERT INTO `glpi_logs` VALUES ('806','ProfileRight','1201','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('807','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','devicesimcard_pinpuk (1202)');
INSERT INTO `glpi_logs` VALUES ('808','ProfileRight','1202','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('809','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','document (1203)');
INSERT INTO `glpi_logs` VALUES ('810','ProfileRight','1203','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('811','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','domain (1204)');
INSERT INTO `glpi_logs` VALUES ('812','ProfileRight','1204','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('813','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','dropdown (1205)');
INSERT INTO `glpi_logs` VALUES ('814','ProfileRight','1205','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('815','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','entity (1206)');
INSERT INTO `glpi_logs` VALUES ('816','ProfileRight','1206','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('817','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','followup (1207)');
INSERT INTO `glpi_logs` VALUES ('818','ProfileRight','1207','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('819','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','group (1208)');
INSERT INTO `glpi_logs` VALUES ('820','ProfileRight','1208','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('821','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','infocom (1209)');
INSERT INTO `glpi_logs` VALUES ('822','ProfileRight','1209','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('823','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','internet (1210)');
INSERT INTO `glpi_logs` VALUES ('824','ProfileRight','1210','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('825','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','itilcategory (1211)');
INSERT INTO `glpi_logs` VALUES ('826','ProfileRight','1211','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('827','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','knowbase (1212)');
INSERT INTO `glpi_logs` VALUES ('828','ProfileRight','1212','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('829','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','knowbasecategory (1213)');
INSERT INTO `glpi_logs` VALUES ('830','ProfileRight','1213','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('831','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','license (1214)');
INSERT INTO `glpi_logs` VALUES ('832','ProfileRight','1214','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('833','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','line (1215)');
INSERT INTO `glpi_logs` VALUES ('834','ProfileRight','1215','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('835','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','lineoperator (1216)');
INSERT INTO `glpi_logs` VALUES ('836','ProfileRight','1216','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('837','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','link (1217)');
INSERT INTO `glpi_logs` VALUES ('838','ProfileRight','1217','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('839','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','location (1218)');
INSERT INTO `glpi_logs` VALUES ('840','ProfileRight','1218','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('841','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','logs (1219)');
INSERT INTO `glpi_logs` VALUES ('842','ProfileRight','1219','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('843','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','monitor (1220)');
INSERT INTO `glpi_logs` VALUES ('844','ProfileRight','1220','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('845','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','netpoint (1221)');
INSERT INTO `glpi_logs` VALUES ('846','ProfileRight','1221','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('847','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','networking (1222)');
INSERT INTO `glpi_logs` VALUES ('848','ProfileRight','1222','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('849','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','notification (1223)');
INSERT INTO `glpi_logs` VALUES ('850','ProfileRight','1223','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('851','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','password_update (1224)');
INSERT INTO `glpi_logs` VALUES ('852','ProfileRight','1224','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('853','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','peripheral (1225)');
INSERT INTO `glpi_logs` VALUES ('854','ProfileRight','1225','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('855','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','phone (1226)');
INSERT INTO `glpi_logs` VALUES ('856','ProfileRight','1226','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('857','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','planning (1227)');
INSERT INTO `glpi_logs` VALUES ('858','ProfileRight','1227','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('859','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','plugin_appliances (1228)');
INSERT INTO `glpi_logs` VALUES ('860','ProfileRight','1228','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('861','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','plugin_appliances_open_ticket (1229)');
INSERT INTO `glpi_logs` VALUES ('862','ProfileRight','1229','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('863','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','plugin_comproveedores (1230)');
INSERT INTO `glpi_logs` VALUES ('864','ProfileRight','1230','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('865','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','plugin_comproveedores_open_ticket (1231)');
INSERT INTO `glpi_logs` VALUES ('866','ProfileRight','1231','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('867','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','printer (1232)');
INSERT INTO `glpi_logs` VALUES ('868','ProfileRight','1232','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('869','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','problem (1233)');
INSERT INTO `glpi_logs` VALUES ('870','ProfileRight','1233','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('871','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','profile (1234)');
INSERT INTO `glpi_logs` VALUES ('872','ProfileRight','1234','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('873','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','project (1235)');
INSERT INTO `glpi_logs` VALUES ('874','ProfileRight','1235','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('875','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','projecttask (1236)');
INSERT INTO `glpi_logs` VALUES ('876','ProfileRight','1236','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('877','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','queuednotification (1237)');
INSERT INTO `glpi_logs` VALUES ('878','ProfileRight','1237','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('879','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','reminder_public (1238)');
INSERT INTO `glpi_logs` VALUES ('880','ProfileRight','1238','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('881','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','reports (1239)');
INSERT INTO `glpi_logs` VALUES ('882','ProfileRight','1239','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('883','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','reservation (1240)');
INSERT INTO `glpi_logs` VALUES ('884','ProfileRight','1240','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('885','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rssfeed_public (1241)');
INSERT INTO `glpi_logs` VALUES ('886','ProfileRight','1241','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('887','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_dictionnary_dropdown (1242)');
INSERT INTO `glpi_logs` VALUES ('888','ProfileRight','1242','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('889','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_dictionnary_printer (1243)');
INSERT INTO `glpi_logs` VALUES ('890','ProfileRight','1243','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('891','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_dictionnary_software (1244)');
INSERT INTO `glpi_logs` VALUES ('892','ProfileRight','1244','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('893','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_import (1245)');
INSERT INTO `glpi_logs` VALUES ('894','ProfileRight','1245','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('895','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_ldap (1246)');
INSERT INTO `glpi_logs` VALUES ('896','ProfileRight','1246','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('897','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_mailcollector (1247)');
INSERT INTO `glpi_logs` VALUES ('898','ProfileRight','1247','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('899','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_softwarecategories (1248)');
INSERT INTO `glpi_logs` VALUES ('900','ProfileRight','1248','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('901','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','rule_ticket (1249)');
INSERT INTO `glpi_logs` VALUES ('902','ProfileRight','1249','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('903','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','search_config (1250)');
INSERT INTO `glpi_logs` VALUES ('904','ProfileRight','1250','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('905','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','show_group_hardware (1251)');
INSERT INTO `glpi_logs` VALUES ('906','ProfileRight','1251','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('907','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','slm (1252)');
INSERT INTO `glpi_logs` VALUES ('908','ProfileRight','1252','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('909','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','software (1253)');
INSERT INTO `glpi_logs` VALUES ('910','ProfileRight','1253','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('911','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','solutiontemplate (1254)');
INSERT INTO `glpi_logs` VALUES ('912','ProfileRight','1254','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('913','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','state (1255)');
INSERT INTO `glpi_logs` VALUES ('914','ProfileRight','1255','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('915','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','statistic (1256)');
INSERT INTO `glpi_logs` VALUES ('916','ProfileRight','1256','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('917','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','task (1257)');
INSERT INTO `glpi_logs` VALUES ('918','ProfileRight','1257','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('919','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','taskcategory (1258)');
INSERT INTO `glpi_logs` VALUES ('920','ProfileRight','1258','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('921','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','ticket (1259)');
INSERT INTO `glpi_logs` VALUES ('922','ProfileRight','1259','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('923','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','ticketcost (1260)');
INSERT INTO `glpi_logs` VALUES ('924','ProfileRight','1260','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('925','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','ticketrecurrent (1261)');
INSERT INTO `glpi_logs` VALUES ('926','ProfileRight','1261','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('927','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','tickettemplate (1262)');
INSERT INTO `glpi_logs` VALUES ('928','ProfileRight','1262','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('929','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','ticketvalidation (1263)');
INSERT INTO `glpi_logs` VALUES ('930','ProfileRight','1263','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('931','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','transfer (1264)');
INSERT INTO `glpi_logs` VALUES ('932','ProfileRight','1264','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('933','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','typedoc (1265)');
INSERT INTO `glpi_logs` VALUES ('934','ProfileRight','1265','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('935','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','user (1266)');
INSERT INTO `glpi_logs` VALUES ('936','ProfileRight','1266','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('937','Profile','12','ProfileRight','17','glpi (2)','2018-04-20 14:17:26','0','','global_validation (1267)');
INSERT INTO `glpi_logs` VALUES ('938','ProfileRight','1267','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('939','Profile','12','0','20','glpi (2)','2018-04-20 14:17:26','0','','');
INSERT INTO `glpi_logs` VALUES ('940','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','26','0','127');
INSERT INTO `glpi_logs` VALUES ('941','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','20','0','127');
INSERT INTO `glpi_logs` VALUES ('942','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','27','0','127');
INSERT INTO `glpi_logs` VALUES ('943','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','129','0','31');
INSERT INTO `glpi_logs` VALUES ('944','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','21','0','127');
INSERT INTO `glpi_logs` VALUES ('945','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','23','0','127');
INSERT INTO `glpi_logs` VALUES ('946','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','25','0','127');
INSERT INTO `glpi_logs` VALUES ('947','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','28','0','127');
INSERT INTO `glpi_logs` VALUES ('948','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','24','0','127');
INSERT INTO `glpi_logs` VALUES ('949','Profile','12','','0','glpi (2)','2018-04-20 14:17:37','22','0','127');
INSERT INTO `glpi_logs` VALUES ('950','Profile','12','','0','glpi (2)','2018-04-20 14:18:11','32','0','127');
INSERT INTO `glpi_logs` VALUES ('951','Profile','12','','0','glpi (2)','2018-04-20 14:18:11','31','0','127');
INSERT INTO `glpi_logs` VALUES ('952','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','26','127','0');
INSERT INTO `glpi_logs` VALUES ('953','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','20','127','0');
INSERT INTO `glpi_logs` VALUES ('954','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','27','127','0');
INSERT INTO `glpi_logs` VALUES ('955','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','129','31','0');
INSERT INTO `glpi_logs` VALUES ('956','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','21','127','0');
INSERT INTO `glpi_logs` VALUES ('957','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','23','127','0');
INSERT INTO `glpi_logs` VALUES ('958','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','25','127','0');
INSERT INTO `glpi_logs` VALUES ('959','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','28','127','0');
INSERT INTO `glpi_logs` VALUES ('960','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','24','127','0');
INSERT INTO `glpi_logs` VALUES ('961','Profile','12','','0','glpi (2)','2018-04-20 14:19:08','22','127','0');
INSERT INTO `glpi_logs` VALUES ('962','Profile','12','','0','glpi (2)','2018-04-20 14:20:03','64','0','23');
INSERT INTO `glpi_logs` VALUES ('963','Profile','12','','0','glpi (2)','2018-04-20 14:20:03','34','0','15383');
INSERT INTO `glpi_logs` VALUES ('964','Profile','12','','0','glpi (2)','2018-04-20 14:20:03','63','0','23');
INSERT INTO `glpi_logs` VALUES ('965','Profile','12','','0','glpi (2)','2018-04-20 14:20:03','120','0','23');
INSERT INTO `glpi_logs` VALUES ('966','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','62','0','1045');
INSERT INTO `glpi_logs` VALUES ('967','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','59','0','3191');
INSERT INTO `glpi_logs` VALUES ('968','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','58','0','119');
INSERT INTO `glpi_logs` VALUES ('969','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','61','0','1');
INSERT INTO `glpi_logs` VALUES ('970','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','55','0','23');
INSERT INTO `glpi_logs` VALUES ('971','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','91','0','23');
INSERT INTO `glpi_logs` VALUES ('972','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','90','0','23');
INSERT INTO `glpi_logs` VALUES ('973','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','49','0','23');
INSERT INTO `glpi_logs` VALUES ('974','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','50','0','23');
INSERT INTO `glpi_logs` VALUES ('975','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','105','0','23');
INSERT INTO `glpi_logs` VALUES ('976','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','51','0','23');
INSERT INTO `glpi_logs` VALUES ('977','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','48','0','1047');
INSERT INTO `glpi_logs` VALUES ('978','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','60','0','23');
INSERT INTO `glpi_logs` VALUES ('979','Profile','12','','0','glpi (2)','2018-04-20 14:20:25','56','0','7199');
INSERT INTO `glpi_logs` VALUES ('980','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','107','0','23');
INSERT INTO `glpi_logs` VALUES ('981','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','47','0','3');
INSERT INTO `glpi_logs` VALUES ('982','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','44','0','23');
INSERT INTO `glpi_logs` VALUES ('983','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','42','0','23');
INSERT INTO `glpi_logs` VALUES ('984','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','46','0','23');
INSERT INTO `glpi_logs` VALUES ('985','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','106','0','23');
INSERT INTO `glpi_logs` VALUES ('986','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','52','0','3072');
INSERT INTO `glpi_logs` VALUES ('987','Profile','12','','0','glpi (2)','2018-04-20 14:20:34','45','0','23');
INSERT INTO `glpi_logs` VALUES ('988','Profile','12','','0','glpi (2)','2018-04-20 14:21:14','1','tec1','Tecnico_Bovis');
INSERT INTO `glpi_logs` VALUES ('989','User','10','Profile','17','glpi (2)','2018-04-20 14:22:18','0','','Tecnico_Bovis (12)');
INSERT INTO `glpi_logs` VALUES ('990','User','10','0','20','glpi (2)','2018-04-20 14:22:18','0','','');
INSERT INTO `glpi_logs` VALUES ('991','User','10','','0','glpi (2)','2018-04-20 14:22:29','20','&nbsp; (0)','Tecnico_Bovis (12)');
INSERT INTO `glpi_logs` VALUES ('992','User','6','','0','glpi (2)','2018-04-20 14:22:50','20','&nbsp; (0)','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('993','Supplier','2','0','20','glpi (2)','2018-04-20 14:37:22','0','','');
INSERT INTO `glpi_logs` VALUES ('994','User','11','Profile','17','glpi (2)','2018-04-23 11:30:28','0','','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('995','User','11','0','20','glpi (2)','2018-04-23 11:30:28','0','','');
INSERT INTO `glpi_logs` VALUES ('996','User','12','Profile','17','glpi (2)','2018-04-23 12:10:37','0','','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('997','User','12','0','20','glpi (2)','2018-04-23 12:10:37','0','','');
INSERT INTO `glpi_logs` VALUES ('998','User','12','','0','glpi (2)','2018-04-23 12:11:05','20','&nbsp; (0)','Proveedores (9)');
INSERT INTO `glpi_logs` VALUES ('999','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','backup (1268)');
INSERT INTO `glpi_logs` VALUES ('1000','ProfileRight','1268','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1001','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','bookmark_public (1269)');
INSERT INTO `glpi_logs` VALUES ('1002','ProfileRight','1269','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1003','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','budget (1270)');
INSERT INTO `glpi_logs` VALUES ('1004','ProfileRight','1270','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1005','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','calendar (1271)');
INSERT INTO `glpi_logs` VALUES ('1006','ProfileRight','1271','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1007','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','cartridge (1272)');
INSERT INTO `glpi_logs` VALUES ('1008','ProfileRight','1272','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1009','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','certificate (1273)');
INSERT INTO `glpi_logs` VALUES ('1010','ProfileRight','1273','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1011','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','change (1274)');
INSERT INTO `glpi_logs` VALUES ('1012','ProfileRight','1274','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1013','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','changevalidation (1275)');
INSERT INTO `glpi_logs` VALUES ('1014','ProfileRight','1275','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1015','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','computer (1276)');
INSERT INTO `glpi_logs` VALUES ('1016','ProfileRight','1276','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1017','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','config (1277)');
INSERT INTO `glpi_logs` VALUES ('1018','ProfileRight','1277','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1019','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','consumable (1278)');
INSERT INTO `glpi_logs` VALUES ('1020','ProfileRight','1278','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1021','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','contact_enterprise (1279)');
INSERT INTO `glpi_logs` VALUES ('1022','ProfileRight','1279','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1023','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','contract (1280)');
INSERT INTO `glpi_logs` VALUES ('1024','ProfileRight','1280','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1025','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','device (1281)');
INSERT INTO `glpi_logs` VALUES ('1026','ProfileRight','1281','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1027','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','devicesimcard_pinpuk (1282)');
INSERT INTO `glpi_logs` VALUES ('1028','ProfileRight','1282','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1029','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','document (1283)');
INSERT INTO `glpi_logs` VALUES ('1030','ProfileRight','1283','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1031','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','domain (1284)');
INSERT INTO `glpi_logs` VALUES ('1032','ProfileRight','1284','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1033','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','dropdown (1285)');
INSERT INTO `glpi_logs` VALUES ('1034','ProfileRight','1285','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1035','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','entity (1286)');
INSERT INTO `glpi_logs` VALUES ('1036','ProfileRight','1286','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1037','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','followup (1287)');
INSERT INTO `glpi_logs` VALUES ('1038','ProfileRight','1287','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1039','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','group (1288)');
INSERT INTO `glpi_logs` VALUES ('1040','ProfileRight','1288','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1041','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','infocom (1289)');
INSERT INTO `glpi_logs` VALUES ('1042','ProfileRight','1289','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1043','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','internet (1290)');
INSERT INTO `glpi_logs` VALUES ('1044','ProfileRight','1290','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1045','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','itilcategory (1291)');
INSERT INTO `glpi_logs` VALUES ('1046','ProfileRight','1291','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1047','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','knowbase (1292)');
INSERT INTO `glpi_logs` VALUES ('1048','ProfileRight','1292','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1049','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','knowbasecategory (1293)');
INSERT INTO `glpi_logs` VALUES ('1050','ProfileRight','1293','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1051','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','license (1294)');
INSERT INTO `glpi_logs` VALUES ('1052','ProfileRight','1294','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1053','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','line (1295)');
INSERT INTO `glpi_logs` VALUES ('1054','ProfileRight','1295','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1055','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','lineoperator (1296)');
INSERT INTO `glpi_logs` VALUES ('1056','ProfileRight','1296','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1057','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','link (1297)');
INSERT INTO `glpi_logs` VALUES ('1058','ProfileRight','1297','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1059','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','location (1298)');
INSERT INTO `glpi_logs` VALUES ('1060','ProfileRight','1298','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1061','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','logs (1299)');
INSERT INTO `glpi_logs` VALUES ('1062','ProfileRight','1299','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1063','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','monitor (1300)');
INSERT INTO `glpi_logs` VALUES ('1064','ProfileRight','1300','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1065','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','netpoint (1301)');
INSERT INTO `glpi_logs` VALUES ('1066','ProfileRight','1301','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1067','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','networking (1302)');
INSERT INTO `glpi_logs` VALUES ('1068','ProfileRight','1302','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1069','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','notification (1303)');
INSERT INTO `glpi_logs` VALUES ('1070','ProfileRight','1303','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1071','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','password_update (1304)');
INSERT INTO `glpi_logs` VALUES ('1072','ProfileRight','1304','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1073','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','peripheral (1305)');
INSERT INTO `glpi_logs` VALUES ('1074','ProfileRight','1305','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1075','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','phone (1306)');
INSERT INTO `glpi_logs` VALUES ('1076','ProfileRight','1306','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1077','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','planning (1307)');
INSERT INTO `glpi_logs` VALUES ('1078','ProfileRight','1307','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1079','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','plugin_appliances (1308)');
INSERT INTO `glpi_logs` VALUES ('1080','ProfileRight','1308','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1081','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','plugin_appliances_open_ticket (1309)');
INSERT INTO `glpi_logs` VALUES ('1082','ProfileRight','1309','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1083','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','plugin_comproveedores (1310)');
INSERT INTO `glpi_logs` VALUES ('1084','ProfileRight','1310','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1085','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','plugin_comproveedores_open_ticket (1311)');
INSERT INTO `glpi_logs` VALUES ('1086','ProfileRight','1311','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1087','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','printer (1312)');
INSERT INTO `glpi_logs` VALUES ('1088','ProfileRight','1312','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1089','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','problem (1313)');
INSERT INTO `glpi_logs` VALUES ('1090','ProfileRight','1313','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1091','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','profile (1314)');
INSERT INTO `glpi_logs` VALUES ('1092','ProfileRight','1314','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1093','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','project (1315)');
INSERT INTO `glpi_logs` VALUES ('1094','ProfileRight','1315','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1095','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','projecttask (1316)');
INSERT INTO `glpi_logs` VALUES ('1096','ProfileRight','1316','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1097','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','queuednotification (1317)');
INSERT INTO `glpi_logs` VALUES ('1098','ProfileRight','1317','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1099','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','reminder_public (1318)');
INSERT INTO `glpi_logs` VALUES ('1100','ProfileRight','1318','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1101','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','reports (1319)');
INSERT INTO `glpi_logs` VALUES ('1102','ProfileRight','1319','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1103','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','reservation (1320)');
INSERT INTO `glpi_logs` VALUES ('1104','ProfileRight','1320','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1105','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rssfeed_public (1321)');
INSERT INTO `glpi_logs` VALUES ('1106','ProfileRight','1321','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1107','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_dictionnary_dropdown (1322)');
INSERT INTO `glpi_logs` VALUES ('1108','ProfileRight','1322','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1109','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_dictionnary_printer (1323)');
INSERT INTO `glpi_logs` VALUES ('1110','ProfileRight','1323','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1111','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_dictionnary_software (1324)');
INSERT INTO `glpi_logs` VALUES ('1112','ProfileRight','1324','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1113','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_import (1325)');
INSERT INTO `glpi_logs` VALUES ('1114','ProfileRight','1325','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1115','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_ldap (1326)');
INSERT INTO `glpi_logs` VALUES ('1116','ProfileRight','1326','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1117','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_mailcollector (1327)');
INSERT INTO `glpi_logs` VALUES ('1118','ProfileRight','1327','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1119','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_softwarecategories (1328)');
INSERT INTO `glpi_logs` VALUES ('1120','ProfileRight','1328','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1121','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','rule_ticket (1329)');
INSERT INTO `glpi_logs` VALUES ('1122','ProfileRight','1329','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1123','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','search_config (1330)');
INSERT INTO `glpi_logs` VALUES ('1124','ProfileRight','1330','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1125','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','show_group_hardware (1331)');
INSERT INTO `glpi_logs` VALUES ('1126','ProfileRight','1331','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1127','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','slm (1332)');
INSERT INTO `glpi_logs` VALUES ('1128','ProfileRight','1332','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1129','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','software (1333)');
INSERT INTO `glpi_logs` VALUES ('1130','ProfileRight','1333','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1131','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','solutiontemplate (1334)');
INSERT INTO `glpi_logs` VALUES ('1132','ProfileRight','1334','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1133','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','state (1335)');
INSERT INTO `glpi_logs` VALUES ('1134','ProfileRight','1335','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1135','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','statistic (1336)');
INSERT INTO `glpi_logs` VALUES ('1136','ProfileRight','1336','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1137','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','task (1337)');
INSERT INTO `glpi_logs` VALUES ('1138','ProfileRight','1337','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1139','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','taskcategory (1338)');
INSERT INTO `glpi_logs` VALUES ('1140','ProfileRight','1338','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1141','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','ticket (1339)');
INSERT INTO `glpi_logs` VALUES ('1142','ProfileRight','1339','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1143','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','ticketcost (1340)');
INSERT INTO `glpi_logs` VALUES ('1144','ProfileRight','1340','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1145','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','ticketrecurrent (1341)');
INSERT INTO `glpi_logs` VALUES ('1146','ProfileRight','1341','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1147','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','tickettemplate (1342)');
INSERT INTO `glpi_logs` VALUES ('1148','ProfileRight','1342','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1149','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','ticketvalidation (1343)');
INSERT INTO `glpi_logs` VALUES ('1150','ProfileRight','1343','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1151','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','transfer (1344)');
INSERT INTO `glpi_logs` VALUES ('1152','ProfileRight','1344','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1153','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','typedoc (1345)');
INSERT INTO `glpi_logs` VALUES ('1154','ProfileRight','1345','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1155','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','user (1346)');
INSERT INTO `glpi_logs` VALUES ('1156','ProfileRight','1346','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1157','Profile','13','ProfileRight','17','glpi (2)','2018-04-25 09:33:23','0','','global_validation (1347)');
INSERT INTO `glpi_logs` VALUES ('1158','ProfileRight','1347','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1159','Profile','13','0','20','glpi (2)','2018-04-25 09:33:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1160','Profile','13','','0','glpi (2)','2018-04-25 09:34:44','64','0','23');
INSERT INTO `glpi_logs` VALUES ('1161','Profile','13','','0','glpi (2)','2018-04-25 09:34:44','34','0','15383');
INSERT INTO `glpi_logs` VALUES ('1162','Profile','13','','0','glpi (2)','2018-04-25 09:34:44','63','0','23');
INSERT INTO `glpi_logs` VALUES ('1163','Profile','13','','0','glpi (2)','2018-04-25 09:34:44','38','0','1');
INSERT INTO `glpi_logs` VALUES ('1164','Profile','13','','0','glpi (2)','2018-04-25 09:34:44','36','0','1055');
INSERT INTO `glpi_logs` VALUES ('1165','Profile','13','','0','glpi (2)','2018-04-25 09:34:44','120','0','23');
INSERT INTO `glpi_logs` VALUES ('1166','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','62','0','1045');
INSERT INTO `glpi_logs` VALUES ('1167','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','59','0','3191');
INSERT INTO `glpi_logs` VALUES ('1168','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','58','0','23');
INSERT INTO `glpi_logs` VALUES ('1169','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','61','0','1');
INSERT INTO `glpi_logs` VALUES ('1170','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','55','0','23');
INSERT INTO `glpi_logs` VALUES ('1171','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','91','0','23');
INSERT INTO `glpi_logs` VALUES ('1172','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','90','0','23');
INSERT INTO `glpi_logs` VALUES ('1173','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','49','0','23');
INSERT INTO `glpi_logs` VALUES ('1174','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','50','0','23');
INSERT INTO `glpi_logs` VALUES ('1175','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','105','0','23');
INSERT INTO `glpi_logs` VALUES ('1176','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','51','0','23');
INSERT INTO `glpi_logs` VALUES ('1177','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','48','0','1047');
INSERT INTO `glpi_logs` VALUES ('1178','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','60','0','23');
INSERT INTO `glpi_logs` VALUES ('1179','Profile','13','','0','glpi (2)','2018-04-25 09:35:48','56','0','7199');
INSERT INTO `glpi_logs` VALUES ('1180','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','107','0','23');
INSERT INTO `glpi_logs` VALUES ('1181','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','47','0','3');
INSERT INTO `glpi_logs` VALUES ('1182','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','44','0','23');
INSERT INTO `glpi_logs` VALUES ('1183','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','42','0','23');
INSERT INTO `glpi_logs` VALUES ('1184','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','46','0','23');
INSERT INTO `glpi_logs` VALUES ('1185','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','106','0','23');
INSERT INTO `glpi_logs` VALUES ('1186','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','52','0','3072');
INSERT INTO `glpi_logs` VALUES ('1187','Profile','13','','0','glpi (2)','2018-04-25 09:36:15','45','0','23');
INSERT INTO `glpi_logs` VALUES ('1188','Profile','13','','0','glpi (2)','2018-04-25 09:37:28','32','0','127');
INSERT INTO `glpi_logs` VALUES ('1189','Profile','13','','0','glpi (2)','2018-04-25 09:37:28','31','0','127');
INSERT INTO `glpi_logs` VALUES ('1191','Profile','4','ProfileRight','17','glpi (2)','2018-04-26 08:37:20','0','','plugin_comproveedores (1348)');
INSERT INTO `glpi_logs` VALUES ('1192','ProfileRight','1348','0','20','glpi (2)','2018-04-26 08:37:20','0','','');
INSERT INTO `glpi_logs` VALUES ('1194','Profile','4','ProfileRight','17','glpi (2)','2018-04-26 08:37:20','0','','plugin_comproveedores_open_ticket (1349)');
INSERT INTO `glpi_logs` VALUES ('1195','ProfileRight','1349','0','20','glpi (2)','2018-04-26 08:37:20','0','','');
INSERT INTO `glpi_logs` VALUES ('1196','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','6','','fgdsfg');
INSERT INTO `glpi_logs` VALUES ('1197','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','10','','sdfg');
INSERT INTO `glpi_logs` VALUES ('1198','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','4','','sdfg');
INSERT INTO `glpi_logs` VALUES ('1199','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','5','','dsfg');
INSERT INTO `glpi_logs` VALUES ('1200','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','12','','jfgkghjkl');
INSERT INTO `glpi_logs` VALUES ('1201','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','3','','sdfg');
INSERT INTO `glpi_logs` VALUES ('1202','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','13','','ul');
INSERT INTO `glpi_logs` VALUES ('1203','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','14','','fgntrybu');
INSERT INTO `glpi_logs` VALUES ('1204','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','11','','ghjkllj');
INSERT INTO `glpi_logs` VALUES ('1205','Supplier','2','','0','glpi (2)','2018-04-26 08:40:10','16','','ulyhuo,lg');
INSERT INTO `glpi_logs` VALUES ('1206','PhoneModel','1','0','20','Tecnico Bovis (10)','2018-04-26 12:40:45','0','','');
INSERT INTO `glpi_logs` VALUES ('1207','PhoneModel','2','0','20','Tecnico Bovis (10)','2018-04-26 12:40:49','0','','');
INSERT INTO `glpi_logs` VALUES ('1208','PhoneModel','3','0','20','Tecnico Bovis (10)','2018-04-26 12:40:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1209','User','10','','0','Pérez Sánchez Daniel (10)','2018-04-26 13:01:24','34','Tecnico','Pérez Sánchez');
INSERT INTO `glpi_logs` VALUES ('1210','User','10','','0','Pérez Sánchez Daniel (10)','2018-04-26 13:01:24','9','Bovis','Daniel');
INSERT INTO `glpi_logs` VALUES ('1211','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','backup (1350)');
INSERT INTO `glpi_logs` VALUES ('1212','ProfileRight','1350','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1213','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','bookmark_public (1351)');
INSERT INTO `glpi_logs` VALUES ('1214','ProfileRight','1351','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1215','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','budget (1352)');
INSERT INTO `glpi_logs` VALUES ('1216','ProfileRight','1352','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1217','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','calendar (1353)');
INSERT INTO `glpi_logs` VALUES ('1218','ProfileRight','1353','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1219','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','cartridge (1354)');
INSERT INTO `glpi_logs` VALUES ('1220','ProfileRight','1354','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1221','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','certificate (1355)');
INSERT INTO `glpi_logs` VALUES ('1222','ProfileRight','1355','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1223','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','change (1356)');
INSERT INTO `glpi_logs` VALUES ('1224','ProfileRight','1356','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1225','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','changevalidation (1357)');
INSERT INTO `glpi_logs` VALUES ('1226','ProfileRight','1357','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1227','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','computer (1358)');
INSERT INTO `glpi_logs` VALUES ('1228','ProfileRight','1358','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1229','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','config (1359)');
INSERT INTO `glpi_logs` VALUES ('1230','ProfileRight','1359','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1231','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','consumable (1360)');
INSERT INTO `glpi_logs` VALUES ('1232','ProfileRight','1360','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1233','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','contact_enterprise (1361)');
INSERT INTO `glpi_logs` VALUES ('1234','ProfileRight','1361','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1235','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','contract (1362)');
INSERT INTO `glpi_logs` VALUES ('1236','ProfileRight','1362','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1237','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','device (1363)');
INSERT INTO `glpi_logs` VALUES ('1238','ProfileRight','1363','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1239','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','devicesimcard_pinpuk (1364)');
INSERT INTO `glpi_logs` VALUES ('1240','ProfileRight','1364','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1241','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','document (1365)');
INSERT INTO `glpi_logs` VALUES ('1242','ProfileRight','1365','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1243','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','domain (1366)');
INSERT INTO `glpi_logs` VALUES ('1244','ProfileRight','1366','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1245','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','dropdown (1367)');
INSERT INTO `glpi_logs` VALUES ('1246','ProfileRight','1367','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1247','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','entity (1368)');
INSERT INTO `glpi_logs` VALUES ('1248','ProfileRight','1368','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1249','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','followup (1369)');
INSERT INTO `glpi_logs` VALUES ('1250','ProfileRight','1369','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1251','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','group (1370)');
INSERT INTO `glpi_logs` VALUES ('1252','ProfileRight','1370','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1253','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','infocom (1371)');
INSERT INTO `glpi_logs` VALUES ('1254','ProfileRight','1371','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1255','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','internet (1372)');
INSERT INTO `glpi_logs` VALUES ('1256','ProfileRight','1372','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1257','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','itilcategory (1373)');
INSERT INTO `glpi_logs` VALUES ('1258','ProfileRight','1373','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1259','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','knowbase (1374)');
INSERT INTO `glpi_logs` VALUES ('1260','ProfileRight','1374','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1261','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','knowbasecategory (1375)');
INSERT INTO `glpi_logs` VALUES ('1262','ProfileRight','1375','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1263','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','license (1376)');
INSERT INTO `glpi_logs` VALUES ('1264','ProfileRight','1376','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1265','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','line (1377)');
INSERT INTO `glpi_logs` VALUES ('1266','ProfileRight','1377','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1267','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','lineoperator (1378)');
INSERT INTO `glpi_logs` VALUES ('1268','ProfileRight','1378','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1269','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','link (1379)');
INSERT INTO `glpi_logs` VALUES ('1270','ProfileRight','1379','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1271','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','location (1380)');
INSERT INTO `glpi_logs` VALUES ('1272','ProfileRight','1380','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1273','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','logs (1381)');
INSERT INTO `glpi_logs` VALUES ('1274','ProfileRight','1381','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1275','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','monitor (1382)');
INSERT INTO `glpi_logs` VALUES ('1276','ProfileRight','1382','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1277','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','netpoint (1383)');
INSERT INTO `glpi_logs` VALUES ('1278','ProfileRight','1383','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1279','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','networking (1384)');
INSERT INTO `glpi_logs` VALUES ('1280','ProfileRight','1384','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1281','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','notification (1385)');
INSERT INTO `glpi_logs` VALUES ('1282','ProfileRight','1385','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1283','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','password_update (1386)');
INSERT INTO `glpi_logs` VALUES ('1284','ProfileRight','1386','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1285','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','peripheral (1387)');
INSERT INTO `glpi_logs` VALUES ('1286','ProfileRight','1387','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1287','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','phone (1388)');
INSERT INTO `glpi_logs` VALUES ('1288','ProfileRight','1388','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1289','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','planning (1389)');
INSERT INTO `glpi_logs` VALUES ('1290','ProfileRight','1389','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1291','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','plugin_appliances (1390)');
INSERT INTO `glpi_logs` VALUES ('1292','ProfileRight','1390','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1293','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','plugin_appliances_open_ticket (1391)');
INSERT INTO `glpi_logs` VALUES ('1294','ProfileRight','1391','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1295','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','plugin_comproveedores (1392)');
INSERT INTO `glpi_logs` VALUES ('1296','ProfileRight','1392','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1297','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','plugin_comproveedores_open_ticket (1393)');
INSERT INTO `glpi_logs` VALUES ('1298','ProfileRight','1393','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1299','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','printer (1394)');
INSERT INTO `glpi_logs` VALUES ('1300','ProfileRight','1394','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1301','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','problem (1395)');
INSERT INTO `glpi_logs` VALUES ('1302','ProfileRight','1395','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1303','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','profile (1396)');
INSERT INTO `glpi_logs` VALUES ('1304','ProfileRight','1396','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1305','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','project (1397)');
INSERT INTO `glpi_logs` VALUES ('1306','ProfileRight','1397','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1307','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','projecttask (1398)');
INSERT INTO `glpi_logs` VALUES ('1308','ProfileRight','1398','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1309','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','queuednotification (1399)');
INSERT INTO `glpi_logs` VALUES ('1310','ProfileRight','1399','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1311','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','reminder_public (1400)');
INSERT INTO `glpi_logs` VALUES ('1312','ProfileRight','1400','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1313','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','reports (1401)');
INSERT INTO `glpi_logs` VALUES ('1314','ProfileRight','1401','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1315','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','reservation (1402)');
INSERT INTO `glpi_logs` VALUES ('1316','ProfileRight','1402','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1317','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rssfeed_public (1403)');
INSERT INTO `glpi_logs` VALUES ('1318','ProfileRight','1403','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1319','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_dictionnary_dropdown (1404)');
INSERT INTO `glpi_logs` VALUES ('1320','ProfileRight','1404','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1321','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_dictionnary_printer (1405)');
INSERT INTO `glpi_logs` VALUES ('1322','ProfileRight','1405','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1323','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_dictionnary_software (1406)');
INSERT INTO `glpi_logs` VALUES ('1324','ProfileRight','1406','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1325','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_import (1407)');
INSERT INTO `glpi_logs` VALUES ('1326','ProfileRight','1407','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1327','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_ldap (1408)');
INSERT INTO `glpi_logs` VALUES ('1328','ProfileRight','1408','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1329','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_mailcollector (1409)');
INSERT INTO `glpi_logs` VALUES ('1330','ProfileRight','1409','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1331','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_softwarecategories (1410)');
INSERT INTO `glpi_logs` VALUES ('1332','ProfileRight','1410','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1333','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','rule_ticket (1411)');
INSERT INTO `glpi_logs` VALUES ('1334','ProfileRight','1411','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1335','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','search_config (1412)');
INSERT INTO `glpi_logs` VALUES ('1336','ProfileRight','1412','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1337','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','show_group_hardware (1413)');
INSERT INTO `glpi_logs` VALUES ('1338','ProfileRight','1413','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1339','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','slm (1414)');
INSERT INTO `glpi_logs` VALUES ('1340','ProfileRight','1414','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1341','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','software (1415)');
INSERT INTO `glpi_logs` VALUES ('1342','ProfileRight','1415','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1343','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','solutiontemplate (1416)');
INSERT INTO `glpi_logs` VALUES ('1344','ProfileRight','1416','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1345','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','state (1417)');
INSERT INTO `glpi_logs` VALUES ('1346','ProfileRight','1417','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1347','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','statistic (1418)');
INSERT INTO `glpi_logs` VALUES ('1348','ProfileRight','1418','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1349','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','task (1419)');
INSERT INTO `glpi_logs` VALUES ('1350','ProfileRight','1419','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1351','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','taskcategory (1420)');
INSERT INTO `glpi_logs` VALUES ('1352','ProfileRight','1420','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1353','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','ticket (1421)');
INSERT INTO `glpi_logs` VALUES ('1354','ProfileRight','1421','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1355','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','ticketcost (1422)');
INSERT INTO `glpi_logs` VALUES ('1356','ProfileRight','1422','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1357','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','ticketrecurrent (1423)');
INSERT INTO `glpi_logs` VALUES ('1358','ProfileRight','1423','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1359','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','tickettemplate (1424)');
INSERT INTO `glpi_logs` VALUES ('1360','ProfileRight','1424','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1361','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','ticketvalidation (1425)');
INSERT INTO `glpi_logs` VALUES ('1362','ProfileRight','1425','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1363','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','transfer (1426)');
INSERT INTO `glpi_logs` VALUES ('1364','ProfileRight','1426','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1365','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','typedoc (1427)');
INSERT INTO `glpi_logs` VALUES ('1366','ProfileRight','1427','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1367','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','user (1428)');
INSERT INTO `glpi_logs` VALUES ('1368','ProfileRight','1428','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1369','Profile','14','ProfileRight','17','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','global_validation (1429)');
INSERT INTO `glpi_logs` VALUES ('1370','ProfileRight','1429','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1371','Profile','14','0','20','Pérez Sánchez Daniel (10)','2018-04-26 13:03:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1372','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','backup (1430)');
INSERT INTO `glpi_logs` VALUES ('1373','ProfileRight','1430','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1374','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','bookmark_public (1431)');
INSERT INTO `glpi_logs` VALUES ('1375','ProfileRight','1431','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1376','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','budget (1432)');
INSERT INTO `glpi_logs` VALUES ('1377','ProfileRight','1432','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1378','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','calendar (1433)');
INSERT INTO `glpi_logs` VALUES ('1379','ProfileRight','1433','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1380','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','cartridge (1434)');
INSERT INTO `glpi_logs` VALUES ('1381','ProfileRight','1434','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1382','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','certificate (1435)');
INSERT INTO `glpi_logs` VALUES ('1383','ProfileRight','1435','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1384','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','change (1436)');
INSERT INTO `glpi_logs` VALUES ('1385','ProfileRight','1436','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1386','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','changevalidation (1437)');
INSERT INTO `glpi_logs` VALUES ('1387','ProfileRight','1437','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1388','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','computer (1438)');
INSERT INTO `glpi_logs` VALUES ('1389','ProfileRight','1438','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1390','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','config (1439)');
INSERT INTO `glpi_logs` VALUES ('1391','ProfileRight','1439','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1392','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','consumable (1440)');
INSERT INTO `glpi_logs` VALUES ('1393','ProfileRight','1440','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1394','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','contact_enterprise (1441)');
INSERT INTO `glpi_logs` VALUES ('1395','ProfileRight','1441','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1396','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','contract (1442)');
INSERT INTO `glpi_logs` VALUES ('1397','ProfileRight','1442','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1398','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','device (1443)');
INSERT INTO `glpi_logs` VALUES ('1399','ProfileRight','1443','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1400','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','devicesimcard_pinpuk (1444)');
INSERT INTO `glpi_logs` VALUES ('1401','ProfileRight','1444','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1402','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','document (1445)');
INSERT INTO `glpi_logs` VALUES ('1403','ProfileRight','1445','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1404','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','domain (1446)');
INSERT INTO `glpi_logs` VALUES ('1405','ProfileRight','1446','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1406','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','dropdown (1447)');
INSERT INTO `glpi_logs` VALUES ('1407','ProfileRight','1447','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1408','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','entity (1448)');
INSERT INTO `glpi_logs` VALUES ('1409','ProfileRight','1448','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1410','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','followup (1449)');
INSERT INTO `glpi_logs` VALUES ('1411','ProfileRight','1449','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1412','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','group (1450)');
INSERT INTO `glpi_logs` VALUES ('1413','ProfileRight','1450','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1414','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','infocom (1451)');
INSERT INTO `glpi_logs` VALUES ('1415','ProfileRight','1451','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1416','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','internet (1452)');
INSERT INTO `glpi_logs` VALUES ('1417','ProfileRight','1452','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1418','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','itilcategory (1453)');
INSERT INTO `glpi_logs` VALUES ('1419','ProfileRight','1453','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1420','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','knowbase (1454)');
INSERT INTO `glpi_logs` VALUES ('1421','ProfileRight','1454','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1422','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','knowbasecategory (1455)');
INSERT INTO `glpi_logs` VALUES ('1423','ProfileRight','1455','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1424','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','license (1456)');
INSERT INTO `glpi_logs` VALUES ('1425','ProfileRight','1456','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1426','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','line (1457)');
INSERT INTO `glpi_logs` VALUES ('1427','ProfileRight','1457','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1428','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','lineoperator (1458)');
INSERT INTO `glpi_logs` VALUES ('1429','ProfileRight','1458','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1430','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','link (1459)');
INSERT INTO `glpi_logs` VALUES ('1431','ProfileRight','1459','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1432','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','location (1460)');
INSERT INTO `glpi_logs` VALUES ('1433','ProfileRight','1460','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1434','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','logs (1461)');
INSERT INTO `glpi_logs` VALUES ('1435','ProfileRight','1461','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1436','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','monitor (1462)');
INSERT INTO `glpi_logs` VALUES ('1437','ProfileRight','1462','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1438','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','netpoint (1463)');
INSERT INTO `glpi_logs` VALUES ('1439','ProfileRight','1463','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1440','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','networking (1464)');
INSERT INTO `glpi_logs` VALUES ('1441','ProfileRight','1464','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1442','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','notification (1465)');
INSERT INTO `glpi_logs` VALUES ('1443','ProfileRight','1465','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1444','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','password_update (1466)');
INSERT INTO `glpi_logs` VALUES ('1445','ProfileRight','1466','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1446','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','peripheral (1467)');
INSERT INTO `glpi_logs` VALUES ('1447','ProfileRight','1467','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1448','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','phone (1468)');
INSERT INTO `glpi_logs` VALUES ('1449','ProfileRight','1468','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1450','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','planning (1469)');
INSERT INTO `glpi_logs` VALUES ('1451','ProfileRight','1469','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1452','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','plugin_appliances (1470)');
INSERT INTO `glpi_logs` VALUES ('1453','ProfileRight','1470','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1454','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','plugin_appliances_open_ticket (1471)');
INSERT INTO `glpi_logs` VALUES ('1455','ProfileRight','1471','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1456','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','plugin_comproveedores (1472)');
INSERT INTO `glpi_logs` VALUES ('1457','ProfileRight','1472','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1458','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','plugin_comproveedores_open_ticket (1473)');
INSERT INTO `glpi_logs` VALUES ('1459','ProfileRight','1473','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1460','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','printer (1474)');
INSERT INTO `glpi_logs` VALUES ('1461','ProfileRight','1474','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1462','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','problem (1475)');
INSERT INTO `glpi_logs` VALUES ('1463','ProfileRight','1475','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1464','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','profile (1476)');
INSERT INTO `glpi_logs` VALUES ('1465','ProfileRight','1476','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1466','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','project (1477)');
INSERT INTO `glpi_logs` VALUES ('1467','ProfileRight','1477','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1468','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','projecttask (1478)');
INSERT INTO `glpi_logs` VALUES ('1469','ProfileRight','1478','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1470','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','queuednotification (1479)');
INSERT INTO `glpi_logs` VALUES ('1471','ProfileRight','1479','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1472','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','reminder_public (1480)');
INSERT INTO `glpi_logs` VALUES ('1473','ProfileRight','1480','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1474','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','reports (1481)');
INSERT INTO `glpi_logs` VALUES ('1475','ProfileRight','1481','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1476','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','reservation (1482)');
INSERT INTO `glpi_logs` VALUES ('1477','ProfileRight','1482','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1478','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rssfeed_public (1483)');
INSERT INTO `glpi_logs` VALUES ('1479','ProfileRight','1483','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1480','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_dictionnary_dropdown (1484)');
INSERT INTO `glpi_logs` VALUES ('1481','ProfileRight','1484','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1482','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_dictionnary_printer (1485)');
INSERT INTO `glpi_logs` VALUES ('1483','ProfileRight','1485','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1484','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_dictionnary_software (1486)');
INSERT INTO `glpi_logs` VALUES ('1485','ProfileRight','1486','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1486','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_import (1487)');
INSERT INTO `glpi_logs` VALUES ('1487','ProfileRight','1487','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1488','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_ldap (1488)');
INSERT INTO `glpi_logs` VALUES ('1489','ProfileRight','1488','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1490','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_mailcollector (1489)');
INSERT INTO `glpi_logs` VALUES ('1491','ProfileRight','1489','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1492','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_softwarecategories (1490)');
INSERT INTO `glpi_logs` VALUES ('1493','ProfileRight','1490','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1494','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','rule_ticket (1491)');
INSERT INTO `glpi_logs` VALUES ('1495','ProfileRight','1491','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1496','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','search_config (1492)');
INSERT INTO `glpi_logs` VALUES ('1497','ProfileRight','1492','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1498','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','show_group_hardware (1493)');
INSERT INTO `glpi_logs` VALUES ('1499','ProfileRight','1493','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1500','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','slm (1494)');
INSERT INTO `glpi_logs` VALUES ('1501','ProfileRight','1494','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1502','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','software (1495)');
INSERT INTO `glpi_logs` VALUES ('1503','ProfileRight','1495','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1504','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','solutiontemplate (1496)');
INSERT INTO `glpi_logs` VALUES ('1505','ProfileRight','1496','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1506','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','state (1497)');
INSERT INTO `glpi_logs` VALUES ('1507','ProfileRight','1497','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1508','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','statistic (1498)');
INSERT INTO `glpi_logs` VALUES ('1509','ProfileRight','1498','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1510','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','task (1499)');
INSERT INTO `glpi_logs` VALUES ('1511','ProfileRight','1499','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1512','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','taskcategory (1500)');
INSERT INTO `glpi_logs` VALUES ('1513','ProfileRight','1500','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1514','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','ticket (1501)');
INSERT INTO `glpi_logs` VALUES ('1515','ProfileRight','1501','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1516','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','ticketcost (1502)');
INSERT INTO `glpi_logs` VALUES ('1517','ProfileRight','1502','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1518','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','ticketrecurrent (1503)');
INSERT INTO `glpi_logs` VALUES ('1519','ProfileRight','1503','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1520','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','tickettemplate (1504)');
INSERT INTO `glpi_logs` VALUES ('1521','ProfileRight','1504','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1522','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','ticketvalidation (1505)');
INSERT INTO `glpi_logs` VALUES ('1523','ProfileRight','1505','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1524','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','transfer (1506)');
INSERT INTO `glpi_logs` VALUES ('1525','ProfileRight','1506','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1526','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','typedoc (1507)');
INSERT INTO `glpi_logs` VALUES ('1527','ProfileRight','1507','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1528','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','user (1508)');
INSERT INTO `glpi_logs` VALUES ('1529','ProfileRight','1508','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1530','Profile','15','ProfileRight','17','glpi (2)','2018-04-27 10:00:02','0','','global_validation (1509)');
INSERT INTO `glpi_logs` VALUES ('1531','ProfileRight','1509','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1532','Profile','15','0','20','glpi (2)','2018-04-27 10:00:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1533','Profile','15','','0','glpi (2)','2018-04-27 10:00:25','1','GENERAL','BOVIS GENERAL');
INSERT INTO `glpi_logs` VALUES ('1534','Profile','14','','0','glpi (2)','2018-04-27 10:02:53','1','PM','BOVIS  USUARIOS DE PROYECTO');
INSERT INTO `glpi_logs` VALUES ('1535','Profile','14','','0','glpi (2)','2018-04-27 10:02:58','1','BOVIS  USUARIOS DE PROYECTO','BOVIS USUARIOS DE PROYECTO');
INSERT INTO `glpi_logs` VALUES ('1536','Profile','10','','0','glpi (2)','2018-04-27 10:03:31','1','Técnico BOVIS','BOVIS FINANCIERO');
INSERT INTO `glpi_logs` VALUES ('1537','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','backup (1510)');
INSERT INTO `glpi_logs` VALUES ('1538','ProfileRight','1510','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1539','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','bookmark_public (1511)');
INSERT INTO `glpi_logs` VALUES ('1540','ProfileRight','1511','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1541','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','budget (1512)');
INSERT INTO `glpi_logs` VALUES ('1542','ProfileRight','1512','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1543','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','calendar (1513)');
INSERT INTO `glpi_logs` VALUES ('1544','ProfileRight','1513','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1545','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','cartridge (1514)');
INSERT INTO `glpi_logs` VALUES ('1546','ProfileRight','1514','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1547','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','certificate (1515)');
INSERT INTO `glpi_logs` VALUES ('1548','ProfileRight','1515','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1549','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','change (1516)');
INSERT INTO `glpi_logs` VALUES ('1550','ProfileRight','1516','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1551','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','changevalidation (1517)');
INSERT INTO `glpi_logs` VALUES ('1552','ProfileRight','1517','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1553','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','computer (1518)');
INSERT INTO `glpi_logs` VALUES ('1554','ProfileRight','1518','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1555','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','config (1519)');
INSERT INTO `glpi_logs` VALUES ('1556','ProfileRight','1519','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1557','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','consumable (1520)');
INSERT INTO `glpi_logs` VALUES ('1558','ProfileRight','1520','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1559','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','contact_enterprise (1521)');
INSERT INTO `glpi_logs` VALUES ('1560','ProfileRight','1521','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1561','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','contract (1522)');
INSERT INTO `glpi_logs` VALUES ('1562','ProfileRight','1522','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1563','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','device (1523)');
INSERT INTO `glpi_logs` VALUES ('1564','ProfileRight','1523','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1565','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','devicesimcard_pinpuk (1524)');
INSERT INTO `glpi_logs` VALUES ('1566','ProfileRight','1524','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1567','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','document (1525)');
INSERT INTO `glpi_logs` VALUES ('1568','ProfileRight','1525','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1569','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','domain (1526)');
INSERT INTO `glpi_logs` VALUES ('1570','ProfileRight','1526','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1571','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','dropdown (1527)');
INSERT INTO `glpi_logs` VALUES ('1572','ProfileRight','1527','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1573','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','entity (1528)');
INSERT INTO `glpi_logs` VALUES ('1574','ProfileRight','1528','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1575','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','followup (1529)');
INSERT INTO `glpi_logs` VALUES ('1576','ProfileRight','1529','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1577','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','group (1530)');
INSERT INTO `glpi_logs` VALUES ('1578','ProfileRight','1530','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1579','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','infocom (1531)');
INSERT INTO `glpi_logs` VALUES ('1580','ProfileRight','1531','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1581','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','internet (1532)');
INSERT INTO `glpi_logs` VALUES ('1582','ProfileRight','1532','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1583','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','itilcategory (1533)');
INSERT INTO `glpi_logs` VALUES ('1584','ProfileRight','1533','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1585','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','knowbase (1534)');
INSERT INTO `glpi_logs` VALUES ('1586','ProfileRight','1534','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1587','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','knowbasecategory (1535)');
INSERT INTO `glpi_logs` VALUES ('1588','ProfileRight','1535','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1589','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','license (1536)');
INSERT INTO `glpi_logs` VALUES ('1590','ProfileRight','1536','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1591','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','line (1537)');
INSERT INTO `glpi_logs` VALUES ('1592','ProfileRight','1537','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1593','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','lineoperator (1538)');
INSERT INTO `glpi_logs` VALUES ('1594','ProfileRight','1538','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1595','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','link (1539)');
INSERT INTO `glpi_logs` VALUES ('1596','ProfileRight','1539','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1597','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','location (1540)');
INSERT INTO `glpi_logs` VALUES ('1598','ProfileRight','1540','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1599','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','logs (1541)');
INSERT INTO `glpi_logs` VALUES ('1600','ProfileRight','1541','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1601','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','monitor (1542)');
INSERT INTO `glpi_logs` VALUES ('1602','ProfileRight','1542','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1603','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','netpoint (1543)');
INSERT INTO `glpi_logs` VALUES ('1604','ProfileRight','1543','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1605','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','networking (1544)');
INSERT INTO `glpi_logs` VALUES ('1606','ProfileRight','1544','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1607','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','notification (1545)');
INSERT INTO `glpi_logs` VALUES ('1608','ProfileRight','1545','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1609','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','password_update (1546)');
INSERT INTO `glpi_logs` VALUES ('1610','ProfileRight','1546','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1611','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','peripheral (1547)');
INSERT INTO `glpi_logs` VALUES ('1612','ProfileRight','1547','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1613','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','phone (1548)');
INSERT INTO `glpi_logs` VALUES ('1614','ProfileRight','1548','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1615','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','planning (1549)');
INSERT INTO `glpi_logs` VALUES ('1616','ProfileRight','1549','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1617','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','plugin_appliances (1550)');
INSERT INTO `glpi_logs` VALUES ('1618','ProfileRight','1550','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1619','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','plugin_appliances_open_ticket (1551)');
INSERT INTO `glpi_logs` VALUES ('1620','ProfileRight','1551','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1621','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','plugin_comproveedores (1552)');
INSERT INTO `glpi_logs` VALUES ('1622','ProfileRight','1552','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1623','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','plugin_comproveedores_open_ticket (1553)');
INSERT INTO `glpi_logs` VALUES ('1624','ProfileRight','1553','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1625','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','printer (1554)');
INSERT INTO `glpi_logs` VALUES ('1626','ProfileRight','1554','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1627','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','problem (1555)');
INSERT INTO `glpi_logs` VALUES ('1628','ProfileRight','1555','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1629','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','profile (1556)');
INSERT INTO `glpi_logs` VALUES ('1630','ProfileRight','1556','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1631','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','project (1557)');
INSERT INTO `glpi_logs` VALUES ('1632','ProfileRight','1557','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1633','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','projecttask (1558)');
INSERT INTO `glpi_logs` VALUES ('1634','ProfileRight','1558','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1635','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','queuednotification (1559)');
INSERT INTO `glpi_logs` VALUES ('1636','ProfileRight','1559','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1637','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','reminder_public (1560)');
INSERT INTO `glpi_logs` VALUES ('1638','ProfileRight','1560','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1639','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','reports (1561)');
INSERT INTO `glpi_logs` VALUES ('1640','ProfileRight','1561','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1641','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','reservation (1562)');
INSERT INTO `glpi_logs` VALUES ('1642','ProfileRight','1562','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1643','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rssfeed_public (1563)');
INSERT INTO `glpi_logs` VALUES ('1644','ProfileRight','1563','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1645','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_dictionnary_dropdown (1564)');
INSERT INTO `glpi_logs` VALUES ('1646','ProfileRight','1564','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1647','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_dictionnary_printer (1565)');
INSERT INTO `glpi_logs` VALUES ('1648','ProfileRight','1565','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1649','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_dictionnary_software (1566)');
INSERT INTO `glpi_logs` VALUES ('1650','ProfileRight','1566','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1651','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_import (1567)');
INSERT INTO `glpi_logs` VALUES ('1652','ProfileRight','1567','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1653','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_ldap (1568)');
INSERT INTO `glpi_logs` VALUES ('1654','ProfileRight','1568','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1655','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_mailcollector (1569)');
INSERT INTO `glpi_logs` VALUES ('1656','ProfileRight','1569','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1657','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_softwarecategories (1570)');
INSERT INTO `glpi_logs` VALUES ('1658','ProfileRight','1570','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1659','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','rule_ticket (1571)');
INSERT INTO `glpi_logs` VALUES ('1660','ProfileRight','1571','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1661','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','search_config (1572)');
INSERT INTO `glpi_logs` VALUES ('1662','ProfileRight','1572','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1663','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','show_group_hardware (1573)');
INSERT INTO `glpi_logs` VALUES ('1664','ProfileRight','1573','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1665','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','slm (1574)');
INSERT INTO `glpi_logs` VALUES ('1666','ProfileRight','1574','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1667','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','software (1575)');
INSERT INTO `glpi_logs` VALUES ('1668','ProfileRight','1575','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1669','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','solutiontemplate (1576)');
INSERT INTO `glpi_logs` VALUES ('1670','ProfileRight','1576','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1671','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','state (1577)');
INSERT INTO `glpi_logs` VALUES ('1672','ProfileRight','1577','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1673','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','statistic (1578)');
INSERT INTO `glpi_logs` VALUES ('1674','ProfileRight','1578','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1675','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','task (1579)');
INSERT INTO `glpi_logs` VALUES ('1676','ProfileRight','1579','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1677','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','taskcategory (1580)');
INSERT INTO `glpi_logs` VALUES ('1678','ProfileRight','1580','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1679','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','ticket (1581)');
INSERT INTO `glpi_logs` VALUES ('1680','ProfileRight','1581','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1681','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','ticketcost (1582)');
INSERT INTO `glpi_logs` VALUES ('1682','ProfileRight','1582','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1683','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','ticketrecurrent (1583)');
INSERT INTO `glpi_logs` VALUES ('1684','ProfileRight','1583','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1685','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','tickettemplate (1584)');
INSERT INTO `glpi_logs` VALUES ('1686','ProfileRight','1584','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1687','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','ticketvalidation (1585)');
INSERT INTO `glpi_logs` VALUES ('1688','ProfileRight','1585','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1689','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','transfer (1586)');
INSERT INTO `glpi_logs` VALUES ('1690','ProfileRight','1586','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1691','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','typedoc (1587)');
INSERT INTO `glpi_logs` VALUES ('1692','ProfileRight','1587','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1693','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','user (1588)');
INSERT INTO `glpi_logs` VALUES ('1694','ProfileRight','1588','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1695','Profile','16','ProfileRight','17','glpi (2)','2018-04-27 10:04:11','0','','global_validation (1589)');
INSERT INTO `glpi_logs` VALUES ('1696','ProfileRight','1589','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1697','Profile','16','0','20','glpi (2)','2018-04-27 10:04:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1698','Profile','9','','0','glpi (2)','2018-04-27 10:05:08','1','Proveedores','BOVIS PROVEEDORES');
INSERT INTO `glpi_logs` VALUES ('1699','User','13','Profile','17','glpi (2)','2018-04-27 10:09:35','0','','BOVIS ESTRATÉGICO (16)');
INSERT INTO `glpi_logs` VALUES ('1700','User','13','0','20','glpi (2)','2018-04-27 10:09:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1701','User','14','Profile','17','glpi (2)','2018-04-27 10:09:55','0','','BOVIS FINANCIERO (10)');
INSERT INTO `glpi_logs` VALUES ('1702','User','14','0','20','glpi (2)','2018-04-27 10:09:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1703','User','15','Profile','17','glpi (2)','2018-04-27 10:10:18','0','','BOVIS GENERAL (15)');
INSERT INTO `glpi_logs` VALUES ('1704','User','15','0','20','glpi (2)','2018-04-27 10:10:18','0','','');
INSERT INTO `glpi_logs` VALUES ('1705','User','16','Profile','17','glpi (2)','2018-04-27 10:10:38','0','','BOVIS PROVEEDORES (9)');
INSERT INTO `glpi_logs` VALUES ('1706','User','16','0','20','glpi (2)','2018-04-27 10:10:38','0','','');
INSERT INTO `glpi_logs` VALUES ('1707','User','17','Profile','17','glpi (2)','2018-04-27 10:12:02','0','','BOVIS USUARIOS DE PROYECTO (14)');
INSERT INTO `glpi_logs` VALUES ('1708','User','17','0','20','glpi (2)','2018-04-27 10:12:02','0','','');
INSERT INTO `glpi_logs` VALUES ('1709','Profile','15','','0','glpi (2)','2018-04-27 10:19:49','100','','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0}');
INSERT INTO `glpi_logs` VALUES ('1710','Profile','15','','0','glpi (2)','2018-04-27 10:19:49','110','','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,');
INSERT INTO `glpi_logs` VALUES ('1711','Profile','15','','0','glpi (2)','2018-04-27 10:19:49','111','','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\"');
INSERT INTO `glpi_logs` VALUES ('1712','User','7','','0','sánchez sánchez juan (7)','2018-04-30 12:36:59','34','juan','sánchez sánchez');
INSERT INTO `glpi_logs` VALUES ('1713','User','7','','0','sánchez sánchez juan (7)','2018-04-30 12:36:59','9','','juan');
INSERT INTO `glpi_logs` VALUES ('1714','SupplierType','1','0','20','glpi (2)','2018-04-30 13:52:34','0','','');
INSERT INTO `glpi_logs` VALUES ('1715','SupplierType','2','0','20','glpi (2)','2018-04-30 13:52:42','0','','');
INSERT INTO `glpi_logs` VALUES ('1716','SupplierType','3','0','20','glpi (2)','2018-04-30 13:52:56','0','','');
INSERT INTO `glpi_logs` VALUES ('1717','Supplier','3','0','20','glpi (2)','2018-04-30 13:53:04','0','','');
INSERT INTO `glpi_logs` VALUES ('1718','User','18','UserEmail','17','glpi (2)','2018-04-30 14:08:23','0','','luis.castilla.camara@acciona.com (1)');
INSERT INTO `glpi_logs` VALUES ('1719','UserEmail','1','0','20','glpi (2)','2018-04-30 14:08:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1720','User','18','Profile','17','glpi (2)','2018-04-30 14:08:23','0','','BOVIS PROVEEDORES (9)');
INSERT INTO `glpi_logs` VALUES ('1721','User','18','0','20','glpi (2)','2018-04-30 14:08:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1722','UserTitle','3','0','20','glpi (2)','2018-04-30 14:09:47','0','','');
INSERT INTO `glpi_logs` VALUES ('1723','UserTitle','4','0','20','glpi (2)','2018-04-30 14:09:54','0','','');
INSERT INTO `glpi_logs` VALUES ('1724','UserTitle','5','0','20','glpi (2)','2018-04-30 14:10:01','0','','');
INSERT INTO `glpi_logs` VALUES ('1725','UserTitle','6','0','20','glpi (2)','2018-04-30 14:10:24','0','','');
INSERT INTO `glpi_logs` VALUES ('1726','User','18','','0','glpi (2)','2018-04-30 14:10:28','81','&nbsp; (0)','Director Geneal (1)');
INSERT INTO `glpi_logs` VALUES ('1727','User','19','UserEmail','17','glpi (2)','2018-04-30 14:12:15','0','','alberto.rey.quintana@acciona.com (2)');
INSERT INTO `glpi_logs` VALUES ('1728','UserEmail','2','0','20','glpi (2)','2018-04-30 14:12:15','0','','');
INSERT INTO `glpi_logs` VALUES ('1729','User','19','Profile','17','glpi (2)','2018-04-30 14:12:15','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('1730','User','19','0','20','glpi (2)','2018-04-30 14:12:15','0','','');
INSERT INTO `glpi_logs` VALUES ('1731','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','26','127','0');
INSERT INTO `glpi_logs` VALUES ('1732','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','20','127','0');
INSERT INTO `glpi_logs` VALUES ('1733','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','27','127','0');
INSERT INTO `glpi_logs` VALUES ('1734','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','129','31','0');
INSERT INTO `glpi_logs` VALUES ('1735','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','21','127','0');
INSERT INTO `glpi_logs` VALUES ('1736','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','23','127','0');
INSERT INTO `glpi_logs` VALUES ('1737','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','25','127','0');
INSERT INTO `glpi_logs` VALUES ('1738','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','28','127','0');
INSERT INTO `glpi_logs` VALUES ('1739','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','24','127','0');
INSERT INTO `glpi_logs` VALUES ('1740','Profile','10','','0','glpi (2)','2018-05-03 08:30:00','22','127','0');
INSERT INTO `glpi_logs` VALUES ('1741','Profile','10','','0','glpi (2)','2018-05-03 08:31:30','115','1151','0');
INSERT INTO `glpi_logs` VALUES ('1742','Profile','10','','0','glpi (2)','2018-05-03 08:31:30','112','1151','0');
INSERT INTO `glpi_logs` VALUES ('1743','Profile','10','','0','glpi (2)','2018-05-03 08:31:30','102','261151','0');
INSERT INTO `glpi_logs` VALUES ('1744','Profile','10','','0','glpi (2)','2018-05-03 08:31:30','119','23','0');
INSERT INTO `glpi_logs` VALUES ('1745','Profile','10','','0','glpi (2)','2018-05-03 08:31:30','103','23','0');
INSERT INTO `glpi_logs` VALUES ('1746','Profile','10','','0','glpi (2)','2018-05-03 08:31:44','100','','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0}');
INSERT INTO `glpi_logs` VALUES ('1747','Profile','10','','0','glpi (2)','2018-05-03 08:31:44','110','','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,');
INSERT INTO `glpi_logs` VALUES ('1748','Profile','10','','0','glpi (2)','2018-05-03 08:31:44','111','','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\"');
INSERT INTO `glpi_logs` VALUES ('1749','Profile','10','','0','glpi (2)','2018-05-03 08:32:41','49','23','0');
INSERT INTO `glpi_logs` VALUES ('1750','Profile','10','','0','glpi (2)','2018-05-03 08:32:41','50','23','0');
INSERT INTO `glpi_logs` VALUES ('1751','Profile','10','','0','glpi (2)','2018-05-03 08:32:41','105','23','0');
INSERT INTO `glpi_logs` VALUES ('1752','Profile','10','','0','glpi (2)','2018-05-03 08:32:41','51','23','0');
INSERT INTO `glpi_logs` VALUES ('1753','Profile','10','','0','glpi (2)','2018-05-03 08:32:41','48','1047','0');
INSERT INTO `glpi_logs` VALUES ('1754','Profile','10','','0','glpi (2)','2018-05-03 08:32:41','60','23','0');
INSERT INTO `glpi_logs` VALUES ('1755','Profile','14','','0','glpi (2)','2018-05-03 08:36:58','100','','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0}');
INSERT INTO `glpi_logs` VALUES ('1756','Profile','14','','0','glpi (2)','2018-05-03 08:36:58','110','','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,');
INSERT INTO `glpi_logs` VALUES ('1757','Profile','14','','0','glpi (2)','2018-05-03 08:36:58','111','','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\"');
INSERT INTO `glpi_logs` VALUES ('1758','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','87','','[]');
INSERT INTO `glpi_logs` VALUES ('1759','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','115','0','1151');
INSERT INTO `glpi_logs` VALUES ('1760','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','79','0','3073');
INSERT INTO `glpi_logs` VALUES ('1761','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','112','0','1151');
INSERT INTO `glpi_logs` VALUES ('1762','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','85','0','1');
INSERT INTO `glpi_logs` VALUES ('1763','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','102','0','261151');
INSERT INTO `glpi_logs` VALUES ('1764','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','119','0','23');
INSERT INTO `glpi_logs` VALUES ('1765','Profile','14','','0','glpi (2)','2018-05-03 08:37:34','103','0','23');
INSERT INTO `glpi_logs` VALUES ('1766','User','19','','0','glpi (2)','2018-05-03 13:26:10','1','areyq','alberto.rey.quintana@acciona.com');
INSERT INTO `glpi_logs` VALUES ('1767','User','18','','0','glpi (2)','2018-05-03 13:26:26','1','luiscastillac','luis.castilla.camara@acciona.com');
INSERT INTO `glpi_logs` VALUES ('1768','User','20','UserEmail','17','glpi (2)','2018-05-03 13:31:58','0','','cesaralberto.orozco.reguero@acciona.com (3)');
INSERT INTO `glpi_logs` VALUES ('1769','UserEmail','3','0','20','glpi (2)','2018-05-03 13:31:58','0','','');
INSERT INTO `glpi_logs` VALUES ('1770','User','20','Profile','17','glpi (2)','2018-05-03 13:31:58','0','','BOVIS PROVEEDORES (9)');
INSERT INTO `glpi_logs` VALUES ('1771','User','20','0','20','glpi (2)','2018-05-03 13:31:58','0','','');
INSERT INTO `glpi_logs` VALUES ('1772','User','19','Profile','17','glpi (2)','2018-05-03 13:32:25','0','','BOVIS PROVEEDORES (9)');
INSERT INTO `glpi_logs` VALUES ('1773','User','19','Profile','19','glpi (2)','2018-05-03 13:32:32','0','Self-Service (1)','');
INSERT INTO `glpi_logs` VALUES ('1774','User','19','','0','glpi (2)','2018-05-03 13:32:40','20','&nbsp; (0)','BOVIS PROVEEDORES (9)');
INSERT INTO `glpi_logs` VALUES ('1775','User','20','','0','glpi (2)','2018-05-03 13:32:53','20','&nbsp; (0)','BOVIS PROVEEDORES (9)');
INSERT INTO `glpi_logs` VALUES ('1776','Supplier','3','','0','glpi (2)','2018-05-04 08:37:33','11','alcobendas','Alcobendas');
INSERT INTO `glpi_logs` VALUES ('1777','Reminder','2','0','20','glpi (2)','2018-05-04 09:25:45','0','','');
INSERT INTO `glpi_logs` VALUES ('1778','Reminder','2','User','15','glpi (2)','2018-05-04 09:32:42','0','','Pérez Sánchez Daniel (10)');
INSERT INTO `glpi_logs` VALUES ('1779','Reminder','2','User','16','glpi (2)','2018-05-04 09:32:56','0','Pérez Sánchez Daniel (10)','');
INSERT INTO `glpi_logs` VALUES ('1780','Profile','16','','0','glpi (2)','2018-05-11 12:14:59','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('1781','Profile','16','','0','glpi (2)','2018-05-11 12:20:57','32','0','127');
INSERT INTO `glpi_logs` VALUES ('1782','Profile','16','','0','glpi (2)','2018-05-11 12:20:57','31','0','127');
INSERT INTO `glpi_logs` VALUES ('1783','Profile','16','','0','glpi (2)','2018-05-11 12:21:09','64','0','23');
INSERT INTO `glpi_logs` VALUES ('1784','Profile','16','','0','glpi (2)','2018-05-11 12:21:09','34','0','15383');
INSERT INTO `glpi_logs` VALUES ('1785','Profile','16','','0','glpi (2)','2018-05-11 12:21:09','63','0','23');
INSERT INTO `glpi_logs` VALUES ('1786','Profile','16','','0','glpi (2)','2018-05-11 12:21:09','38','0','1');
INSERT INTO `glpi_logs` VALUES ('1787','Profile','16','','0','glpi (2)','2018-05-11 12:21:09','36','0','1055');
INSERT INTO `glpi_logs` VALUES ('1788','Profile','16','','0','glpi (2)','2018-05-11 12:21:09','120','0','23');
INSERT INTO `glpi_logs` VALUES ('1789','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','62','0','1045');
INSERT INTO `glpi_logs` VALUES ('1790','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','59','0','3191');
INSERT INTO `glpi_logs` VALUES ('1791','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','58','0','119');
INSERT INTO `glpi_logs` VALUES ('1792','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','61','0','1');
INSERT INTO `glpi_logs` VALUES ('1793','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','55','0','23');
INSERT INTO `glpi_logs` VALUES ('1794','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','91','0','23');
INSERT INTO `glpi_logs` VALUES ('1795','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','90','0','23');
INSERT INTO `glpi_logs` VALUES ('1796','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','49','0','23');
INSERT INTO `glpi_logs` VALUES ('1797','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','50','0','23');
INSERT INTO `glpi_logs` VALUES ('1798','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','105','0','23');
INSERT INTO `glpi_logs` VALUES ('1799','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','51','0','23');
INSERT INTO `glpi_logs` VALUES ('1800','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','48','0','1047');
INSERT INTO `glpi_logs` VALUES ('1801','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','60','0','23');
INSERT INTO `glpi_logs` VALUES ('1802','Profile','16','','0','glpi (2)','2018-05-11 12:21:22','56','0','7199');
INSERT INTO `glpi_logs` VALUES ('1803','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','107','0','23');
INSERT INTO `glpi_logs` VALUES ('1804','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','47','0','3');
INSERT INTO `glpi_logs` VALUES ('1805','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','44','0','23');
INSERT INTO `glpi_logs` VALUES ('1806','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','42','0','23');
INSERT INTO `glpi_logs` VALUES ('1807','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','46','0','23');
INSERT INTO `glpi_logs` VALUES ('1808','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','106','0','23');
INSERT INTO `glpi_logs` VALUES ('1809','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','52','0','3072');
INSERT INTO `glpi_logs` VALUES ('1810','Profile','16','','0','glpi (2)','2018-05-11 12:21:37','45','0','23');
INSERT INTO `glpi_logs` VALUES ('1811','Reminder','3','0','20','usuestrategico1 (13)','2018-05-15 12:21:29','0','','');
INSERT INTO `glpi_logs` VALUES ('1812','Project','1','0','20','usuestrategico1 (13)','2018-05-15 13:19:17','0','','');
INSERT INTO `glpi_logs` VALUES ('1813','ProjectTask','1','0','20','usuestrategico1 (13)','2018-05-15 13:20:15','0','','');
INSERT INTO `glpi_logs` VALUES ('1814','ProjectTask','2','0','20','usuestrategico1 (13)','2018-05-15 13:21:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1815','ProjectTask','1','Supplier','15','usuestrategico1 (13)','2018-05-15 13:22:49','0','','ACCIONA CONSTRUCCIÓN, S.A. (3)');
INSERT INTO `glpi_logs` VALUES ('1816','Supplier','3','ProjectTask','15','usuestrategico1 (13)','2018-05-15 13:22:49','0','','SEGURIDAD Y SALUD (1)');
INSERT INTO `glpi_logs` VALUES ('1817','ProjectTaskTeam','1','0','20','usuestrategico1 (13)','2018-05-15 13:22:49','0','','');
INSERT INTO `glpi_logs` VALUES ('1818','Project','1','','0','usuestrategico1 (13)','2018-05-21 07:41:32','1','SANTIAGO BERNABEU','PROYECTO001');
INSERT INTO `glpi_logs` VALUES ('1819','Profile','16','','0','glpi (2)','2018-05-21 07:43:47','34','15383','0');
INSERT INTO `glpi_logs` VALUES ('1820','Profile','16','','0','glpi (2)','2018-05-21 07:43:47','120','23','0');

### Dump table glpi_mailcollectors

DROP TABLE IF EXISTS `glpi_mailcollectors`;
CREATE TABLE `glpi_mailcollectors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize_max` int(11) NOT NULL DEFAULT '2097152',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accepted` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `refused` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_kerberos` tinyint(1) NOT NULL DEFAULT '0',
  `errors` int(11) NOT NULL DEFAULT '0',
  `use_mail_date` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_manufacturers

DROP TABLE IF EXISTS `glpi_manufacturers`;
CREATE TABLE `glpi_manufacturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitormodels

DROP TABLE IF EXISTS `glpi_monitormodels`;
CREATE TABLE `glpi_monitormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitors

DROP TABLE IF EXISTS `glpi_monitors`;
CREATE TABLE `glpi_monitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` decimal(5,2) NOT NULL DEFAULT '0.00',
  `have_micro` tinyint(1) NOT NULL DEFAULT '0',
  `have_speaker` tinyint(1) NOT NULL DEFAULT '0',
  `have_subd` tinyint(1) NOT NULL DEFAULT '0',
  `have_bnc` tinyint(1) NOT NULL DEFAULT '0',
  `have_dvi` tinyint(1) NOT NULL DEFAULT '0',
  `have_pivot` tinyint(1) NOT NULL DEFAULT '0',
  `have_hdmi` tinyint(1) NOT NULL DEFAULT '0',
  `have_displayport` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `monitortypes_id` int(11) NOT NULL DEFAULT '0',
  `monitormodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `monitormodels_id` (`monitormodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `monitortypes_id` (`monitortypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitortypes

DROP TABLE IF EXISTS `glpi_monitortypes`;
CREATE TABLE `glpi_monitortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_netpoints

DROP TABLE IF EXISTS `glpi_netpoints`;
CREATE TABLE `glpi_netpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `complete` (`entities_id`,`locations_id`,`name`),
  KEY `location_name` (`locations_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkaliases

DROP TABLE IF EXISTS `glpi_networkaliases`;
CREATE TABLE `glpi_networkaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `networknames_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `networknames_id` (`networknames_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentmodels

DROP TABLE IF EXISTS `glpi_networkequipmentmodels`;
CREATE TABLE `glpi_networkequipmentmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipments

DROP TABLE IF EXISTS `glpi_networkequipments`;
CREATE TABLE `glpi_networkequipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmenttypes_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentmodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `networkequipmentmodels_id` (`networkequipmentmodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `networkequipmenttypes_id` (`networkequipmenttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmenttypes

DROP TABLE IF EXISTS `glpi_networkequipmenttypes`;
CREATE TABLE `glpi_networkequipmenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkinterfaces

DROP TABLE IF EXISTS `glpi_networkinterfaces`;
CREATE TABLE `glpi_networkinterfaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networknames

DROP TABLE IF EXISTS `glpi_networknames`;
CREATE TABLE `glpi_networknames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `FQDN` (`name`,`fqdns_id`),
  KEY `name` (`name`),
  KEY `fqdns_id` (`fqdns_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaggregates

DROP TABLE IF EXISTS `glpi_networkportaggregates`;
CREATE TABLE `glpi_networkportaggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_list` text COLLATE utf8_unicode_ci COMMENT 'array of associated networkports_id',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaliases

DROP TABLE IF EXISTS `glpi_networkportaliases`;
CREATE TABLE `glpi_networkportaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_alias` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `networkports_id_alias` (`networkports_id_alias`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportdialups

DROP TABLE IF EXISTS `glpi_networkportdialups`;
CREATE TABLE `glpi_networkportdialups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportethernets

DROP TABLE IF EXISTS `glpi_networkportethernets`;
CREATE TABLE `glpi_networkportethernets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'T, LX, SX',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `type` (`type`),
  KEY `speed` (`speed`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportfiberchannels

DROP TABLE IF EXISTS `glpi_networkportfiberchannels`;
CREATE TABLE `glpi_networkportfiberchannels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `wwn` varchar(16) COLLATE utf8_unicode_ci DEFAULT '',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `wwn` (`wwn`),
  KEY `speed` (`speed`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportlocals

DROP TABLE IF EXISTS `glpi_networkportlocals`;
CREATE TABLE `glpi_networkportlocals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports

DROP TABLE IF EXISTS `glpi_networkports`;
CREATE TABLE `glpi_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `logical_number` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `instantiation_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `on_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `mac` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_networkports

DROP TABLE IF EXISTS `glpi_networkports_networkports`;
CREATE TABLE `glpi_networkports_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id_1` int(11) NOT NULL DEFAULT '0',
  `networkports_id_2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id_1`,`networkports_id_2`),
  KEY `networkports_id_2` (`networkports_id_2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_vlans

DROP TABLE IF EXISTS `glpi_networkports_vlans`;
CREATE TABLE `glpi_networkports_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  `tagged` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id`,`vlans_id`),
  KEY `vlans_id` (`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportwifis

DROP TABLE IF EXISTS `glpi_networkportwifis`;
CREATE TABLE `glpi_networkportwifis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `wifinetworks_id` int(11) NOT NULL DEFAULT '0',
  `networkportwifis_id` int(11) NOT NULL DEFAULT '0' COMMENT 'only useful in case of Managed node',
  `version` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'a, a/b, a/b/g, a/b/g/n, a/b/g/n/y',
  `mode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, managed, master, repeater, secondary, monitor, auto',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `essid` (`wifinetworks_id`),
  KEY `version` (`version`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networks

DROP TABLE IF EXISTS `glpi_networks`;
CREATE TABLE `glpi_networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notepads

DROP TABLE IF EXISTS `glpi_notepads`;
CREATE TABLE `glpi_notepads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date` (`date`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notifications

DROP TABLE IF EXISTS `glpi_notifications`;
CREATE TABLE `glpi_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notifications` VALUES ('1','Alert Tickets not closed','0','Ticket','alertnotclosed','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('2','New Ticket','0','Ticket','new','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('3','Update Ticket','0','Ticket','update','','1','0','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('4','Close Ticket','0','Ticket','closed','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('5','Add Followup','0','Ticket','add_followup','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('6','Add Task','0','Ticket','add_task','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('7','Update Followup','0','Ticket','update_followup','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('8','Update Task','0','Ticket','update_task','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('9','Delete Followup','0','Ticket','delete_followup','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('10','Delete Task','0','Ticket','delete_task','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('11','Resolve ticket','0','Ticket','solved','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('12','Ticket Validation','0','Ticket','validation','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('13','New Reservation','0','Reservation','new','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('14','Update Reservation','0','Reservation','update','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('15','Delete Reservation','0','Reservation','delete','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('16','Alert Reservation','0','Reservation','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('17','Contract Notice','0','Contract','notice','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('18','Contract End','0','Contract','end','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('19','MySQL Synchronization','0','DBConnection','desynchronization','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('20','Cartridges','0','CartridgeItem','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('21','Consumables','0','ConsumableItem','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('22','Infocoms','0','Infocom','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('23','Software Licenses','0','SoftwareLicense','alert','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('24','Ticket Recall','0','Ticket','recall','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('25','Password Forget','0','User','passwordforget','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('26','Ticket Satisfaction','0','Ticket','satisfaction','','1','1','2011-03-04 11:35:15',NULL);
INSERT INTO `glpi_notifications` VALUES ('27','Item not unique','0','FieldUnicity','refuse','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('28','Crontask Watcher','0','Crontask','alert','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('29','New Problem','0','Problem','new','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('30','Update Problem','0','Problem','update','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('31','Resolve Problem','0','Problem','solved','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('32','Add Task','0','Problem','add_task','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('33','Update Task','0','Problem','update_task','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('34','Delete Task','0','Problem','delete_task','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('35','Close Problem','0','Problem','closed','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('36','Delete Problem','0','Problem','delete','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('37','Ticket Validation Answer','0','Ticket','validation_answer','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('38','Contract End Periodicity','0','Contract','periodicity','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('39','Contract Notice Periodicity','0','Contract','periodicitynotice','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('40','Planning recall','0','PlanningRecall','planningrecall','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('41','Delete Ticket','0','Ticket','delete','','1','1','2014-01-15 14:35:26',NULL);
INSERT INTO `glpi_notifications` VALUES ('42','New Change','0','Change','new','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('43','Update Change','0','Change','update','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('44','Resolve Change','0','Change','solved','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('45','Add Task','0','Change','add_task','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('46','Update Task','0','Change','update_task','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('47','Delete Task','0','Change','delete_task','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('48','Close Change','0','Change','closed','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('49','Delete Change','0','Change','delete','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('50','Ticket Satisfaction Answer','0','Ticket','replysatisfaction','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('51','Receiver errors','0','MailCollector','error','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('52','New Project','0','Project','new','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('53','Update Project','0','Project','update','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('54','Delete Project','0','Project','delete','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('55','New Project Task','0','ProjectTask','new','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('56','Update Project Task','0','ProjectTask','update','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('57','Delete Project Task','0','ProjectTask','delete','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('58','Request Unlock Items','0','ObjectLock','unlock','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('59','New user in requesters','0','Ticket','requester_user','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('60','New group in requesters','0','Ticket','requester_group','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('61','New user in observers','0','Ticket','observer_user','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('62','New group in observers','0','Ticket','observer_group','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('63','New user in assignees','0','Ticket','assign_user','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('64','New group in assignees','0','Ticket','assign_group','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('65','New supplier in assignees','0','Ticket','assign_supplier','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('66','Saved searches','0','SavedSearch_Alert','alert','','1','1','2016-02-08 16:57:46',NULL);
INSERT INTO `glpi_notifications` VALUES ('67','Certificates','0','Certificate','alert','','1','1',NULL,NULL);

### Dump table glpi_notifications_notificationtemplates

DROP TABLE IF EXISTS `glpi_notifications_notificationtemplates`;
CREATE TABLE `glpi_notifications_notificationtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notifications_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'See Notification_NotificationTemplate::MODE_* constants',
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`notifications_id`,`mode`,`notificationtemplates_id`),
  KEY `notifications_id` (`notifications_id`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`),
  KEY `mode` (`mode`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('1','1','mailing','6');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('2','2','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('3','3','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('4','4','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('5','5','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('6','6','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('7','7','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('8','8','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('9','9','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('10','10','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('11','11','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('12','12','mailing','7');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('13','13','mailing','2');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('14','14','mailing','2');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('15','15','mailing','2');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('16','16','mailing','3');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('17','17','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('18','18','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('19','19','mailing','1');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('20','20','mailing','8');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('21','21','mailing','9');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('22','22','mailing','10');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('23','23','mailing','11');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('24','24','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('25','25','mailing','13');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('26','26','mailing','14');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('27','27','mailing','15');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('28','28','mailing','16');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('29','29','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('30','30','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('31','31','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('32','32','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('33','33','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('34','34','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('35','35','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('36','36','mailing','17');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('37','37','mailing','7');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('38','38','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('39','39','mailing','12');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('40','40','mailing','18');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('41','41','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('42','42','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('43','43','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('44','44','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('45','45','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('46','46','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('47','47','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('48','48','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('49','49','mailing','19');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('50','50','mailing','14');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('51','51','mailing','20');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('52','52','mailing','21');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('53','53','mailing','21');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('54','54','mailing','21');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('55','55','mailing','22');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('56','56','mailing','22');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('57','57','mailing','22');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('58','58','mailing','23');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('59','59','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('60','60','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('61','61','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('62','62','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('63','63','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('64','64','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('65','65','mailing','4');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('66','66','mailing','24');
INSERT INTO `glpi_notifications_notificationtemplates` VALUES ('67','67','mailing','25');

### Dump table glpi_notificationtargets

DROP TABLE IF EXISTS `glpi_notificationtargets`;
CREATE TABLE `glpi_notificationtargets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `notifications_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `items` (`type`,`items_id`),
  KEY `notifications_id` (`notifications_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtargets` VALUES ('1','3','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('2','1','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('3','3','2','2');
INSERT INTO `glpi_notificationtargets` VALUES ('4','1','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('5','1','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('6','1','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('7','1','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('8','2','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('9','4','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('10','3','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('11','3','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('12','3','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('13','3','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('14','1','1','19');
INSERT INTO `glpi_notificationtargets` VALUES ('15','14','1','12');
INSERT INTO `glpi_notificationtargets` VALUES ('16','3','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('17','1','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('18','3','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('19','1','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('20','1','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('21','3','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('22','1','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('23','3','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('24','1','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('25','3','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('26','1','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('27','3','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('28','1','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('29','3','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('30','1','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('31','3','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('32','19','1','25');
INSERT INTO `glpi_notificationtargets` VALUES ('33','3','1','26');
INSERT INTO `glpi_notificationtargets` VALUES ('34','21','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('35','21','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('36','21','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('37','21','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('38','21','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('39','21','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('40','21','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('41','21','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('42','21','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('43','21','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('75','1','1','41');
INSERT INTO `glpi_notificationtargets` VALUES ('46','1','1','28');
INSERT INTO `glpi_notificationtargets` VALUES ('47','3','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('48','1','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('49','21','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('50','2','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('51','4','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('52','3','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('53','1','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('54','21','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('55','3','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('56','1','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('57','21','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('58','3','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('59','1','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('60','21','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('61','3','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('62','1','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('63','21','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('64','3','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('65','1','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('66','21','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('67','3','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('68','1','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('69','21','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('70','3','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('71','1','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('72','21','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('73','14','1','37');
INSERT INTO `glpi_notificationtargets` VALUES ('74','3','1','40');
INSERT INTO `glpi_notificationtargets` VALUES ('76','3','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('77','1','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('78','21','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('79','2','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('80','4','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('81','3','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('82','1','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('83','21','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('84','3','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('85','1','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('86','21','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('87','3','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('88','1','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('89','21','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('90','3','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('91','1','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('92','21','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('93','3','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('94','1','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('95','21','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('96','3','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('97','1','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('98','21','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('99','3','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('100','1','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('101','21','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('102','3','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('103','2','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('104','1','1','51');
INSERT INTO `glpi_notificationtargets` VALUES ('105','27','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('106','1','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('107','28','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('108','27','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('109','1','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('110','28','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('111','27','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('112','1','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('113','28','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('114','31','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('115','1','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('116','32','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('117','31','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('118','1','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('119','32','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('120','31','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('121','1','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('122','32','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('123','19','1','58');
INSERT INTO `glpi_notificationtargets` VALUES ('124','3','1','59');
INSERT INTO `glpi_notificationtargets` VALUES ('125','13','1','60');
INSERT INTO `glpi_notificationtargets` VALUES ('126','21','1','61');
INSERT INTO `glpi_notificationtargets` VALUES ('127','20','1','62');
INSERT INTO `glpi_notificationtargets` VALUES ('128','2','1','63');
INSERT INTO `glpi_notificationtargets` VALUES ('129','23','1','64');
INSERT INTO `glpi_notificationtargets` VALUES ('130','8','1','65');
INSERT INTO `glpi_notificationtargets` VALUES ('131','19','1','66');

### Dump table glpi_notificationtemplates

DROP TABLE IF EXISTS `glpi_notificationtemplates`;
CREATE TABLE `glpi_notificationtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `css` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `itemtype` (`itemtype`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplates` VALUES ('1','MySQL Synchronization','DBConnection','2010-02-01 15:51:46','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('2','Reservations','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('3','Alert Reservation','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('4','Tickets','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('5','Tickets (Simple)','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('6','Alert Tickets not closed','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('7','Tickets Validation','Ticket','2010-02-26 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('8','Cartridges','CartridgeItem','2010-02-16 13:17:24','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('9','Consumables','ConsumableItem','2010-02-16 13:17:38','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('10','Infocoms','Infocom','2010-02-16 13:17:55','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('11','Licenses','SoftwareLicense','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('12','Contracts','Contract','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('13','Password Forget','User','2011-03-04 11:35:13',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('14','Ticket Satisfaction','Ticket','2011-03-04 11:35:15',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('15','Item not unique','FieldUnicity','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('16','Crontask','Crontask','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('17','Problems','Problem','2011-12-06 09:48:33',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('18','Planning recall','PlanningRecall','2014-01-15 14:35:24',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('19','Changes','Change','2014-06-18 08:02:07',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('20','Receiver errors','MailCollector','2014-06-18 08:02:08',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('21','Projects','Project','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('22','Project Tasks','ProjectTask','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('23','Unlock Item request','ObjectLock','2016-02-08 16:57:46',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('24','Saved searches alerts','SavedSearch_Alert','2017-04-05 14:57:34',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('25','Certificates','Certificate',NULL,'',NULL,NULL);

### Dump table glpi_notificationtemplatetranslations

DROP TABLE IF EXISTS `glpi_notificationtemplatetranslations`;
CREATE TABLE `glpi_notificationtemplatetranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `language` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_text` text COLLATE utf8_unicode_ci,
  `content_html` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('1','1','','##lang.dbconnection.title##','##lang.dbconnection.delay## : ##dbconnection.delay##
','&lt;p&gt;##lang.dbconnection.delay## : ##dbconnection.delay##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('2','2','','##reservation.action##','======================================================================
##lang.reservation.user##: ##reservation.user##
##lang.reservation.item.name##: ##reservation.itemtype## - ##reservation.item.name##
##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech## ##ENDIFreservation.tech##
##lang.reservation.begin##: ##reservation.begin##
##lang.reservation.end##: ##reservation.end##
##lang.reservation.comment##: ##reservation.comment##
======================================================================
','&lt;!-- description{ color: inherit; background: #ebebeb;border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; } --&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.user##:&lt;/span&gt;##reservation.user##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.item.name##:&lt;/span&gt;##reservation.itemtype## - ##reservation.item.name##&lt;br /&gt;##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech####ENDIFreservation.tech##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.begin##:&lt;/span&gt; ##reservation.begin##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.end##:&lt;/span&gt;##reservation.end##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.comment##:&lt;/span&gt; ##reservation.comment##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('3','3','','##reservation.action##  ##reservation.entity##','##lang.reservation.entity## : ##reservation.entity##


##FOREACHreservations##
##lang.reservation.itemtype## : ##reservation.itemtype##

 ##lang.reservation.item## : ##reservation.item##

 ##reservation.url##

 ##ENDFOREACHreservations##','&lt;p&gt;##lang.reservation.entity## : ##reservation.entity## &lt;br /&gt; &lt;br /&gt;
##FOREACHreservations## &lt;br /&gt;##lang.reservation.itemtype## :  ##reservation.itemtype##&lt;br /&gt;
 ##lang.reservation.item## :  ##reservation.item##&lt;br /&gt; &lt;br /&gt;
 &lt;a href=\"##reservation.url##\"&gt; ##reservation.url##&lt;/a&gt;&lt;br /&gt;
 ##ENDFOREACHreservations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('4','4','','##ticket.action## ##ticket.title##',' ##IFticket.storestatus=5##
 ##lang.ticket.url## : ##ticket.urlapprove##
 ##lang.ticket.autoclosewarning##
 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description## ##ENDIFticket.storestatus##
 ##ELSEticket.storestatus## ##lang.ticket.url## : ##ticket.url## ##ENDELSEticket.storestatus##

 ##lang.ticket.description##

 ##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.authors## : ##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors## ##ELSEticket.authors##--##ENDELSEticket.authors##
 ##lang.ticket.creationdate## : ##ticket.creationdate##
 ##lang.ticket.closedate## : ##ticket.closedate##
 ##lang.ticket.requesttype## : ##ticket.requesttype##
##lang.ticket.item.name## :

##FOREACHitems##

 ##IFticket.itemtype##
  ##ticket.itemtype## - ##ticket.item.name##
  ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model##
  ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial##
  ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial##
 ##ENDIFticket.itemtype##

##ENDFOREACHitems##
##IFticket.assigntousers## ##lang.ticket.assigntousers## : ##ticket.assigntousers## ##ENDIFticket.assigntousers##
 ##lang.ticket.status## : ##ticket.status##
##IFticket.assigntogroups## ##lang.ticket.assigntogroups## : ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##
 ##lang.ticket.urgency## : ##ticket.urgency##
 ##lang.ticket.impact## : ##ticket.impact##
 ##lang.ticket.priority## : ##ticket.priority##
##IFticket.user.email## ##lang.ticket.user.email## : ##ticket.user.email ##ENDIFticket.user.email##
##IFticket.category## ##lang.ticket.category## : ##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
 ##lang.ticket.content## : ##ticket.content##
 ##IFticket.storestatus=6##

 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description##
 ##ENDIFticket.storestatus##
 ##lang.ticket.numberoffollowups## : ##ticket.numberoffollowups##

##FOREACHfollowups##

 [##followup.date##] ##lang.followup.isprivate## : ##followup.isprivate##
 ##lang.followup.author## ##followup.author##
 ##lang.followup.description## ##followup.description##
 ##lang.followup.date## ##followup.date##
 ##lang.followup.requesttype## ##followup.requesttype##

##ENDFOREACHfollowups##
 ##lang.ticket.numberoftasks## : ##ticket.numberoftasks##

##FOREACHtasks##

 [##task.date##] ##lang.task.isprivate## : ##task.isprivate##
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##','<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div>##IFticket.storestatus=5##</div>
<div>##lang.ticket.url## : <a href=\"##ticket.urlapprove##\">##ticket.urlapprove##</a> <strong>&#160;</strong></div>
<div><strong>##lang.ticket.autoclosewarning##</strong></div>
<div><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.type##</strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description## ##ENDIFticket.storestatus##</div>
<div>##ELSEticket.storestatus## ##lang.ticket.url## : <a href=\"##ticket.url##\">##ticket.url##</a> ##ENDELSEticket.storestatus##</div>
<p class=\"description b\"><strong>##lang.ticket.description##</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.title##</span>&#160;:##ticket.title## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.authors##</span>&#160;:##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors##    ##ELSEticket.authors##--##ENDELSEticket.authors## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.creationdate##</span>&#160;:##ticket.creationdate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.closedate##</span>&#160;:##ticket.closedate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.requesttype##</span>&#160;:##ticket.requesttype##<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.item.name##</span>&#160;:
<p>##FOREACHitems##</p>
<div class=\"description b\">##IFticket.itemtype## ##ticket.itemtype##&#160;- ##ticket.item.name## ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model## ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial## ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial## ##ENDIFticket.itemtype## </div><br />
<p>##ENDFOREACHitems##</p>
##IFticket.assigntousers## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntousers##</span>&#160;: ##ticket.assigntousers## ##ENDIFticket.assigntousers##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.status## </span>&#160;: ##ticket.status##<br /> ##IFticket.assigntogroups## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntogroups##</span>&#160;: ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.urgency##</span>&#160;: ##ticket.urgency##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.impact##</span>&#160;: ##ticket.impact##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.priority##</span>&#160;: ##ticket.priority## <br /> ##IFticket.user.email##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.user.email##</span>&#160;: ##ticket.user.email ##ENDIFticket.user.email##    <br /> ##IFticket.category##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.category## </span>&#160;:##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##    <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.content##</span>&#160;: ##ticket.content##</p>
<br />##IFticket.storestatus=6##<br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solution.type##</span></strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description##<br />##ENDIFticket.storestatus##</p>
<div class=\"description b\">##lang.ticket.numberoffollowups##&#160;: ##ticket.numberoffollowups##</div>
<p>##FOREACHfollowups##</p>
<div class=\"description b\"><br /> <strong> [##followup.date##] <em>##lang.followup.isprivate## : ##followup.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.author## </span> ##followup.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.description## </span> ##followup.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.date## </span> ##followup.date##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.requesttype## </span> ##followup.requesttype##</div>
<p>##ENDFOREACHfollowups##</p>
<div class=\"description b\">##lang.ticket.numberoftasks##&#160;: ##ticket.numberoftasks##</div>
<p>##FOREACHtasks##</p>
<div class=\"description b\"><br /> <strong> [##task.date##] <em>##lang.task.isprivate## : ##task.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.author##</span> ##task.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.description##</span> ##task.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.time##</span> ##task.time##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.category##</span> ##task.category##</div>
<p>##ENDFOREACHtasks##</p>');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('5','12','','##contract.action##  ##contract.entity##','##lang.contract.entity## : ##contract.entity##

##FOREACHcontracts##
##lang.contract.name## : ##contract.name##
##lang.contract.number## : ##contract.number##
##lang.contract.time## : ##contract.time##
##IFcontract.type####lang.contract.type## : ##contract.type####ENDIFcontract.type##
##contract.url##
##ENDFOREACHcontracts##','&lt;p&gt;##lang.contract.entity## : ##contract.entity##&lt;br /&gt;
&lt;br /&gt;##FOREACHcontracts##&lt;br /&gt;##lang.contract.name## :
##contract.name##&lt;br /&gt;
##lang.contract.number## : ##contract.number##&lt;br /&gt;
##lang.contract.time## : ##contract.time##&lt;br /&gt;
##IFcontract.type####lang.contract.type## : ##contract.type##
##ENDIFcontract.type##&lt;br /&gt;
&lt;a href=\"##contract.url##\"&gt;
##contract.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcontracts##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('6','5','','##ticket.action## ##ticket.title##','##lang.ticket.url## : ##ticket.url##

##lang.ticket.description##


##lang.ticket.title##  :##ticket.title##

##lang.ticket.authors##  :##IFticket.authors##
##ticket.authors## ##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##

##IFticket.category## ##lang.ticket.category##  :##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##

##lang.ticket.content##  : ##ticket.content##
##IFticket.itemtype##
##lang.ticket.item.name##  : ##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##','&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.url##\"&gt;
##ticket.url##&lt;/a&gt;&lt;/div&gt;
&lt;div class=\"description b\"&gt;
##lang.ticket.description##&lt;/div&gt;
&lt;p&gt;&lt;span
style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.title##&lt;/span&gt;&#160;:##ticket.title##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.authors##&lt;/span&gt;
##IFticket.authors## ##ticket.authors##
##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;&#160
;&lt;/span&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;
##IFticket.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.category## &lt;/span&gt;&#160;:##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.content##&lt;/span&gt;&#160;:
##ticket.content##&lt;br /&gt;##IFticket.itemtype##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.item.name##&lt;/span&gt;&#160;:
##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('15','15','','##lang.unicity.action##','##lang.unicity.entity## : ##unicity.entity##

##lang.unicity.itemtype## : ##unicity.itemtype##

##lang.unicity.message## : ##unicity.message##

##lang.unicity.action_user## : ##unicity.action_user##

##lang.unicity.action_type## : ##unicity.action_type##

##lang.unicity.date## : ##unicity.date##','&lt;p&gt;##lang.unicity.entity## : ##unicity.entity##&lt;/p&gt;
&lt;p&gt;##lang.unicity.itemtype## : ##unicity.itemtype##&lt;/p&gt;
&lt;p&gt;##lang.unicity.message## : ##unicity.message##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_user## : ##unicity.action_user##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_type## : ##unicity.action_type##&lt;/p&gt;
&lt;p&gt;##lang.unicity.date## : ##unicity.date##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('7','7','','##ticket.action## ##ticket.title##','##FOREACHvalidations##

##IFvalidation.storestatus=2##
##validation.submission.title##
##lang.validation.commentsubmission## : ##validation.commentsubmission##
##ENDIFvalidation.storestatus##
##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##

##lang.ticket.url## : ##ticket.urlvalidation##

##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
##IFvalidation.commentvalidation##
##lang.validation.commentvalidation## : ##validation.commentvalidation##
##ENDIFvalidation.commentvalidation##
##ENDFOREACHvalidations##','&lt;div&gt;##FOREACHvalidations##&lt;/div&gt;
&lt;p&gt;##IFvalidation.storestatus=2##&lt;/p&gt;
&lt;div&gt;##validation.submission.title##&lt;/div&gt;
&lt;div&gt;##lang.validation.commentsubmission## : ##validation.commentsubmission##&lt;/div&gt;
&lt;div&gt;##ENDIFvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;&lt;/div&gt;
&lt;div&gt;
&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.urlvalidation##\"&gt; ##ticket.urlvalidation## &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;p&gt;##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
&lt;br /&gt; ##IFvalidation.commentvalidation##&lt;br /&gt; ##lang.validation.commentvalidation## :
&#160; ##validation.commentvalidation##&lt;br /&gt; ##ENDIFvalidation.commentvalidation##
&lt;br /&gt;##ENDFOREACHvalidations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('8','6','','##ticket.action## ##ticket.entity##','##lang.ticket.entity## : ##ticket.entity##

##FOREACHtickets##

##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.status## : ##ticket.status##

 ##ticket.url##
 ##ENDFOREACHtickets##','&lt;table class=\"tab_cadre\" border=\"1\" cellspacing=\"2\" cellpadding=\"3\"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.title##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.attribution##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##FOREACHtickets##
&lt;tr&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;&lt;a href=\"##ticket.url##\"&gt;##ticket.title##&lt;/a&gt;&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##IFticket.assigntousers####ticket.assigntousers##&lt;br /&gt;##ENDIFticket.assigntousers####IFticket.assigntogroups##&lt;br /&gt;##ticket.assigntogroups## ##ENDIFticket.assigntogroups####IFticket.assigntosupplier##&lt;br /&gt;##ticket.assigntosupplier## ##ENDIFticket.assigntosupplier##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##ENDFOREACHtickets##
&lt;/tbody&gt;
&lt;/table&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('9','9','','##consumable.action##  ##consumable.entity##','##lang.consumable.entity## : ##consumable.entity##


##FOREACHconsumables##
##lang.consumable.item## : ##consumable.item##


##lang.consumable.reference## : ##consumable.reference##

##lang.consumable.remaining## : ##consumable.remaining##

##consumable.url##

##ENDFOREACHconsumables##','&lt;p&gt;
##lang.consumable.entity## : ##consumable.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHconsumables##
&lt;br /&gt;##lang.consumable.item## : ##consumable.item##&lt;br /&gt;
&lt;br /&gt;##lang.consumable.reference## : ##consumable.reference##&lt;br /&gt;
##lang.consumable.remaining## : ##consumable.remaining##&lt;br /&gt;
&lt;a href=\"##consumable.url##\"&gt; ##consumable.url##&lt;/a&gt;&lt;br /&gt;
   ##ENDFOREACHconsumables##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('10','8','','##cartridge.action##  ##cartridge.entity##','##lang.cartridge.entity## : ##cartridge.entity##


##FOREACHcartridges##
##lang.cartridge.item## : ##cartridge.item##


##lang.cartridge.reference## : ##cartridge.reference##

##lang.cartridge.remaining## : ##cartridge.remaining##

##cartridge.url##
 ##ENDFOREACHcartridges##','&lt;p&gt;##lang.cartridge.entity## : ##cartridge.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHcartridges##
&lt;br /&gt;##lang.cartridge.item## :
##cartridge.item##&lt;br /&gt; &lt;br /&gt;
##lang.cartridge.reference## :
##cartridge.reference##&lt;br /&gt;
##lang.cartridge.remaining## :
##cartridge.remaining##&lt;br /&gt;
&lt;a href=\"##cartridge.url##\"&gt;
##cartridge.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcartridges##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('11','10','','##infocom.action##  ##infocom.entity##','##lang.infocom.entity## : ##infocom.entity##


##FOREACHinfocoms##

##lang.infocom.itemtype## : ##infocom.itemtype##

##lang.infocom.item## : ##infocom.item##


##lang.infocom.expirationdate## : ##infocom.expirationdate##

##infocom.url##
 ##ENDFOREACHinfocoms##','&lt;p&gt;##lang.infocom.entity## : ##infocom.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHinfocoms##
&lt;br /&gt;##lang.infocom.itemtype## : ##infocom.itemtype##&lt;br /&gt;
##lang.infocom.item## : ##infocom.item##&lt;br /&gt; &lt;br /&gt;
##lang.infocom.expirationdate## : ##infocom.expirationdate##
&lt;br /&gt; &lt;a href=\"##infocom.url##\"&gt;
##infocom.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHinfocoms##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('12','11','','##license.action##  ##license.entity##','##lang.license.entity## : ##license.entity##

##FOREACHlicenses##

##lang.license.item## : ##license.item##

##lang.license.serial## : ##license.serial##

##lang.license.expirationdate## : ##license.expirationdate##

##license.url##
 ##ENDFOREACHlicenses##','&lt;p&gt;
##lang.license.entity## : ##license.entity##&lt;br /&gt;
##FOREACHlicenses##
&lt;br /&gt;##lang.license.item## : ##license.item##&lt;br /&gt;
##lang.license.serial## : ##license.serial##&lt;br /&gt;
##lang.license.expirationdate## : ##license.expirationdate##
&lt;br /&gt; &lt;a href=\"##license.url##\"&gt; ##license.url##
&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHlicenses##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('13','13','','##user.action##','##user.realname## ##user.firstname##

##lang.passwordforget.information##

##lang.passwordforget.link## ##user.passwordforgeturl##','&lt;p&gt;&lt;strong&gt;##user.realname## ##user.firstname##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.information##&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.link## &lt;a title=\"##user.passwordforgeturl##\" href=\"##user.passwordforgeturl##\"&gt;##user.passwordforgeturl##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('14','14','','##ticket.action## ##ticket.title##','##lang.ticket.title## : ##ticket.title##

##lang.ticket.closedate## : ##ticket.closedate##

##lang.satisfaction.text## ##ticket.urlsatisfaction##','&lt;p&gt;##lang.ticket.title## : ##ticket.title##&lt;/p&gt;
&lt;p&gt;##lang.ticket.closedate## : ##ticket.closedate##&lt;/p&gt;
&lt;p&gt;##lang.satisfaction.text## &lt;a href=\"##ticket.urlsatisfaction##\"&gt;##ticket.urlsatisfaction##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('16','16','','##crontask.action##','##lang.crontask.warning##

##FOREACHcrontasks##
 ##crontask.name## : ##crontask.description##

##ENDFOREACHcrontasks##','&lt;p&gt;##lang.crontask.warning##&lt;/p&gt;
&lt;p&gt;##FOREACHcrontasks## &lt;br /&gt;&lt;a href=\"##crontask.url##\"&gt;##crontask.name##&lt;/a&gt; : ##crontask.description##&lt;br /&gt; &lt;br /&gt;##ENDFOREACHcrontasks##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('17','17','','##problem.action## ##problem.title##','##IFproblem.storestatus=5##
 ##lang.problem.url## : ##problem.urlapprove##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description## ##ENDIFproblem.storestatus##
 ##ELSEproblem.storestatus## ##lang.problem.url## : ##problem.url## ##ENDELSEproblem.storestatus##

 ##lang.problem.description##

 ##lang.problem.title##  :##problem.title##
 ##lang.problem.authors##  :##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors## ##ELSEproblem.authors##--##ENDELSEproblem.authors##
 ##lang.problem.creationdate##  :##problem.creationdate##
 ##IFproblem.assigntousers## ##lang.problem.assigntousers##  : ##problem.assigntousers## ##ENDIFproblem.assigntousers##
 ##lang.problem.status##  : ##problem.status##
 ##IFproblem.assigntogroups## ##lang.problem.assigntogroups##  : ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##
 ##lang.problem.urgency##  : ##problem.urgency##
 ##lang.problem.impact##  : ##problem.impact##
 ##lang.problem.priority## : ##problem.priority##
##IFproblem.category## ##lang.problem.category##  :##problem.category## ##ENDIFproblem.category## ##ELSEproblem.category## ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##
 ##lang.problem.content##  : ##problem.content##

##IFproblem.storestatus=6##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description##
##ENDIFproblem.storestatus##
 ##lang.problem.numberoftickets## : ##problem.numberoftickets##

##FOREACHtickets##
 [##ticket.date##] ##lang.problem.title## : ##ticket.title##
 ##lang.problem.content## ##ticket.content##

##ENDFOREACHtickets##
 ##lang.problem.numberoftasks## : ##problem.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFproblem.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.problem.url## : &lt;a href=\"##problem.urlapprove##\"&gt;##problem.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description## ##ENDIFproblem.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEproblem.storestatus## ##lang.problem.url## : &lt;a href=\"##problem.url##\"&gt;##problem.url##&lt;/a&gt; ##ENDELSEproblem.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.problem.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.title##&lt;/span&gt;&#160;:##problem.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.authors##&lt;/span&gt;&#160;:##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors##    ##ELSEproblem.authors##--##ENDELSEproblem.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.creationdate##&lt;/span&gt;&#160;:##problem.creationdate## &lt;br /&gt; ##IFproblem.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntousers##&lt;/span&gt;&#160;: ##problem.assigntousers## ##ENDIFproblem.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.status## &lt;/span&gt;&#160;: ##problem.status##&lt;br /&gt; ##IFproblem.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntogroups##&lt;/span&gt;&#160;: ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.urgency##&lt;/span&gt;&#160;: ##problem.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.impact##&lt;/span&gt;&#160;: ##problem.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.priority##&lt;/span&gt; : ##problem.priority## &lt;br /&gt;##IFproblem.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.category## &lt;/span&gt;&#160;:##problem.category##  ##ENDIFproblem.category## ##ELSEproblem.category##  ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.content##&lt;/span&gt;&#160;: ##problem.content##&lt;/p&gt;
&lt;p&gt;##IFproblem.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description##&lt;br /&gt;##ENDIFproblem.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftickets##&#160;: ##problem.numberoftickets##&lt;/div&gt;
&lt;p&gt;##FOREACHtickets##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##ticket.date##] &lt;em&gt;##lang.problem.title## : &lt;a href=\"##ticket.url##\"&gt;##ticket.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.content## &lt;/span&gt; ##ticket.content##
&lt;p&gt;##ENDFOREACHtickets##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftasks##&#160;: ##problem.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('18','18','','##recall.action##: ##recall.item.name##','##recall.action##: ##recall.item.name##

##recall.item.content##

##lang.recall.planning.begin##: ##recall.planning.begin##
##lang.recall.planning.end##: ##recall.planning.end##
##lang.recall.planning.state##: ##recall.planning.state##
##lang.recall.item.private##: ##recall.item.private##','&lt;p&gt;##recall.action##: &lt;a href=\"##recall.item.url##\"&gt;##recall.item.name##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;##recall.item.content##&lt;/p&gt;
&lt;p&gt;##lang.recall.planning.begin##: ##recall.planning.begin##&lt;br /&gt;##lang.recall.planning.end##: ##recall.planning.end##&lt;br /&gt;##lang.recall.planning.state##: ##recall.planning.state##&lt;br /&gt;##lang.recall.item.private##: ##recall.item.private##&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('19','19','','##change.action## ##change.title##','##IFchange.storestatus=5##
 ##lang.change.url## : ##change.urlapprove##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description## ##ENDIFchange.storestatus##
 ##ELSEchange.storestatus## ##lang.change.url## : ##change.url## ##ENDELSEchange.storestatus##

 ##lang.change.description##

 ##lang.change.title##  :##change.title##
 ##lang.change.authors##  :##IFchange.authors## ##change.authors## ##ENDIFchange.authors## ##ELSEchange.authors##--##ENDELSEchange.authors##
 ##lang.change.creationdate##  :##change.creationdate##
 ##IFchange.assigntousers## ##lang.change.assigntousers##  : ##change.assigntousers## ##ENDIFchange.assigntousers##
 ##lang.change.status##  : ##change.status##
 ##IFchange.assigntogroups## ##lang.change.assigntogroups##  : ##change.assigntogroups## ##ENDIFchange.assigntogroups##
 ##lang.change.urgency##  : ##change.urgency##
 ##lang.change.impact##  : ##change.impact##
 ##lang.change.priority## : ##change.priority##
##IFchange.category## ##lang.change.category##  :##change.category## ##ENDIFchange.category## ##ELSEchange.category## ##lang.change.nocategoryassigned## ##ENDELSEchange.category##
 ##lang.change.content##  : ##change.content##

##IFchange.storestatus=6##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description##
##ENDIFchange.storestatus##
 ##lang.change.numberofproblems## : ##change.numberofproblems##

##FOREACHproblems##
 [##problem.date##] ##lang.change.title## : ##problem.title##
 ##lang.change.content## ##problem.content##

##ENDFOREACHproblems##
 ##lang.change.numberoftasks## : ##change.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFchange.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.change.url## : &lt;a href=\"##change.urlapprove##\"&gt;##change.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description## ##ENDIFchange.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEchange.storestatus## ##lang.change.url## : &lt;a href=\"##change.url##\"&gt;##change.url##&lt;/a&gt; ##ENDELSEchange.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.change.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.title##&lt;/span&gt;&#160;:##change.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.authors##&lt;/span&gt;&#160;:##IFchange.authors## ##change.authors## ##ENDIFchange.authors##    ##ELSEchange.authors##--##ENDELSEchange.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.creationdate##&lt;/span&gt;&#160;:##change.creationdate## &lt;br /&gt; ##IFchange.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntousers##&lt;/span&gt;&#160;: ##change.assigntousers## ##ENDIFchange.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.status## &lt;/span&gt;&#160;: ##change.status##&lt;br /&gt; ##IFchange.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntogroups##&lt;/span&gt;&#160;: ##change.assigntogroups## ##ENDIFchange.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.urgency##&lt;/span&gt;&#160;: ##change.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.impact##&lt;/span&gt;&#160;: ##change.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.priority##&lt;/span&gt; : ##change.priority## &lt;br /&gt;##IFchange.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.category## &lt;/span&gt;&#160;:##change.category##  ##ENDIFchange.category## ##ELSEchange.category##  ##lang.change.nocategoryassigned## ##ENDELSEchange.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.content##&lt;/span&gt;&#160;: ##change.content##&lt;/p&gt;
&lt;p&gt;##IFchange.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description##&lt;br /&gt;##ENDIFchange.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberofproblems##&#160;: ##change.numberofproblems##&lt;/div&gt;
&lt;p&gt;##FOREACHproblems##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##problem.date##] &lt;em&gt;##lang.change.title## : &lt;a href=\"##problem.url##\"&gt;##problem.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.content## &lt;/span&gt; ##problem.content##
&lt;p&gt;##ENDFOREACHproblems##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberoftasks##&#160;: ##change.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('20','20','','##mailcollector.action##','##FOREACHmailcollectors##
##lang.mailcollector.name## : ##mailcollector.name##
##lang.mailcollector.errors## : ##mailcollector.errors##
##mailcollector.url##
##ENDFOREACHmailcollectors##','&lt;p&gt;##FOREACHmailcollectors##&lt;br /&gt;##lang.mailcollector.name## : ##mailcollector.name##&lt;br /&gt; ##lang.mailcollector.errors## : ##mailcollector.errors##&lt;br /&gt;&lt;a href=\"##mailcollector.url##\"&gt;##mailcollector.url##&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHmailcollectors##&lt;/p&gt;
&lt;p&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('21','21','','##project.action## ##project.name## ##project.code##','##lang.project.url## : ##project.url##

##lang.project.description##

##lang.project.name## : ##project.name##
##lang.project.code## : ##project.code##
##lang.project.manager## : ##project.manager##
##lang.project.managergroup## : ##project.managergroup##
##lang.project.creationdate## : ##project.creationdate##
##lang.project.priority## : ##project.priority##
##lang.project.state## : ##project.state##
##lang.project.type## : ##project.type##
##lang.project.description## : ##project.description##

##lang.project.numberoftasks## : ##project.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.project.url## : &lt;a href=\"##project.url##\"&gt;##project.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.project.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.project.name## : ##project.name##&lt;br /&gt;##lang.project.code## : ##project.code##&lt;br /&gt; ##lang.project.manager## : ##project.manager##&lt;br /&gt;##lang.project.managergroup## : ##project.managergroup##&lt;br /&gt; ##lang.project.creationdate## : ##project.creationdate##&lt;br /&gt;##lang.project.priority## : ##project.priority## &lt;br /&gt;##lang.project.state## : ##project.state##&lt;br /&gt;##lang.project.type## : ##project.type##&lt;br /&gt;##lang.project.description## : ##project.description##&lt;/p&gt;
&lt;p&gt;##lang.project.numberoftasks## : ##project.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt; ##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('22','22','','##projecttask.action## ##projecttask.name##','##lang.projecttask.url## : ##projecttask.url##

##lang.projecttask.description##

##lang.projecttask.name## : ##projecttask.name##
##lang.projecttask.project## : ##projecttask.project##
##lang.projecttask.creationdate## : ##projecttask.creationdate##
##lang.projecttask.state## : ##projecttask.state##
##lang.projecttask.type## : ##projecttask.type##
##lang.projecttask.description## : ##projecttask.description##

##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.projecttask.url## : &lt;a href=\"##projecttask.url##\"&gt;##projecttask.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.projecttask.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.projecttask.name## : ##projecttask.name##&lt;br /&gt;##lang.projecttask.project## : &lt;a href=\"##projecttask.projecturl##\"&gt;##projecttask.project##&lt;/a&gt;&lt;br /&gt;##lang.projecttask.creationdate## : ##projecttask.creationdate##&lt;br /&gt;##lang.projecttask.state## : ##projecttask.state##&lt;br /&gt;##lang.projecttask.type## : ##projecttask.type##&lt;br /&gt;##lang.projecttask.description## : ##projecttask.description##&lt;/p&gt;
&lt;p&gt;##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt;##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('23','23','','##objectlock.action##','##objectlock.type## ###objectlock.id## - ##objectlock.name##

      ##lang.objectlock.url##
      ##objectlock.url##

      ##lang.objectlock.date_mod##
      ##objectlock.date_mod##

      Hello ##objectlock.lockedby.firstname##,
      Could go to this item and unlock it for me?
      Thank you,
      Regards,
      ##objectlock.requester.firstname##','&lt;table&gt;
      &lt;tbody&gt;
      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##objectlock.url##\"&gt;##objectlock.type## ###objectlock.id## - ##objectlock.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.url##&lt;/td&gt;
      &lt;td&gt;##objectlock.url##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.date_mod##&lt;/td&gt;
      &lt;td&gt;##objectlock.date_mod##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;/tbody&gt;
      &lt;/table&gt;
      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello ##objectlock.lockedby.firstname##,&lt;br /&gt;Could go to this item and unlock it for me?&lt;br /&gt;Thank you,&lt;br /&gt;Regards,&lt;br /&gt;##objectlock.requester.firstname## ##objectlock.requester.lastname##&lt;/span&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('24','24','','##savedsearch.action## ##savedsearch.name##','##savedsearch.type## ###savedsearch.id## - ##savedsearch.name##

      ##savedsearch.message##

      ##lang.savedsearch.url##
      ##savedsearch.url##

      Regards,','&lt;table&gt;
      &lt;tbody&gt;
      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##savedsearch.url##\"&gt;##savedsearch.type## ###savedsearch.id## - ##savedsearch.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;
      &lt;tr&gt;&lt;td colspan=\"2\"&gt;&lt;a href=\"##savedsearch.url##\"&gt;##savedsearch.message##&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.savedsearch.url##&lt;/td&gt;
      &lt;td&gt;##savedsearch.url##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;/tbody&gt;
      &lt;/table&gt;
      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello &lt;br /&gt;Regards,&lt;/span&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('25','25','','##certificate.action##  ##certificate.entity##','##lang.certificate.entity## : ##certificate.entity##

##FOREACHcertificates##

##lang.certificate.serial## : ##certificate.serial##

##lang.certificate.expirationdate## : ##certificate.expirationdate##

##certificate.url##
 ##ENDFOREACHcertificates##','&lt;p&gt;
##lang.certificate.entity## : ##certificate.entity##&lt;br /&gt;
##FOREACHcertificates##
&lt;br /&gt;##lang.certificate.name## : ##certificate.name##&lt;br /&gt;
##lang.certificate.serial## : ##certificate.serial##&lt;br /&gt;
##lang.certificate.expirationdate## : ##certificate.expirationdate##
&lt;br /&gt; &lt;a href=\"##certificate.url##\"&gt; ##certificate.url##
&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHcertificates##&lt;/p&gt;');

### Dump table glpi_notimportedemails

DROP TABLE IF EXISTS `glpi_notimportedemails`;
CREATE TABLE `glpi_notimportedemails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `mailcollectors_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `subject` text,
  `messageid` varchar(255) NOT NULL,
  `reason` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `mailcollectors_id` (`mailcollectors_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


### Dump table glpi_objectlocks

DROP TABLE IF EXISTS `glpi_objectlocks`;
CREATE TABLE `glpi_objectlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Type of locked object',
  `items_id` int(11) NOT NULL COMMENT 'RELATION to various tables, according to itemtype (ID)',
  `users_id` int(11) NOT NULL COMMENT 'id of the locker',
  `date_mod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the lock',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevelactions

DROP TABLE IF EXISTS `glpi_olalevelactions`;
CREATE TABLE `glpi_olalevelactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olalevels_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `olalevels_id` (`olalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevelcriterias

DROP TABLE IF EXISTS `glpi_olalevelcriterias`;
CREATE TABLE `glpi_olalevelcriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `olalevels_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `olalevels_id` (`olalevels_id`),
  KEY `condition` (`condition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevels

DROP TABLE IF EXISTS `glpi_olalevels`;
CREATE TABLE `glpi_olalevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `olas_id` int(11) NOT NULL DEFAULT '0',
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `olas_id` (`olas_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olalevels_tickets

DROP TABLE IF EXISTS `glpi_olalevels_tickets`;
CREATE TABLE `glpi_olalevels_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `olalevels_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`olalevels_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `olalevels_id` (`olalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_olas

DROP TABLE IF EXISTS `glpi_olas`;
CREATE TABLE `glpi_olas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `number_time` int(11) NOT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `definition_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_of_working_day` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `slms_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `calendars_id` (`calendars_id`),
  KEY `slms_id` (`slms_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemarchitectures

DROP TABLE IF EXISTS `glpi_operatingsystemarchitectures`;
CREATE TABLE `glpi_operatingsystemarchitectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemeditions

DROP TABLE IF EXISTS `glpi_operatingsystemeditions`;
CREATE TABLE `glpi_operatingsystemeditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemkernels

DROP TABLE IF EXISTS `glpi_operatingsystemkernels`;
CREATE TABLE `glpi_operatingsystemkernels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemkernelversions

DROP TABLE IF EXISTS `glpi_operatingsystemkernelversions`;
CREATE TABLE `glpi_operatingsystemkernelversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `operatingsystemkernels_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `operatingsystemkernels_id` (`operatingsystemkernels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystems

DROP TABLE IF EXISTS `glpi_operatingsystems`;
CREATE TABLE `glpi_operatingsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemservicepacks

DROP TABLE IF EXISTS `glpi_operatingsystemservicepacks`;
CREATE TABLE `glpi_operatingsystemservicepacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemversions

DROP TABLE IF EXISTS `glpi_operatingsystemversions`;
CREATE TABLE `glpi_operatingsystemversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheralmodels

DROP TABLE IF EXISTS `glpi_peripheralmodels`;
CREATE TABLE `glpi_peripheralmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripherals

DROP TABLE IF EXISTS `glpi_peripherals`;
CREATE TABLE `glpi_peripherals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `peripheraltypes_id` int(11) NOT NULL DEFAULT '0',
  `peripheralmodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `peripheralmodels_id` (`peripheralmodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `peripheraltypes_id` (`peripheraltypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheraltypes

DROP TABLE IF EXISTS `glpi_peripheraltypes`;
CREATE TABLE `glpi_peripheraltypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonemodels

DROP TABLE IF EXISTS `glpi_phonemodels`;
CREATE TABLE `glpi_phonemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_phonemodels` VALUES ('1','SAMSUNG','','','2018-04-26 12:40:45','2018-04-26 12:40:45');
INSERT INTO `glpi_phonemodels` VALUES ('2','NOKIA','','','2018-04-26 12:40:49','2018-04-26 12:40:49');
INSERT INTO `glpi_phonemodels` VALUES ('3','WIKO','','','2018-04-26 12:40:55','2018-04-26 12:40:55');

### Dump table glpi_phonepowersupplies

DROP TABLE IF EXISTS `glpi_phonepowersupplies`;
CREATE TABLE `glpi_phonepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phones

DROP TABLE IF EXISTS `glpi_phones`;
CREATE TABLE `glpi_phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `phonetypes_id` int(11) NOT NULL DEFAULT '0',
  `phonemodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `number_line` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_headset` tinyint(1) NOT NULL DEFAULT '0',
  `have_hp` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `phonemodels_id` (`phonemodels_id`),
  KEY `phonepowersupplies_id` (`phonepowersupplies_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `phonetypes_id` (`phonetypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonetypes

DROP TABLE IF EXISTS `glpi_phonetypes`;
CREATE TABLE `glpi_phonetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_planningrecalls

DROP TABLE IF EXISTS `glpi_planningrecalls`;
CREATE TABLE `glpi_planningrecalls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `before_time` int(11) NOT NULL DEFAULT '-10',
  `when` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`users_id`),
  KEY `users_id` (`users_id`),
  KEY `before_time` (`before_time`),
  KEY `when` (`when`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_comproveedores_annualbillings

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_annualbillings`;
CREATE TABLE `glpi_plugin_comproveedores_annualbillings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anio` date DEFAULT NULL,
  `facturacion` decimal(12,0) DEFAULT NULL,
  `beneficios_impuestos` decimal(12,0) DEFAULT NULL,
  `resultado` decimal(12,0) DEFAULT NULL,
  `total_activo` decimal(12,0) DEFAULT NULL,
  `activo_circulante` decimal(12,0) DEFAULT NULL,
  `pasivo_circulante` decimal(12,0) DEFAULT NULL,
  `cash_flow` decimal(12,0) DEFAULT NULL,
  `fondos_propios` decimal(12,0) DEFAULT NULL,
  `recursos_ajenos` decimal(12,0) DEFAULT NULL,
  `cv_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `externalid` (`externalid`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_annualbillings` VALUES ('1','2018-00-00','0','0','0','0','0','0','0','0','0','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_annualbillings` VALUES ('2','2017-00-00','0','0','0','0','0','0','0','0','0','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_annualbillings` VALUES ('3','2016-00-00','0','0','0','0','0','0','0','0','0','5','0','0',NULL,NULL);

### Dump table glpi_plugin_comproveedores_categories

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_categories`;
CREATE TABLE `glpi_plugin_comproveedores_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `glpi_plugin_comproveedores_roltypes_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('1','SUMINISTRO_MATERIALES_PARA_OBRA_CIVIL','1');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('2','SUMINISTRO_MATERIALES_PARA_ACABADOS','1');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('3','SUMINISTRO_AISLAMIENTOS_Y_TRATAMIENTOS_ESPECÍFICOS','1');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('4','SUMINISTRO_MATERIALES_PARA_INSTALACIONES_ELECTROMECÁNICAS','1');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('5','CONTRATISTA_GENERAL_OBRA_CIVIL','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('6','CONTRATISTA_ESPECIALISTA_ACONDICIONAMIENTO_INTEGRAL__FIT_OUT','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('7','CONTRATISTA_GENERAL_INSTALACIONES_ELECTROMECÁNICAS','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('8','CONTRATISTA_MEDIOS_AUXILIARES__PRELIMINARES','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('9','CONTRATISTA_SEGURIDAD_Y_SALUD','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('10','CONTRATISTA_ESPECIALIDADES_OBRA_CIVIL__SUBESTRUCTURA_Y_ESTRUCTURA','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('11','CONTRATISTA_ESPECIALIDADES_OBRA_CIVIL__SOLUCIONES_PREFABRICADAS','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('12','CONTRATISTA_ESPECIALIDADES_OBRA_CIVIL__ALBAÑILERÍA','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('13','CONTRATISTA_ESPECIALIDADES_OBRA_CIVIL__FACHADA','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('14','CONTRATISTA_ESPECIALIDADES_OBRA_CIVIL__CUBIERTAS','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('15','CONTRATISTA_ESPECIALIDADES_OBRA_CIVIL__URBANIZACIÓN_Y_PAISAJISMO','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('16','CONTRATISTA_AISLAMIENTOS_Y_TRATAMIENTOS_ESPECÍFICOS','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('17','CONTRATISTA_ESPECIALIDADES_ACABADOS','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('18','CONTRATISTA_INSTALACIONES_ELÉCTRICAS','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('19','CONTRATISTA_INSTALACIONES_MECÁNICAS','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('20','CONTRATISTA_INSTALACIONES_ESPECIALES','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('21','CONTRATISTA_MEDIOS_DE_ELEVACIÓN','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('22','CONTRATISTA_DE_REHABILITACIÓN','2');
INSERT INTO `glpi_plugin_comproveedores_categories` VALUES ('23','CONTRATISTA_DE_EQUIPAMIENTO','2');

### Dump table glpi_plugin_comproveedores_communities

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_communities`;
CREATE TABLE `glpi_plugin_comproveedores_communities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('1','Andalucía','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('2','Aragón','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('3','Principado de Asturias','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('4','Illes Balears','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('5','Canarias','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('6','Cantabria','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('7','Castilla y León','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('8','Castilla - La Mancha','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('9','Cataluña','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('10','Comunitat Valenciana','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('11','Extremadura','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('12','Galicia','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('13','Comunidad de Madrid ','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('14','Región de Murcia','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('15','Comunidad Foral de Navarra','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('16','País Vasco','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('17','La Rioja','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('18','Ceuta','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_communities` VALUES ('19','Melilla','0',NULL,'0','0');

### Dump table glpi_plugin_comproveedores_comproveedores

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_comproveedores`;
CREATE TABLE `glpi_plugin_comproveedores_comproveedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `is_helpdesk_visible` int(11) NOT NULL DEFAULT '1',
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugin_comproveedores_cvs

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_cvs`;
CREATE TABLE `glpi_plugin_comproveedores_cvs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  `empresa_matriz_nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empresa_matriz_direccion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empresa_matriz_pais` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empresa_matriz_ciudad` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empresa_matriz_provincia` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empresa_matriz_CP` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `titulacion_superior` int(11) NOT NULL DEFAULT '0',
  `titulacion_grado_medio` int(11) NOT NULL DEFAULT '0',
  `tecnicos_no_universitarios` int(11) NOT NULL DEFAULT '0',
  `personal` int(11) NOT NULL DEFAULT '0',
  `otros_categoria_numeros_empleados` int(11) NOT NULL DEFAULT '0',
  `capital_social` decimal(20,2) DEFAULT NULL,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `externalid` (`externalid`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_cvs` VALUES ('4','Construcciones Lopez','2','','0','','','','','0','0','0','0','0',NULL,'0','0','0','ulyhuo,lg',NULL);
INSERT INTO `glpi_plugin_comproveedores_cvs` VALUES ('5','ACCIONA CONSTRUCCIÓN, S.A.','3','CORPORACIÓN ACCIONA INFRAESTRUCTURAS S.A.','0','','ALCOBENDAS','MADRID','','0','0','0','0','0','0.00','0','0','0','',NULL);

### Dump table glpi_plugin_comproveedores_empleados

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_empleados`;
CREATE TABLE `glpi_plugin_comproveedores_empleados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empleados_eventuales` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empleados_fijos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `anio` int(11) DEFAULT NULL,
  `cv_id` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_empleados` VALUES ('1','316','1883','2016','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_empleados` VALUES ('2','303','2185','2015','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_empleados` VALUES ('3','752','2228','2014','5','0',NULL,'0','0');

### Dump table glpi_plugin_comproveedores_experiences

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_experiences`;
CREATE TABLE `glpi_plugin_comproveedores_experiences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `estado` tinyint(1) NOT NULL,
  `intervencion_bovis` tinyint(1) NOT NULL DEFAULT '0',
  `plugin_comproveedores_experiencestypes_id` int(11) NOT NULL,
  `plugin_comproveedores_communities_id` int(11) DEFAULT NULL,
  `cliente` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `anio` date DEFAULT NULL,
  `importe` decimal(20,2) DEFAULT NULL,
  `duracion` int(11) DEFAULT NULL,
  `bim` tinyint(1) DEFAULT NULL,
  `breeam` tinyint(1) DEFAULT NULL,
  `leed` tinyint(1) DEFAULT NULL,
  `otros_certificados` tinyint(1) DEFAULT NULL,
  `cpd_tier` tinyint(1) DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cv_id` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('1','sdfgsdfg','0','0','0','0','','2018-05-31','0.00','0','0','0','0','0','0','','1','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('3','proyecto 1','0','0','0','13','Comunidad de Madrid','2018-05-22','120.00','12','0','1','0','0','0','','4','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('4','proyecto 2','0','0','0','11','CCAA Extremadura','2018-05-30','500.00','24','1','0','1','0','1','','4','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('5','DESIGN AND CONSTRUCTION OF RAILWAY PROJECT DUBAI METRO 2020','0','0','0','0','ROADS AND TRANSPORT AUTORITY - DUBAI','2018-00-00','1.38','45','1','0','0','0','0','','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('6','EJECUCIÓN DE LA PRIMERA LINEA DEL METRO DE QUITO,, FASE 2: CONSTRUCCIÓN DE LAS OBRAS CIVILES Y PROVISION Y MONTAJE DEL SISTEMA DE EQUIPAMIENTOS E INSTALACIONES. ECUADOR','1','0','0','0','MUNICIPIO DEL DISTRITO METROPOLITANO DE QUITO','2018-00-00','1.63','36','-1','-1','-1','-1','-1','','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('7','OBRAS DE CONTRUCCIÓN DEL CENTRO POLIVALENTE DE LA CALLE BARCELÓ DE MADRID','1','0','2','13','AYTO. MADRID','2010-00-00','40476456.19','51','0','0','0','0','0','','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('12','EJECUCIÓN  DE LAS OBRAS AMPLIACIÓN  DEL HOSPITAL PRINCIPES DE ESPAÑA EN EL HOSPITALET DEL LLOBERGAT','1','0','3','9','G. CAT-GISA','2010-00-00','60529223.08','62','0','1','0','0','0','','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('9','REMODELACIÓN (1ª FASE) DEL MUSEO ARQUEOLÓGICO NACIONAL EN MADRID. MADRID','0','0','5','13','MINISTERIO DE CULTURA','2008-00-00','36317551.13','46','0','0','0','0','0','','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('10','NUEVO CENTRO PARA CONSERVATORIO DE MÚSICA \"MUSIKENE\" DE DONOSTÍA, EN SAN SEBASTIÁN, GUIPÚZCOA.','0','0','5','16','GOBIERNO VASCO','2012-00-00','17946909.82','27','0','0','0','0','0','','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('11','DESARROLLO DE LOS ESPACIOS INTERIORES DEL PALACIO DE CONGRESOS, CORRESPONDIENTE A LA SEGUNDA FASE DE LA ACTUACIÓN \"APARCAMIENTO, REMONTE MECÁNICO Y EQUIPAMIENTO CULTURAL PALACIO DE CONGRESOS EN SANFONT DE TOLEDO','0','0','5','8','EMPRESA MUNICIPAL DE LA VIVIENDA DE TOLEDO, S.A.','2009-00-00','17284299.27','41',NULL,NULL,NULL,NULL,NULL,'','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiences` VALUES ('13','HOTEL SANTA BÁRBARA, EN LA PALMA','1','1','4','4','SHEDIR MALLORCA','2016-00-00','276033058.00','80','0','0','0','0','1','','5','0',NULL,'0','0');

### Dump table glpi_plugin_comproveedores_experiencestypes

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_experiencestypes`;
CREATE TABLE `glpi_plugin_comproveedores_experiencestypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('1','Oficinas','Edificios de oficinas','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('2','Comercio','Centros comerciales / locales comerciales','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('3','Salud','Proyectos de Hospitales y centros sanitarios','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('4','Hoteles/Residencias','Proyectos de Hoteles / Residencias de la 3a edad / Residencias de estudiantes','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('5','Cultura','Proyectos de equipamiento de museos, Centros culturales, Auditorios, Centros de convenciones y palacios de congresos','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('6','Enseñanza','Centros docentes (Universidades, Institutos de enseñanza, guarderías infantiles.. )','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('7','Deportivo','Complejos deportivos(Estadios de fútbol, Pabellones deportivos, Polideportivos, etc)','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('8','Industria','Proyectos industriales/Logísticos','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('9','Vivienda','Proyectos de vivienda residenciales','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('10','Rehabilitación','Obras de rehabilitación de edificios','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_experiencestypes` VALUES ('11','CPD/Otros','Centro de procesos de datos(CPD) y otros proyectos','0',NULL,'0','0');

### Dump table glpi_plugin_comproveedores_featuredcompanies

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_featuredcompanies`;
CREATE TABLE `glpi_plugin_comproveedores_featuredcompanies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empresa_destacada` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `puesto` int(11) NOT NULL DEFAULT '0',
  `cv_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `externalid` (`externalid`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_featuredcompanies` VALUES ('1','ACCIONA CONSTRUCCIÓN, S.A.','1','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_featuredcompanies` VALUES ('2','','2','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_featuredcompanies` VALUES ('3','','3','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_featuredcompanies` VALUES ('4','','4','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_featuredcompanies` VALUES ('5','','5','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_featuredcompanies` VALUES ('6','','6','5','0','0',NULL,NULL);

### Dump table glpi_plugin_comproveedores_insurances

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_insurances`;
CREATE TABLE `glpi_plugin_comproveedores_insurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cia_aseguradora` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cuantia` int(11) NOT NULL DEFAULT '0',
  `fecha_caducidad` date DEFAULT NULL,
  `numero_empleados_asegurados` int(11) NOT NULL DEFAULT '0',
  `cv_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_insurances` VALUES ('2','Resposabilidad civil','MAPFRE','10000','2018-12-31','2000','4','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_insurances` VALUES ('3','Resposabilidad civil','XXX','1000','2018-12-31','150','4','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_insurances` VALUES ('4','Seguro todo riesgo','XXX','1000','2018-12-31','0','4','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_insurances` VALUES ('5','Resposabilidad civil','XL Insurance Company SE, Sucursal en España		','10000000','2017-04-30','0','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_insurances` VALUES ('6','Todo Riesgo de daños Materiales Concesiones','Royal & Sun Alliance Insurance plc, Sucursal en España','125000000','0000-00-00','0','5','0',NULL,'0','0');
INSERT INTO `glpi_plugin_comproveedores_insurances` VALUES ('7','Seguro accidentes de trabajo','VIDACAIXA','0','2018-01-01','0','5','0',NULL,'0','0');

### Dump table glpi_plugin_comproveedores_integratedmanagementsystems

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_integratedmanagementsystems`;
CREATE TABLE `glpi_plugin_comproveedores_integratedmanagementsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_gestion` tinyint(1) NOT NULL DEFAULT '0',
  `obs_plan_gestion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `control_documentos` tinyint(1) NOT NULL DEFAULT '0',
  `obs_control_documentos` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `politica_calidad` tinyint(1) NOT NULL DEFAULT '0',
  `obs_politica_calidad` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auditorias_internas` tinyint(1) NOT NULL DEFAULT '0',
  `obs_auditorias_internas` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `plan_sostenibilidad` tinyint(1) NOT NULL DEFAULT '0',
  `obs_plan_sostenibilidad` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sg_medioambiental` tinyint(1) NOT NULL DEFAULT '0',
  `obs_sg_medioambiental` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `acciones_rsc` tinyint(1) NOT NULL DEFAULT '0',
  `obs_acciones_rsc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gestion_rsc` tinyint(1) NOT NULL DEFAULT '0',
  `obs_gestion_rsc` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sg_seguridad_y_salud` tinyint(1) NOT NULL DEFAULT '0',
  `obs_sg_seguridad_y_salud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `certificado_formacion` tinyint(1) NOT NULL DEFAULT '0',
  `obs_certificado_formacion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `departamento_segurida_y_salud` tinyint(1) NOT NULL DEFAULT '0',
  `obs_departamento_segurida_y_salud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `metodologia_segurida_y_salud` tinyint(1) NOT NULL DEFAULT '0',
  `obs_metodologia_segurida_y_salud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `formacion_segurida_y_salud` tinyint(1) NOT NULL DEFAULT '0',
  `obs_formacion_segurida_y_salud` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empleado_rp` tinyint(1) NOT NULL DEFAULT '0',
  `obs_empleado_rp` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `empresa_asesoramiento` tinyint(1) NOT NULL DEFAULT '0',
  `obs_empresa_asesoramiento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `procedimiento_subcontratistas` tinyint(1) NOT NULL DEFAULT '0',
  `obs_procedimiento_subcontratistas` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cv_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `externalid` (`externalid`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_integratedmanagementsystems` VALUES ('1','1','','0','','0','','0','','0','','0','','0','','0','','0','','0','','0','','0','','0','','0','','0','','0','','5','0','0',NULL,NULL);

### Dump table glpi_plugin_comproveedores_listspecialties

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_listspecialties`;
CREATE TABLE `glpi_plugin_comproveedores_listspecialties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plugin_comproveedores_roltypes_id` int(11) DEFAULT NULL,
  `plugin_comproveedores_categories_id` int(11) NOT NULL,
  `plugin_comproveedores_specialties_id` int(11) DEFAULT NULL,
  `cv_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

INSERT INTO `glpi_plugin_comproveedores_listspecialties` VALUES ('2','1','1','59','1');
INSERT INTO `glpi_plugin_comproveedores_listspecialties` VALUES ('6','2','14','106','4');
INSERT INTO `glpi_plugin_comproveedores_listspecialties` VALUES ('7','1','2','141','4');

### Dump table glpi_plugin_comproveedores_lossratios

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_lossratios`;
CREATE TABLE `glpi_plugin_comproveedores_lossratios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `anio` date DEFAULT NULL,
  `incidencia` decimal(4,2) DEFAULT NULL,
  `frecuencia` decimal(4,2) DEFAULT NULL,
  `gravedad` decimal(4,2) DEFAULT NULL,
  `cv_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `externalid` (`externalid`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_lossratios` VALUES ('1','2018-00-00','1.00','0.00','1.00','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_lossratios` VALUES ('2','2017-00-00','2.00','1.00','0.00','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_lossratios` VALUES ('3','2016-00-00','0.00','0.00','0.00','5','0','0',NULL,NULL);

### Dump table glpi_plugin_comproveedores_previousnamescompanies

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_previousnamescompanies`;
CREATE TABLE `glpi_plugin_comproveedores_previousnamescompanies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha_cambio` datetime(6) DEFAULT NULL,
  `cv_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `externalid` (`externalid`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_previousnamescompanies` VALUES ('1','ACCIONA CONSTRUCCIÓN, S.A.','2018-05-14 14:57:00.270256','5','0','0',NULL,NULL);

### Dump table glpi_plugin_comproveedores_roltypes

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_roltypes`;
CREATE TABLE `glpi_plugin_comproveedores_roltypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

INSERT INTO `glpi_plugin_comproveedores_roltypes` VALUES ('1','Suministrador');
INSERT INTO `glpi_plugin_comproveedores_roltypes` VALUES ('2','Contratista');

### Dump table glpi_plugin_comproveedores_specialties

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_specialties`;
CREATE TABLE `glpi_plugin_comproveedores_specialties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `glpi_plugin_comproveedores_categories_id` int(11) NOT NULL,
  `name` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('1','0','SUMINISTRO_MATERIALES_Y_ELEMENTOS_ESTRUCTURALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('2','0','SUMINISTRO_MORTEROS,_ADITIVOS,_ADHESIVOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('3','0','SUMINISTRO_ELEMENTOS_PREFABRICADOS_DE_HORMIGÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('4','0','SUMINISTRO_ELEMENTOS_PREFABRICADOS_DE_GRC');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('5','0','SUMINISTRO_OTROS_PREFABRICADOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('6','0','SUMINISTRO_PIEDRA_NATURAL_(MÁRMOLES,_GRANITOS,_CALIZAS,_PIZARRAS)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('7','0','SUMINISTRO_MATERIALES_CERÁMICOS_(BALDOSAS,_ALICATADOS,_REVESTIMIENTOS_CERÁMICOS)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('8','0','SUMINISTRO_FALSOS_TECHOS_METÁLICOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('9','0','SUMINISTRO_FALSOS_TECHOS_FIBRAS_MINERALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('10','0','SUMINISTRO_FALSOS_TECHOS_MADERAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('11','0','SUMINISTRO_MAMPARAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('12','0','MATERIALES_AISLAMIENTO_TÉRMICO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('13','0','MATERIALES_AISLAMIENTO_ACÚSTICO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('14','0','LÁMINAS_Y_MATERIALES_IMPERMEABILIZACIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('15','0','SUMINISTRO_EQUIPOS_Y_ELEMENTOS_PARA_INSTALACIONES_ELÉCTRICAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('16','0','SUMINISTRO_EQUIPOS_Y_ELEMENTOS_PARA_INSTALACIONES_ELÉCTRICAS_-_LUMINARIAS_E_ILUMINACIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('17','0','SUMINISTRO_EQUIPOS_Y_ELEMENTOS_PARA_INSTALACIONES_DE_FONTANERÍA_Y_SANEAMIENTO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('18','0','SUMINISTRO_EQUIPOS_Y_ELEMENTOS_PARA_INSTALACIONES_DE_CLIMATIZACIÓN,_VENTILACIÓN_Y_EXTRACCIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('19','0','SUMINISTRO_EQUIPOS_Y_ELEMENTOS_PARA_PROTECCIÓN_CONTRA_INCENDIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('20','0','SUMINISTRO_EQUIPOS_Y_ELEMENTOS_PARA_INSTALACIONES_ESPECIALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('21','0','CONTRATISTA_GENERAL_OBRA_CIVIL_GRANDE');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('22','0','CONTRATISTA_GENERAL_OBRA_CIVIL_MEDIANO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('23','0','CONTRATISTA_GENERAL_OBRA_CIVIL_PEQUEÑO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('24','0','CONTRATISTA_ESPECIALISTA_ACONDICIONAMIENTO_INTEGRAL_OFICINAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('25','0','CONTRATISTA_ESPECIALISTA_ACONDICIONAMIENTO_INTEGRAL_OFICINAS_BANCARIAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('26','0','CONTRATISTA_ESPECIALISTA_ACONDICIONAMIENTO_INTEGRAL_LOCALES_COMERCIALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('27','0','CONTRATISTA_GENERAL_INSTALACIONES_ELECTROMECÁNICAS_MEDIANO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('28','0','CONTRATISTA_GENERAL_INSTALACIONES_ELECTROMECÁNICAS_PEQUEÑO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('29','0','ALQUILER_GRÚAS_TORRE');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('30','0','ALQUILER_Y_MONTAJE_CASETAS_PREFABRICADAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('31','0','ALQUILER_CONTENEDORES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('32','0','INSTALACIONES_PROVISIONALES_OBRA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('33','0','ALQUILER_GRUPOS_ELECTRÓGENOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('34','0','ALQUILER_GRÚAS_AUTOMÓVILES_Y_SOBRE_CAMIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('35','0','SUMINISTRO_/_INSTALACIÓN_CERRAMIENTOS_PROVISIONALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('36','0','SUMINISTRO_MATERIAL_Y_EQUIPAMIENTO_OFICINA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('37','0','ALQUILER_ANDAMIOS_Y_CIMBRAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('38','0','ALQUILER_PLATAFORMAS_TIJERA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('39','0','ALQUILER_MONTACARGAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('40','0','ALQUILER_ANDAMIOS_CREMALLERA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('41','0','ALQUILER_CESTAS_BRAZO_ARTICULADO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('42','0','ALQUILER_MAQUINARIA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('43','0','EMPRESAS_DE_SEGURIDAD_Y_VIGILANCIA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('44','0','AMBULANCIAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('45','0','EMPRESAS_MULTISERVICIO_-_\"MULTIGANG\"');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('46','0','LIMPIEZA_DE_OBRA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('47','0','EMPRESAS_INSTALACIÓN_SISTEMAS_SEGURIDAD_Y_VIGILANCIA_OBRA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('48','0','INSTALACIÓN_Y_MANTENIMIENTO_DE_MEDIDAS_Y_ELEMENTOS_DE_PROTECCIÓN_COLECTIVA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('49','0','DEMOLICIONES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('50','0','MOVIMIENTO_DE_TIERRAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('51','0','MOVIMIENTO_DE_TIERRAS_-_VOLADURAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('52','0','GUNITADOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('53','0','PROTECCIÓN_/_ESTABILIZACIÓN_DE_TALUDES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('54','0','PILOTES_/_MUROS_PANTALLA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('55','0','MICROPILOTES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('56','0','MEJORA_Y_ESTABILIZACIÓN_DE_SUELOS_/_INYECCIONES_/_JET_GROUTING');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('57','0','ESTRUCTURAS_DE_HORMIGÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('58','0','ESTRUCTURAS_METÁLICAS_PERFILES_LAMINADOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('59','0','ESTRUCTURAS_METÁLICAS_ESPACIALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('60','0','ESTRUCTURAS_DE_MADERA_LAMINADA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('61','0','ESTRUCTURAS_PREFABRICADAS_DE_HORMIGÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('62','0','FORJADOS_COLABORANTES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('63','0','SOLUCIONES_INTEGRALES_PREFABRICADAS_-_ASEOS_PREFABRICADOS,_COCINAS_PREF.');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('64','0','SOLUCIONES_INTEGRALES_PREFABRICADAS_-_EDIFICACIÓN_MODULAR');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('65','0','SOLUCIONES_INTEGRALES_PREFABRICADAS_-_QUIRÓFANOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('66','0','LADRILLO_VISTO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('67','0','ALBAÑILERÍA_EN_GENERAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('68','0','YESOS_/_ENFOSCADOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('69','0','REVOCOS_/_MONOCAPAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('70','0','MÓDULOS_PREFABRICADOS_DE_HORMIGÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('71','0','REVOCOS_/_MONOCAPAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('72','0','YESOS_/_ENFOSCADOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('73','0','FACHADAS_APLACADO_PIEDRA_NATURAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('74','0','FACHADAS_VENTILADAS_PANELES_COMPOSITE');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('75','0','FACHADAS_VENTILADAS_CERÁMICAS_-_HORMIGÓN_POLÍMERO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('76','0','FACHADAS_METÁLICAS_(CHAPA,_PANEL_SANDWICH)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('77','0','FACHADAS_VENTILADAS_PANELES_TIPO_FENÓLICO,_TRESPA,_PRODEMA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('78','0','MURO_CORTINA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('79','0','CARPINTERÍA_EXTERIOR_METÁLICA_(ALUMINIO,_ACERO_INOX)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('80','0','CARPINTERÍA_EXTERIOR_DE_MADERA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('81','0','CARPINTERÍA_EXTERIOR_DE_PVC');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('82','0','REVESTIMIENTOS_MONOCAPA_/_REVOCOS_/_ENFOSCADOS_/_PÉTREOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('83','0','REVESTIMIENTO_PANELES_TIPO_FENÓLICO,_TRESPA,_PRODEMA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('84','0','ARQUITECTURA_TEXTIL_');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('85','0','DOBLE_PIEL_/_SISTEMAS_OSCURECIMIENTO_/_SOMBREAMIENTO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('86','0','GÓNDOLAS_-_SISTEMAS_LIMPIEZA_FACHADAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('87','0','OTRAS_FACHADAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('88','0','CUBIERTAS_DECK');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('89','0','CUBIERTAS_METÁLICAS_(ZINC,_COBRE)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('90','0','LUCERNARIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('91','0','CUBIERTAS_PANEL_SANDWICH');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('92','0','IMPERMEABILIZACIÓN_LÁMINAS_ASFÁLTICAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('93','0','IMPERMEABILIZACIÓN_POLIURETANO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('94','0','IMPERMEABILIZACIÓN_LÁMINAS_PVC');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('95','0','CUBIERTAS_AJARDINADAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('96','0','CUBIERTAS_TIPO_EFTE');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('97','0','CUBIERTAS_MATERIALES_LIGEROS_TIPO_METACRILATO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('98','0','CUBIERTAS_TEJAS_CERÁMICAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('99','0','CUBIERTA_PIZARRA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('100','0','IMPERMEABILIZACIONES_EN_GENERAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('101','0','OTRAS_CUBIERTAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('102','0','URBANIZACIÓN_EN_GENERAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('103','0','PAVIMENTOS_ASFÁLTICOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('104','0','JARDINERÍA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('105','0','FUENTES_DECORATIVAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('106','0','AISLAMIENTOS_TÉRMICOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('107','0','AISLAMIENTOS_ACÚSTICOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('108','0','TRATAMIENTOS_IGNÍFUGOS_Y_PROTECCIONES_CONTRA_FUEGO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('109','0','JUNTAS_DE_DILATACIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('110','0','FALSOS_TECHOS_METÁLICOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('111','0','FALSOS_TECHOS_MODULARES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('112','0','FALSOS_TECHOS_CARTÓN-YESO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('113','0','SUELO_TÉCNICO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('114','0','SOLADOS_RESINAS_/_INDUSTRIALES_/_EPOXI');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('115','0','SOLADOS_DE_PIEDRA_NATURAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('116','0','SOLADOS_DE_TERRAZO_IN_SITU_-_CONTINUO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('117','0','SOLADOS_DE_TERRAZO_EN_BALDOSAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('118','0','SOLADOS_DE_MADERA_(TARIMAS_/_PARQUET)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('119','0','SOLADOS_DE_BALDOSAS_CERÁMICAS_/_GRES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('120','0','SOLADOS_PLÁSTICOS_(VINÍLO,_PVC,_LINOLEO)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('121','0','SOLADOS_DEPORTIVOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('122','0','MOQUETAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('123','0','TABIQUES_MÓVILES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('124','0','MAMPARAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('125','0','MAMPARAS_ASEOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('126','0','PINTURAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('127','0','CERRAJERÍA_GRUESA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('128','0','METALISTERÍA_(ACERO_INOXIDABLE,_ACERO,_ALUMINIO,_OTROS_METALES)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('129','0','VALLADOS_Y_CERRAMIENTOS_METÁLICOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('130','0','PUERTAS_RF');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('131','0','PUERTAS_METÁLICAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('132','0','PUERTAS_DE_MADERA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('133','0','PUERTAS_AUTOMÁTICAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('134','0','PUERTAS_ESPECIALES_-_GRANDES_DIMENSIONES_-_INDUSTRIALES_-HANGARES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('135','0','CARPINTERÍA_DE_MADERA_EN_GENERAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('136','0','PANELES_TIPO_FENÓLICO,_TRESPA,_PRODEMA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('137','0','CHAPADOS_Y_REVESTIMIENTOS_PIEDRA_NATURAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('138','0','VIDRIERÍA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('139','0','SEÑALETICA_');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('140','0','ELEMENTOS_E_INSTALACIONES_ACÚSTICAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('141','0','ACABADOS_EN_GENERAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('142','0','OTROS_ACABADOS_ESPECÍFICOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('143','0','INSTALACIONES_ELÉCTRICAS_BAJA_TENSIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('144','0','INSTALACIONES_ELÉCTRICAS_MEDIA_TENSIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('145','0','CENTROS_DE_TRANSFORMACIÓN-_CELDAS_Y_TRAFOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('146','0','DETECCIÓN_DE_INCENDIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('147','0','FONTANERÍA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('148','0','SANEAMIENTO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('149','0','POCERÍA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('150','0','GAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('151','0','CLIMATIZACIÓN_-_VENTILACIÓN_-_EXTRACCIÓN');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('152','0','EXTINCIÓN_DE_INCENDIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('153','0','INSTALACIONES_PARTICULARES_CPD');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('154','0','INSTALACIÓN_PROTECCIÓN_CONTRAINCENDIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('155','0','INSTALACIÓN_ENERGÍA_SOLAR_(FOTOVOLTAICA_/SOLAR_TÉRMICA)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('156','0','INSTALACIONES_DE_VOZ_Y_DATOS_/_TELEFONÍA_/_COMUNICACIONES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('157','0','CONTROL_DE_ACCESOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('158','0','SEGURIDAD_-_CCTV');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('159','0','INSTALACIONES_DE_DOMÓTICA');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('160','0','INSTALACION_GESTIÓN_INTEGRAL_DEL_EDIFICIO_(BMS)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('161','0','INSTALACIÓN_DETECCIÓN_ESPECIAL_(TIPO_VESDA)');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('162','0','SISTEMAS_ESPECIALES_DE_EXTINCIÓN_DE_INCENDIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('163','0','INSTALACION_DE_CONTEO_DE_PERSONAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('164','0','INSTALACION_DE_GESTIÓN_Y_GUIADO_DE_PARKINGS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('165','0','INSTALACIONES_AUDIOVISUALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('166','0','ASCENSORES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('167','0','ESCALERAS_MECÁNICAS_Y_\"TRAVELATORS\"');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('168','0','MONTACARGAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('169','0','REHABILITACIÓN_COMPLETA_DE_EDIFICIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('170','0','REFUERZOS_Y_REHABILITACIÓN_ESTRUCTURAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('171','0','REHABILITACIÓN_FACHADAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('172','0','REHABILITACIONES_Y_REFORMAS_INTERIORES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('173','0','EQUIPAMIENTO_HOTELES_/_RESIDENCIAS_ESTUDIANTES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('174','0','EQUIPAMIENTO_HOSPITALES_/_RESIDENCIAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('175','0','MOBILIARIO_Y_EQUIPAMIENTO_DE_OFICINAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('176','0','MOBILIARIO_Y_EQUIPAMIENTO_DE_CENTROS_COMERCIALES');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('177','0','MOBILIARIO_Y_EQUIPAMIENTO_DEPORTIVO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('178','0','MOBILIARIO_URBANO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('179','0','EQUIPAMIENTO_DE_COCINAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('180','0','EQUIPAMIENTO_EN_GENERAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('181','0','MOBILIARIO_Y_EQUIPAMIENTO_ESPECÍFICO_DE_LABORATORIOS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('182','0','SPA_Y_SAUNAS');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('183','0','EQUIPAMIENTO_AUDIOVISUAL');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('184','0','EQUIPAMIENTO_INFORMÁTICO');
INSERT INTO `glpi_plugin_comproveedores_specialties` VALUES ('185','23','PRIMERA');

### Dump table glpi_plugin_comproveedores_subcontractingcompanies

DROP TABLE IF EXISTS `glpi_plugin_comproveedores_subcontractingcompanies`;
CREATE TABLE `glpi_plugin_comproveedores_subcontractingcompanies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_empresa_subcontratista` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `puesto` int(11) NOT NULL DEFAULT '0',
  `cv_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `externalid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `externalid` (`externalid`),
  KEY `entities_id` (`entities_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('1','ACCIONA CONSTRUCCIÓN, S.A.','1','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('2','','2','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('3','','3','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('4','','4','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('5','','5','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('6','','6','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('7','','7','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('8','','8','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('9','','9','5','0','0',NULL,NULL);
INSERT INTO `glpi_plugin_comproveedores_subcontractingcompanies` VALUES ('10','','10','5','0','0',NULL,NULL);

### Dump table glpi_plugins

DROP TABLE IF EXISTS `glpi_plugins`;
CREATE TABLE `glpi_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `directory` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PLUGIN_* constant',
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `homepage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`directory`),
  KEY `state` (`state`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugins` VALUES ('1','comproveedores','Gestion avanzada de proveedores','1.0.0','1','Fotex:Daniel Torvisco, Julio Márquez','https://fotex.es','GPLv3+');

### Dump table glpi_printermodels

DROP TABLE IF EXISTS `glpi_printermodels`;
CREATE TABLE `glpi_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `product_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `product_number` (`product_number`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_printers

DROP TABLE IF EXISTS `glpi_printers`;
CREATE TABLE `glpi_printers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_serial` tinyint(1) NOT NULL DEFAULT '0',
  `have_parallel` tinyint(1) NOT NULL DEFAULT '0',
  `have_usb` tinyint(1) NOT NULL DEFAULT '0',
  `have_wifi` tinyint(1) NOT NULL DEFAULT '0',
  `have_ethernet` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `memory_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `printertypes_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `init_pages_counter` int(11) NOT NULL DEFAULT '0',
  `last_pages_counter` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `printermodels_id` (`printermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `printertypes_id` (`printertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `last_pages_counter` (`last_pages_counter`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_printertypes

DROP TABLE IF EXISTS `glpi_printertypes`;
CREATE TABLE `glpi_printertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problemcosts

DROP TABLE IF EXISTS `glpi_problemcosts`;
CREATE TABLE `glpi_problemcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `problems_id` (`problems_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems

DROP TABLE IF EXISTS `glpi_problems`;
CREATE TABLE `glpi_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `time_to_resolve` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `causecontent` longtext COLLATE utf8_unicode_ci,
  `symptomcontent` longtext COLLATE utf8_unicode_ci,
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `time_to_resolve` (`time_to_resolve`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_suppliers

DROP TABLE IF EXISTS `glpi_problems_suppliers`;
CREATE TABLE `glpi_problems_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_tickets

DROP TABLE IF EXISTS `glpi_problems_tickets`;
CREATE TABLE `glpi_problems_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_users

DROP TABLE IF EXISTS `glpi_problems_users`;
CREATE TABLE `glpi_problems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problemtasks

DROP TABLE IF EXISTS `glpi_problemtasks`;
CREATE TABLE `glpi_problemtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `tasktemplates_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `problems_id` (`problems_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `state` (`state`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `tasktemplates_id` (`tasktemplates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profilerights

DROP TABLE IF EXISTS `glpi_profilerights`;
CREATE TABLE `glpi_profilerights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rights` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`profiles_id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profilerights` VALUES ('1','1','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('2','1','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('3','1','software','0');
INSERT INTO `glpi_profilerights` VALUES ('4','1','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('5','1','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('6','1','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('7','1','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('8','1','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('9','1','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('10','1','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('734','6','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('12','1','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('13','1','document','0');
INSERT INTO `glpi_profilerights` VALUES ('14','1','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('15','1','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('16','1','knowbase','10240');
INSERT INTO `glpi_profilerights` VALUES ('20','1','reservation','1024');
INSERT INTO `glpi_profilerights` VALUES ('21','1','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('22','1','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('24','1','device','0');
INSERT INTO `glpi_profilerights` VALUES ('25','1','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('26','1','link','0');
INSERT INTO `glpi_profilerights` VALUES ('27','1','config','0');
INSERT INTO `glpi_profilerights` VALUES ('29','1','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('30','1','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('31','1','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('32','1','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('33','1','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('684','5','location','0');
INSERT INTO `glpi_profilerights` VALUES ('679','7','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('36','1','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('37','1','user','0');
INSERT INTO `glpi_profilerights` VALUES ('39','1','group','0');
INSERT INTO `glpi_profilerights` VALUES ('40','1','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('41','1','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('42','1','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('43','1','reminder_public','1');
INSERT INTO `glpi_profilerights` VALUES ('44','1','rssfeed_public','1');
INSERT INTO `glpi_profilerights` VALUES ('45','1','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('46','1','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('47','1','ticket','131077');
INSERT INTO `glpi_profilerights` VALUES ('51','1','followup','5');
INSERT INTO `glpi_profilerights` VALUES ('52','1','task','1');
INSERT INTO `glpi_profilerights` VALUES ('64','1','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('716','2','state','0');
INSERT INTO `glpi_profilerights` VALUES ('709','2','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('67','1','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('68','1','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('70','1','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('71','1','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('72','1','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('73','1','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('75','1','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('76','1','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('728','7','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('79','1','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('80','1','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('81','1','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('85','1','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('702','2','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('697','4','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('691','5','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('89','1','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('90','1','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('91','1','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('671','6','changevalidation','20');
INSERT INTO `glpi_profilerights` VALUES ('94','1','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('95','2','computer','33');
INSERT INTO `glpi_profilerights` VALUES ('96','2','monitor','33');
INSERT INTO `glpi_profilerights` VALUES ('97','2','software','33');
INSERT INTO `glpi_profilerights` VALUES ('98','2','networking','33');
INSERT INTO `glpi_profilerights` VALUES ('99','2','internet','1');
INSERT INTO `glpi_profilerights` VALUES ('100','2','printer','33');
INSERT INTO `glpi_profilerights` VALUES ('101','2','peripheral','33');
INSERT INTO `glpi_profilerights` VALUES ('102','2','cartridge','33');
INSERT INTO `glpi_profilerights` VALUES ('103','2','consumable','33');
INSERT INTO `glpi_profilerights` VALUES ('104','2','phone','33');
INSERT INTO `glpi_profilerights` VALUES ('733','5','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('106','2','contact_enterprise','33');
INSERT INTO `glpi_profilerights` VALUES ('107','2','document','33');
INSERT INTO `glpi_profilerights` VALUES ('108','2','contract','33');
INSERT INTO `glpi_profilerights` VALUES ('109','2','infocom','1');
INSERT INTO `glpi_profilerights` VALUES ('110','2','knowbase','10241');
INSERT INTO `glpi_profilerights` VALUES ('114','2','reservation','1025');
INSERT INTO `glpi_profilerights` VALUES ('115','2','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('116','2','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('118','2','device','0');
INSERT INTO `glpi_profilerights` VALUES ('119','2','typedoc','1');
INSERT INTO `glpi_profilerights` VALUES ('120','2','link','1');
INSERT INTO `glpi_profilerights` VALUES ('121','2','config','0');
INSERT INTO `glpi_profilerights` VALUES ('123','2','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('124','2','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('125','2','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('126','2','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('127','2','search_config','1055');
INSERT INTO `glpi_profilerights` VALUES ('683','4','location','31');
INSERT INTO `glpi_profilerights` VALUES ('678','6','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('130','2','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('131','2','user','2049');
INSERT INTO `glpi_profilerights` VALUES ('133','2','group','1');
INSERT INTO `glpi_profilerights` VALUES ('134','2','entity','32');
INSERT INTO `glpi_profilerights` VALUES ('135','2','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('136','2','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('137','2','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('138','2','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('139','2','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('140','2','backup','1024');
INSERT INTO `glpi_profilerights` VALUES ('141','2','ticket','168989');
INSERT INTO `glpi_profilerights` VALUES ('145','2','followup','5');
INSERT INTO `glpi_profilerights` VALUES ('146','2','task','1');
INSERT INTO `glpi_profilerights` VALUES ('748','6','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('749','7','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('158','2','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('715','1','state','0');
INSERT INTO `glpi_profilerights` VALUES ('708','1','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('161','2','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('162','2','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('164','2','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('165','2','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('166','2','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('167','2','budget','33');
INSERT INTO `glpi_profilerights` VALUES ('169','2','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('170','2','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('726','5','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('727','6','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('173','2','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('174','2','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('175','2','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('179','2','problem','1057');
INSERT INTO `glpi_profilerights` VALUES ('701','1','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('696','3','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('690','4','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('183','2','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('184','2','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('185','2','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('669','4','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('670','5','changevalidation','20');
INSERT INTO `glpi_profilerights` VALUES ('188','2','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('189','3','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('190','3','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('191','3','software','0');
INSERT INTO `glpi_profilerights` VALUES ('192','3','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('193','3','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('194','3','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('195','3','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('196','3','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('197','3','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('198','3','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('732','4','queuednotification','31');
INSERT INTO `glpi_profilerights` VALUES ('200','3','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('201','3','document','127');
INSERT INTO `glpi_profilerights` VALUES ('202','3','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('203','3','infocom','31');
INSERT INTO `glpi_profilerights` VALUES ('204','3','knowbase','14367');
INSERT INTO `glpi_profilerights` VALUES ('208','3','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('209','3','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('210','3','dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('212','3','device','31');
INSERT INTO `glpi_profilerights` VALUES ('213','3','typedoc','31');
INSERT INTO `glpi_profilerights` VALUES ('214','3','link','31');
INSERT INTO `glpi_profilerights` VALUES ('215','3','config','0');
INSERT INTO `glpi_profilerights` VALUES ('217','3','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('218','3','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('219','3','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('220','3','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('221','3','search_config','3103');
INSERT INTO `glpi_profilerights` VALUES ('682','3','location','31');
INSERT INTO `glpi_profilerights` VALUES ('677','5','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('224','3','profile','1');
INSERT INTO `glpi_profilerights` VALUES ('225','3','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('227','3','group','31');
INSERT INTO `glpi_profilerights` VALUES ('228','3','entity','96');
INSERT INTO `glpi_profilerights` VALUES ('229','3','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('230','3','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('231','3','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('232','3','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('233','3','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('234','3','backup','1024');
INSERT INTO `glpi_profilerights` VALUES ('235','3','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('239','3','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('240','3','task','0');
INSERT INTO `glpi_profilerights` VALUES ('745','3','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('746','4','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('747','5','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('252','3','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('714','7','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('707','7','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('255','3','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('256','3','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('258','3','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('259','3','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('260','3','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('261','3','budget','127');
INSERT INTO `glpi_profilerights` VALUES ('263','3','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('264','3','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('724','3','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('725','4','solutiontemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('267','3','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('268','3','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('269','3','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('273','3','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('695','2','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('689','3','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('277','3','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('278','3','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('279','3','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('667','2','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('668','3','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('282','3','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('283','4','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('284','4','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('285','4','software','0');
INSERT INTO `glpi_profilerights` VALUES ('286','4','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('287','4','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('288','4','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('289','4','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('290','4','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('291','4','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('292','4','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('294','4','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('295','4','document','127');
INSERT INTO `glpi_profilerights` VALUES ('296','4','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('297','4','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('298','4','knowbase','15519');
INSERT INTO `glpi_profilerights` VALUES ('302','4','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('303','4','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('304','4','dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('306','4','device','31');
INSERT INTO `glpi_profilerights` VALUES ('307','4','typedoc','31');
INSERT INTO `glpi_profilerights` VALUES ('308','4','link','159');
INSERT INTO `glpi_profilerights` VALUES ('309','4','config','31');
INSERT INTO `glpi_profilerights` VALUES ('311','4','rule_ticket','1055');
INSERT INTO `glpi_profilerights` VALUES ('312','4','rule_import','31');
INSERT INTO `glpi_profilerights` VALUES ('313','4','rule_ldap','31');
INSERT INTO `glpi_profilerights` VALUES ('314','4','rule_softwarecategories','31');
INSERT INTO `glpi_profilerights` VALUES ('315','4','search_config','3103');
INSERT INTO `glpi_profilerights` VALUES ('681','2','location','0');
INSERT INTO `glpi_profilerights` VALUES ('676','4','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('318','4','profile','159');
INSERT INTO `glpi_profilerights` VALUES ('319','4','user','7327');
INSERT INTO `glpi_profilerights` VALUES ('321','4','group','159');
INSERT INTO `glpi_profilerights` VALUES ('322','4','entity','3327');
INSERT INTO `glpi_profilerights` VALUES ('323','4','transfer','31');
INSERT INTO `glpi_profilerights` VALUES ('324','4','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('325','4','reminder_public','159');
INSERT INTO `glpi_profilerights` VALUES ('326','4','rssfeed_public','159');
INSERT INTO `glpi_profilerights` VALUES ('327','4','bookmark_public','31');
INSERT INTO `glpi_profilerights` VALUES ('328','4','backup','1055');
INSERT INTO `glpi_profilerights` VALUES ('329','4','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('333','4','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('334','4','task','0');
INSERT INTO `glpi_profilerights` VALUES ('742','7','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('743','1','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('744','2','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('346','4','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('713','6','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('706','6','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('349','4','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('350','4','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('352','4','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('353','4','rule_dictionnary_software','31');
INSERT INTO `glpi_profilerights` VALUES ('354','4','rule_dictionnary_dropdown','31');
INSERT INTO `glpi_profilerights` VALUES ('355','4','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('357','4','notification','31');
INSERT INTO `glpi_profilerights` VALUES ('358','4','rule_mailcollector','31');
INSERT INTO `glpi_profilerights` VALUES ('722','1','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('723','2','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('361','4','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('362','4','slm','31');
INSERT INTO `glpi_profilerights` VALUES ('363','4','rule_dictionnary_printer','31');
INSERT INTO `glpi_profilerights` VALUES ('367','4','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('694','1','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('688','2','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('371','4','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('372','4','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('373','4','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('665','7','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('666','1','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('376','4','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('377','5','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('378','5','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('379','5','software','0');
INSERT INTO `glpi_profilerights` VALUES ('380','5','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('381','5','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('382','5','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('383','5','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('384','5','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('385','5','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('386','5','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('731','3','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('388','5','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('389','5','document','0');
INSERT INTO `glpi_profilerights` VALUES ('390','5','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('391','5','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('392','5','knowbase','8192');
INSERT INTO `glpi_profilerights` VALUES ('396','5','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('397','5','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('398','5','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('400','5','device','0');
INSERT INTO `glpi_profilerights` VALUES ('401','5','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('402','5','link','0');
INSERT INTO `glpi_profilerights` VALUES ('403','5','config','0');
INSERT INTO `glpi_profilerights` VALUES ('405','5','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('406','5','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('407','5','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('408','5','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('409','5','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('680','1','location','0');
INSERT INTO `glpi_profilerights` VALUES ('675','3','domain','31');
INSERT INTO `glpi_profilerights` VALUES ('412','5','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('413','5','user','1025');
INSERT INTO `glpi_profilerights` VALUES ('415','5','group','0');
INSERT INTO `glpi_profilerights` VALUES ('416','5','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('417','5','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('418','5','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('419','5','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('420','5','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('421','5','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('422','5','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('423','5','ticket','140295');
INSERT INTO `glpi_profilerights` VALUES ('427','5','followup','12295');
INSERT INTO `glpi_profilerights` VALUES ('428','5','task','8193');
INSERT INTO `glpi_profilerights` VALUES ('739','4','project','1279');
INSERT INTO `glpi_profilerights` VALUES ('740','5','project','1150');
INSERT INTO `glpi_profilerights` VALUES ('741','6','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('440','5','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('712','5','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('705','5','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('443','5','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('444','5','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('446','5','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('447','5','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('448','5','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('449','5','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('451','5','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('452','5','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('720','6','state','0');
INSERT INTO `glpi_profilerights` VALUES ('721','7','state','31');
INSERT INTO `glpi_profilerights` VALUES ('455','5','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('456','5','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('457','5','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('461','5','problem','1024');
INSERT INTO `glpi_profilerights` VALUES ('700','7','knowbasecategory','31');
INSERT INTO `glpi_profilerights` VALUES ('687','1','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('465','5','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('466','5','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('467','5','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('663','5','change','1054');
INSERT INTO `glpi_profilerights` VALUES ('664','6','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('470','5','ticketvalidation','3088');
INSERT INTO `glpi_profilerights` VALUES ('471','6','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('472','6','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('473','6','software','127');
INSERT INTO `glpi_profilerights` VALUES ('474','6','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('475','6','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('476','6','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('477','6','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('478','6','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('479','6','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('480','6','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('730','2','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('482','6','contact_enterprise','96');
INSERT INTO `glpi_profilerights` VALUES ('483','6','document','127');
INSERT INTO `glpi_profilerights` VALUES ('484','6','contract','96');
INSERT INTO `glpi_profilerights` VALUES ('485','6','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('486','6','knowbase','14367');
INSERT INTO `glpi_profilerights` VALUES ('490','6','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('491','6','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('492','6','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('494','6','device','0');
INSERT INTO `glpi_profilerights` VALUES ('495','6','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('496','6','link','0');
INSERT INTO `glpi_profilerights` VALUES ('497','6','config','0');
INSERT INTO `glpi_profilerights` VALUES ('499','6','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('500','6','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('501','6','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('502','6','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('503','6','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('674','2','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('506','6','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('507','6','user','1055');
INSERT INTO `glpi_profilerights` VALUES ('509','6','group','1');
INSERT INTO `glpi_profilerights` VALUES ('510','6','entity','97');
INSERT INTO `glpi_profilerights` VALUES ('511','6','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('512','6','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('513','6','reminder_public','31');
INSERT INTO `glpi_profilerights` VALUES ('514','6','rssfeed_public','31');
INSERT INTO `glpi_profilerights` VALUES ('515','6','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('516','6','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('517','6','ticket','168967');
INSERT INTO `glpi_profilerights` VALUES ('521','6','followup','13319');
INSERT INTO `glpi_profilerights` VALUES ('522','6','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('736','1','project','0');
INSERT INTO `glpi_profilerights` VALUES ('737','2','project','1025');
INSERT INTO `glpi_profilerights` VALUES ('738','3','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('534','6','planning','1');
INSERT INTO `glpi_profilerights` VALUES ('711','4','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('704','4','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('537','6','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('538','6','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('540','6','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('541','6','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('542','6','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('543','6','budget','96');
INSERT INTO `glpi_profilerights` VALUES ('545','6','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('546','6','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('718','4','state','31');
INSERT INTO `glpi_profilerights` VALUES ('719','5','state','0');
INSERT INTO `glpi_profilerights` VALUES ('549','6','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('550','6','slm','1');
INSERT INTO `glpi_profilerights` VALUES ('551','6','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('555','6','problem','1121');
INSERT INTO `glpi_profilerights` VALUES ('699','6','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('693','7','itilcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('686','7','location','31');
INSERT INTO `glpi_profilerights` VALUES ('559','6','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('560','6','ticketrecurrent','1');
INSERT INTO `glpi_profilerights` VALUES ('561','6','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('661','3','change','0');
INSERT INTO `glpi_profilerights` VALUES ('662','4','change','0');
INSERT INTO `glpi_profilerights` VALUES ('564','6','ticketvalidation','3088');
INSERT INTO `glpi_profilerights` VALUES ('565','7','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('566','7','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('567','7','software','127');
INSERT INTO `glpi_profilerights` VALUES ('568','7','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('569','7','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('570','7','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('571','7','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('572','7','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('573','7','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('574','7','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('729','1','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('576','7','contact_enterprise','96');
INSERT INTO `glpi_profilerights` VALUES ('577','7','document','127');
INSERT INTO `glpi_profilerights` VALUES ('578','7','contract','96');
INSERT INTO `glpi_profilerights` VALUES ('579','7','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('580','7','knowbase','14367');
INSERT INTO `glpi_profilerights` VALUES ('584','7','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('585','7','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('586','7','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('588','7','device','0');
INSERT INTO `glpi_profilerights` VALUES ('589','7','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('590','7','link','0');
INSERT INTO `glpi_profilerights` VALUES ('591','7','config','0');
INSERT INTO `glpi_profilerights` VALUES ('593','7','rule_ticket','1055');
INSERT INTO `glpi_profilerights` VALUES ('594','7','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('595','7','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('596','7','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('597','7','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('673','1','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('600','7','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('601','7','user','1055');
INSERT INTO `glpi_profilerights` VALUES ('603','7','group','1');
INSERT INTO `glpi_profilerights` VALUES ('604','7','entity','97');
INSERT INTO `glpi_profilerights` VALUES ('605','7','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('606','7','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('607','7','reminder_public','31');
INSERT INTO `glpi_profilerights` VALUES ('608','7','rssfeed_public','31');
INSERT INTO `glpi_profilerights` VALUES ('609','7','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('610','7','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('611','7','ticket','259103');
INSERT INTO `glpi_profilerights` VALUES ('615','7','followup','13335');
INSERT INTO `glpi_profilerights` VALUES ('616','7','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('735','7','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('628','7','planning','2049');
INSERT INTO `glpi_profilerights` VALUES ('710','3','taskcategory','31');
INSERT INTO `glpi_profilerights` VALUES ('703','3','netpoint','31');
INSERT INTO `glpi_profilerights` VALUES ('631','7','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('632','7','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('634','7','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('635','7','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('636','7','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('637','7','budget','96');
INSERT INTO `glpi_profilerights` VALUES ('639','7','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('640','7','rule_mailcollector','31');
INSERT INTO `glpi_profilerights` VALUES ('672','7','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('717','3','state','31');
INSERT INTO `glpi_profilerights` VALUES ('643','7','calendar','31');
INSERT INTO `glpi_profilerights` VALUES ('644','7','slm','31');
INSERT INTO `glpi_profilerights` VALUES ('645','7','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('649','7','problem','1151');
INSERT INTO `glpi_profilerights` VALUES ('698','5','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('692','6','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('685','6','location','0');
INSERT INTO `glpi_profilerights` VALUES ('653','7','tickettemplate','31');
INSERT INTO `glpi_profilerights` VALUES ('654','7','ticketrecurrent','31');
INSERT INTO `glpi_profilerights` VALUES ('655','7','ticketcost','31');
INSERT INTO `glpi_profilerights` VALUES ('659','1','change','0');
INSERT INTO `glpi_profilerights` VALUES ('660','2','change','1057');
INSERT INTO `glpi_profilerights` VALUES ('658','7','ticketvalidation','15384');
INSERT INTO `glpi_profilerights` VALUES ('750','8','backup','1');
INSERT INTO `glpi_profilerights` VALUES ('751','8','bookmark_public','1');
INSERT INTO `glpi_profilerights` VALUES ('752','8','budget','161');
INSERT INTO `glpi_profilerights` VALUES ('753','8','calendar','1');
INSERT INTO `glpi_profilerights` VALUES ('754','8','cartridge','161');
INSERT INTO `glpi_profilerights` VALUES ('755','8','change','1185');
INSERT INTO `glpi_profilerights` VALUES ('756','8','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('757','8','computer','161');
INSERT INTO `glpi_profilerights` VALUES ('758','8','config','1');
INSERT INTO `glpi_profilerights` VALUES ('759','8','consumable','161');
INSERT INTO `glpi_profilerights` VALUES ('760','8','contact_enterprise','161');
INSERT INTO `glpi_profilerights` VALUES ('761','8','contract','161');
INSERT INTO `glpi_profilerights` VALUES ('762','8','device','0');
INSERT INTO `glpi_profilerights` VALUES ('763','8','document','161');
INSERT INTO `glpi_profilerights` VALUES ('764','8','domain','1');
INSERT INTO `glpi_profilerights` VALUES ('765','8','dropdown','1');
INSERT INTO `glpi_profilerights` VALUES ('766','8','entity','1185');
INSERT INTO `glpi_profilerights` VALUES ('767','8','followup','8193');
INSERT INTO `glpi_profilerights` VALUES ('768','8','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('769','8','group','129');
INSERT INTO `glpi_profilerights` VALUES ('770','8','infocom','1');
INSERT INTO `glpi_profilerights` VALUES ('771','8','internet','129');
INSERT INTO `glpi_profilerights` VALUES ('772','8','itilcategory','1');
INSERT INTO `glpi_profilerights` VALUES ('773','8','knowbase','10369');
INSERT INTO `glpi_profilerights` VALUES ('774','8','knowbasecategory','1');
INSERT INTO `glpi_profilerights` VALUES ('775','8','link','129');
INSERT INTO `glpi_profilerights` VALUES ('776','8','location','1');
INSERT INTO `glpi_profilerights` VALUES ('777','8','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('778','8','monitor','161');
INSERT INTO `glpi_profilerights` VALUES ('779','8','netpoint','1');
INSERT INTO `glpi_profilerights` VALUES ('780','8','networking','161');
INSERT INTO `glpi_profilerights` VALUES ('781','8','notification','1');
INSERT INTO `glpi_profilerights` VALUES ('782','8','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('783','8','peripheral','161');
INSERT INTO `glpi_profilerights` VALUES ('784','8','phone','161');
INSERT INTO `glpi_profilerights` VALUES ('785','8','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('786','8','printer','161');
INSERT INTO `glpi_profilerights` VALUES ('787','8','problem','1185');
INSERT INTO `glpi_profilerights` VALUES ('788','8','profile','129');
INSERT INTO `glpi_profilerights` VALUES ('789','8','project','1185');
INSERT INTO `glpi_profilerights` VALUES ('790','8','projecttask','1');
INSERT INTO `glpi_profilerights` VALUES ('791','8','queuednotification','1');
INSERT INTO `glpi_profilerights` VALUES ('792','8','reminder_public','129');
INSERT INTO `glpi_profilerights` VALUES ('793','8','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('794','8','reservation','1');
INSERT INTO `glpi_profilerights` VALUES ('795','8','rssfeed_public','129');
INSERT INTO `glpi_profilerights` VALUES ('796','8','rule_dictionnary_dropdown','1');
INSERT INTO `glpi_profilerights` VALUES ('797','8','rule_dictionnary_printer','1');
INSERT INTO `glpi_profilerights` VALUES ('798','8','rule_dictionnary_software','1');
INSERT INTO `glpi_profilerights` VALUES ('799','8','rule_import','1');
INSERT INTO `glpi_profilerights` VALUES ('800','8','rule_ldap','1');
INSERT INTO `glpi_profilerights` VALUES ('801','8','rule_mailcollector','1');
INSERT INTO `glpi_profilerights` VALUES ('802','8','rule_softwarecategories','1');
INSERT INTO `glpi_profilerights` VALUES ('803','8','rule_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('804','8','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('805','8','show_group_hardware','1');
INSERT INTO `glpi_profilerights` VALUES ('806','8','slm','1');
INSERT INTO `glpi_profilerights` VALUES ('807','8','software','161');
INSERT INTO `glpi_profilerights` VALUES ('808','8','solutiontemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('809','8','state','1');
INSERT INTO `glpi_profilerights` VALUES ('810','8','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('811','8','task','8193');
INSERT INTO `glpi_profilerights` VALUES ('812','8','taskcategory','1');
INSERT INTO `glpi_profilerights` VALUES ('813','8','ticket','138369');
INSERT INTO `glpi_profilerights` VALUES ('814','8','ticketcost','1');
INSERT INTO `glpi_profilerights` VALUES ('815','8','ticketrecurrent','1');
INSERT INTO `glpi_profilerights` VALUES ('816','8','tickettemplate','1');
INSERT INTO `glpi_profilerights` VALUES ('817','8','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('818','8','transfer','1');
INSERT INTO `glpi_profilerights` VALUES ('819','8','typedoc','1');
INSERT INTO `glpi_profilerights` VALUES ('820','8','user','2177');
INSERT INTO `glpi_profilerights` VALUES ('821','1','license','0');
INSERT INTO `glpi_profilerights` VALUES ('822','2','license','33');
INSERT INTO `glpi_profilerights` VALUES ('823','3','license','127');
INSERT INTO `glpi_profilerights` VALUES ('824','4','license','0');
INSERT INTO `glpi_profilerights` VALUES ('825','5','license','0');
INSERT INTO `glpi_profilerights` VALUES ('826','6','license','127');
INSERT INTO `glpi_profilerights` VALUES ('827','7','license','127');
INSERT INTO `glpi_profilerights` VALUES ('828','8','license','161');
INSERT INTO `glpi_profilerights` VALUES ('829','1','line','0');
INSERT INTO `glpi_profilerights` VALUES ('830','2','line','33');
INSERT INTO `glpi_profilerights` VALUES ('831','3','line','127');
INSERT INTO `glpi_profilerights` VALUES ('832','4','line','0');
INSERT INTO `glpi_profilerights` VALUES ('833','5','line','0');
INSERT INTO `glpi_profilerights` VALUES ('834','6','line','127');
INSERT INTO `glpi_profilerights` VALUES ('835','7','line','127');
INSERT INTO `glpi_profilerights` VALUES ('836','8','line','161');
INSERT INTO `glpi_profilerights` VALUES ('837','1','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('838','2','lineoperator','33');
INSERT INTO `glpi_profilerights` VALUES ('839','3','lineoperator','31');
INSERT INTO `glpi_profilerights` VALUES ('840','4','lineoperator','31');
INSERT INTO `glpi_profilerights` VALUES ('841','5','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('842','6','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('843','7','lineoperator','31');
INSERT INTO `glpi_profilerights` VALUES ('844','8','lineoperator','1');
INSERT INTO `glpi_profilerights` VALUES ('845','1','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('846','2','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('847','3','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('848','4','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('849','5','devicesimcard_pinpuk','1');
INSERT INTO `glpi_profilerights` VALUES ('850','6','devicesimcard_pinpuk','3');
INSERT INTO `glpi_profilerights` VALUES ('851','7','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('852','8','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('853','1','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('854','2','certificate','33');
INSERT INTO `glpi_profilerights` VALUES ('855','3','certificate','127');
INSERT INTO `glpi_profilerights` VALUES ('856','4','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('857','5','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('858','6','certificate','127');
INSERT INTO `glpi_profilerights` VALUES ('859','7','certificate','127');
INSERT INTO `glpi_profilerights` VALUES ('860','8','certificate','161');
INSERT INTO `glpi_profilerights` VALUES ('861','3','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('862','4','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('863','9','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('864','9','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('865','9','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('866','9','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('867','9','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('868','9','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('869','9','change','0');
INSERT INTO `glpi_profilerights` VALUES ('870','9','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('871','9','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('872','9','config','0');
INSERT INTO `glpi_profilerights` VALUES ('873','9','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('874','9','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('875','9','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('876','9','device','0');
INSERT INTO `glpi_profilerights` VALUES ('877','9','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('878','9','document','0');
INSERT INTO `glpi_profilerights` VALUES ('879','9','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('880','9','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('881','9','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('882','9','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('883','9','group','0');
INSERT INTO `glpi_profilerights` VALUES ('884','9','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('885','9','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('886','9','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('887','9','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('888','9','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('889','9','license','0');
INSERT INTO `glpi_profilerights` VALUES ('890','9','line','0');
INSERT INTO `glpi_profilerights` VALUES ('891','9','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('892','9','link','0');
INSERT INTO `glpi_profilerights` VALUES ('893','9','location','0');
INSERT INTO `glpi_profilerights` VALUES ('894','9','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('895','9','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('896','9','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('897','9','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('898','9','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('899','9','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('900','9','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('901','9','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('902','9','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('903','9','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('904','9','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('905','9','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('906','9','project','0');
INSERT INTO `glpi_profilerights` VALUES ('907','9','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('908','9','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('909','9','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('910','9','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('911','9','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('912','9','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('913','9','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('914','9','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('915','9','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('916','9','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('917','9','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('918','9','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('919','9','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('920','9','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('921','9','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('922','9','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('923','9','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('924','9','software','0');
INSERT INTO `glpi_profilerights` VALUES ('925','9','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('926','9','state','0');
INSERT INTO `glpi_profilerights` VALUES ('927','9','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('928','9','task','0');
INSERT INTO `glpi_profilerights` VALUES ('929','9','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('930','9','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('931','9','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('932','9','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('933','9','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('934','9','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('935','9','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('936','9','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('937','9','user','0');
INSERT INTO `glpi_profilerights` VALUES ('938','9','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('939','1','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('940','2','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('941','3','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('957','4','plugin_appliances','127');
INSERT INTO `glpi_profilerights` VALUES ('943','5','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('944','6','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('945','7','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('946','8','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('947','9','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('948','1','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('949','2','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('950','3','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('958','4','plugin_appliances_open_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('952','5','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('953','6','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('954','7','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('955','8','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('956','9','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('959','1','plugin_comproveedores','0');
INSERT INTO `glpi_profilerights` VALUES ('960','2','plugin_comproveedores','0');
INSERT INTO `glpi_profilerights` VALUES ('961','3','plugin_comproveedores','0');
INSERT INTO `glpi_profilerights` VALUES ('963','5','plugin_comproveedores','127');
INSERT INTO `glpi_profilerights` VALUES ('964','6','plugin_comproveedores','127');
INSERT INTO `glpi_profilerights` VALUES ('965','7','plugin_comproveedores','127');
INSERT INTO `glpi_profilerights` VALUES ('966','8','plugin_comproveedores','127');
INSERT INTO `glpi_profilerights` VALUES ('967','9','plugin_comproveedores','31');
INSERT INTO `glpi_profilerights` VALUES ('968','1','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('969','2','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('970','3','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('972','5','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('973','6','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('974','7','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('975','8','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('976','9','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1348','4','plugin_comproveedores','127');
INSERT INTO `glpi_profilerights` VALUES ('1349','4','plugin_comproveedores_open_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('1012','10','backup','1045');
INSERT INTO `glpi_profilerights` VALUES ('1013','10','bookmark_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1014','10','budget','127');
INSERT INTO `glpi_profilerights` VALUES ('1015','10','calendar','23');
INSERT INTO `glpi_profilerights` VALUES ('1016','10','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1017','10','certificate','127');
INSERT INTO `glpi_profilerights` VALUES ('1018','10','change','0');
INSERT INTO `glpi_profilerights` VALUES ('1019','10','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1020','10','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('1021','10','config','3');
INSERT INTO `glpi_profilerights` VALUES ('1022','10','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('1023','10','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('1024','10','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('1025','10','device','23');
INSERT INTO `glpi_profilerights` VALUES ('1026','10','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('1027','10','document','127');
INSERT INTO `glpi_profilerights` VALUES ('1028','10','domain','23');
INSERT INTO `glpi_profilerights` VALUES ('1029','10','dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1030','10','entity','3191');
INSERT INTO `glpi_profilerights` VALUES ('1031','10','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('1032','10','group','119');
INSERT INTO `glpi_profilerights` VALUES ('1033','10','infocom','23');
INSERT INTO `glpi_profilerights` VALUES ('1034','10','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('1035','10','itilcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1036','10','knowbase','15383');
INSERT INTO `glpi_profilerights` VALUES ('1037','10','knowbasecategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1038','10','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1039','10','line','127');
INSERT INTO `glpi_profilerights` VALUES ('1040','10','lineoperator','23');
INSERT INTO `glpi_profilerights` VALUES ('1041','10','link','23');
INSERT INTO `glpi_profilerights` VALUES ('1042','10','location','23');
INSERT INTO `glpi_profilerights` VALUES ('1043','10','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('1044','10','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('1045','10','netpoint','23');
INSERT INTO `glpi_profilerights` VALUES ('1046','10','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('1047','10','notification','23');
INSERT INTO `glpi_profilerights` VALUES ('1048','10','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('1049','10','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('1050','10','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('1051','10','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('1052','10','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('1053','10','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1054','10','plugin_comproveedores','31');
INSERT INTO `glpi_profilerights` VALUES ('1055','10','plugin_comproveedores_open_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('1056','10','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1057','10','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('1058','10','profile','23');
INSERT INTO `glpi_profilerights` VALUES ('1059','10','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('1060','10','projecttask','1121');
INSERT INTO `glpi_profilerights` VALUES ('1061','10','queuednotification','31');
INSERT INTO `glpi_profilerights` VALUES ('1062','10','reminder_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1063','10','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('1064','10','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('1065','10','rssfeed_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1066','10','rule_dictionnary_dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1067','10','rule_dictionnary_printer','23');
INSERT INTO `glpi_profilerights` VALUES ('1068','10','rule_dictionnary_software','23');
INSERT INTO `glpi_profilerights` VALUES ('1069','10','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('1070','10','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('1071','10','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('1072','10','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('1073','10','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1074','10','search_config','3072');
INSERT INTO `glpi_profilerights` VALUES ('1075','10','show_group_hardware','1');
INSERT INTO `glpi_profilerights` VALUES ('1076','10','slm','23');
INSERT INTO `glpi_profilerights` VALUES ('1077','10','software','0');
INSERT INTO `glpi_profilerights` VALUES ('1078','10','solutiontemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1079','10','state','23');
INSERT INTO `glpi_profilerights` VALUES ('1080','10','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('1081','10','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('1082','10','taskcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1083','10','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1084','10','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('1085','10','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('1086','10','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1087','10','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1088','10','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('1089','10','typedoc','23');
INSERT INTO `glpi_profilerights` VALUES ('1090','10','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('1091','10','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('1100','11','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('1101','11','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1102','11','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('1103','11','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('1104','11','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1105','11','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('1106','11','change','0');
INSERT INTO `glpi_profilerights` VALUES ('1107','11','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1108','11','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('1109','11','config','0');
INSERT INTO `glpi_profilerights` VALUES ('1110','11','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('1111','11','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('1112','11','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('1113','11','device','0');
INSERT INTO `glpi_profilerights` VALUES ('1114','11','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('1115','11','document','0');
INSERT INTO `glpi_profilerights` VALUES ('1116','11','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('1117','11','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1118','11','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('1119','11','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('1120','11','group','0');
INSERT INTO `glpi_profilerights` VALUES ('1121','11','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('1122','11','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('1123','11','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1124','11','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('1125','11','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1126','11','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1127','11','line','0');
INSERT INTO `glpi_profilerights` VALUES ('1128','11','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('1129','11','link','0');
INSERT INTO `glpi_profilerights` VALUES ('1130','11','location','0');
INSERT INTO `glpi_profilerights` VALUES ('1131','11','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('1132','11','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('1133','11','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('1134','11','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('1135','11','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('1136','11','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('1137','11','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('1138','11','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('1139','11','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('1140','11','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('1141','11','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1142','11','plugin_comproveedores','0');
INSERT INTO `glpi_profilerights` VALUES ('1143','11','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1144','11','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1145','11','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('1146','11','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('1147','11','project','0');
INSERT INTO `glpi_profilerights` VALUES ('1148','11','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('1149','11','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('1150','11','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1151','11','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('1152','11','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('1153','11','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1154','11','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1155','11','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1156','11','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('1157','11','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('1158','11','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('1159','11','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('1160','11','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('1161','11','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1162','11','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('1163','11','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('1164','11','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('1165','11','software','0');
INSERT INTO `glpi_profilerights` VALUES ('1166','11','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1167','11','state','0');
INSERT INTO `glpi_profilerights` VALUES ('1168','11','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('1169','11','task','0');
INSERT INTO `glpi_profilerights` VALUES ('1170','11','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1171','11','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1172','11','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('1173','11','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('1174','11','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1175','11','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1176','11','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('1177','11','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('1178','11','user','0');
INSERT INTO `glpi_profilerights` VALUES ('1179','11','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('1188','12','backup','1045');
INSERT INTO `glpi_profilerights` VALUES ('1189','12','bookmark_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1190','12','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('1191','12','calendar','23');
INSERT INTO `glpi_profilerights` VALUES ('1192','12','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1193','12','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('1194','12','change','0');
INSERT INTO `glpi_profilerights` VALUES ('1195','12','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1196','12','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('1197','12','config','3');
INSERT INTO `glpi_profilerights` VALUES ('1198','12','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('1199','12','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('1200','12','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('1201','12','device','23');
INSERT INTO `glpi_profilerights` VALUES ('1202','12','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('1203','12','document','127');
INSERT INTO `glpi_profilerights` VALUES ('1204','12','domain','23');
INSERT INTO `glpi_profilerights` VALUES ('1205','12','dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1206','12','entity','3191');
INSERT INTO `glpi_profilerights` VALUES ('1207','12','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('1208','12','group','119');
INSERT INTO `glpi_profilerights` VALUES ('1209','12','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('1210','12','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('1211','12','itilcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1212','12','knowbase','15383');
INSERT INTO `glpi_profilerights` VALUES ('1213','12','knowbasecategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1214','12','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1215','12','line','0');
INSERT INTO `glpi_profilerights` VALUES ('1216','12','lineoperator','23');
INSERT INTO `glpi_profilerights` VALUES ('1217','12','link','23');
INSERT INTO `glpi_profilerights` VALUES ('1218','12','location','23');
INSERT INTO `glpi_profilerights` VALUES ('1219','12','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('1220','12','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('1221','12','netpoint','23');
INSERT INTO `glpi_profilerights` VALUES ('1222','12','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('1223','12','notification','23');
INSERT INTO `glpi_profilerights` VALUES ('1224','12','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('1225','12','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('1226','12','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('1227','12','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('1228','12','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('1229','12','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1230','12','plugin_comproveedores','31');
INSERT INTO `glpi_profilerights` VALUES ('1231','12','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1232','12','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1233','12','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('1234','12','profile','23');
INSERT INTO `glpi_profilerights` VALUES ('1235','12','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('1236','12','projecttask','1121');
INSERT INTO `glpi_profilerights` VALUES ('1237','12','queuednotification','31');
INSERT INTO `glpi_profilerights` VALUES ('1238','12','reminder_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1239','12','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('1240','12','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('1241','12','rssfeed_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1242','12','rule_dictionnary_dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1243','12','rule_dictionnary_printer','23');
INSERT INTO `glpi_profilerights` VALUES ('1244','12','rule_dictionnary_software','23');
INSERT INTO `glpi_profilerights` VALUES ('1245','12','rule_import','23');
INSERT INTO `glpi_profilerights` VALUES ('1246','12','rule_ldap','23');
INSERT INTO `glpi_profilerights` VALUES ('1247','12','rule_mailcollector','23');
INSERT INTO `glpi_profilerights` VALUES ('1248','12','rule_softwarecategories','23');
INSERT INTO `glpi_profilerights` VALUES ('1249','12','rule_ticket','1047');
INSERT INTO `glpi_profilerights` VALUES ('1250','12','search_config','3072');
INSERT INTO `glpi_profilerights` VALUES ('1251','12','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('1252','12','slm','23');
INSERT INTO `glpi_profilerights` VALUES ('1253','12','software','0');
INSERT INTO `glpi_profilerights` VALUES ('1254','12','solutiontemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1255','12','state','23');
INSERT INTO `glpi_profilerights` VALUES ('1256','12','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('1257','12','task','0');
INSERT INTO `glpi_profilerights` VALUES ('1258','12','taskcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1259','12','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1260','12','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('1261','12','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('1262','12','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1263','12','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1264','12','transfer','23');
INSERT INTO `glpi_profilerights` VALUES ('1265','12','typedoc','23');
INSERT INTO `glpi_profilerights` VALUES ('1266','12','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('1267','12','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('1268','13','backup','1045');
INSERT INTO `glpi_profilerights` VALUES ('1269','13','bookmark_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1270','13','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('1271','13','calendar','23');
INSERT INTO `glpi_profilerights` VALUES ('1272','13','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1273','13','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('1274','13','change','0');
INSERT INTO `glpi_profilerights` VALUES ('1275','13','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1276','13','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('1277','13','config','3');
INSERT INTO `glpi_profilerights` VALUES ('1278','13','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('1279','13','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('1280','13','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('1281','13','device','23');
INSERT INTO `glpi_profilerights` VALUES ('1282','13','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('1283','13','document','127');
INSERT INTO `glpi_profilerights` VALUES ('1284','13','domain','23');
INSERT INTO `glpi_profilerights` VALUES ('1285','13','dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1286','13','entity','3191');
INSERT INTO `glpi_profilerights` VALUES ('1287','13','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('1288','13','group','23');
INSERT INTO `glpi_profilerights` VALUES ('1289','13','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('1290','13','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('1291','13','itilcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1292','13','knowbase','15383');
INSERT INTO `glpi_profilerights` VALUES ('1293','13','knowbasecategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1294','13','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1295','13','line','0');
INSERT INTO `glpi_profilerights` VALUES ('1296','13','lineoperator','23');
INSERT INTO `glpi_profilerights` VALUES ('1297','13','link','23');
INSERT INTO `glpi_profilerights` VALUES ('1298','13','location','23');
INSERT INTO `glpi_profilerights` VALUES ('1299','13','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('1300','13','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('1301','13','netpoint','23');
INSERT INTO `glpi_profilerights` VALUES ('1302','13','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('1303','13','notification','23');
INSERT INTO `glpi_profilerights` VALUES ('1304','13','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('1305','13','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('1306','13','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('1307','13','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('1308','13','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('1309','13','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1310','13','plugin_comproveedores','31');
INSERT INTO `glpi_profilerights` VALUES ('1311','13','plugin_comproveedores_open_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('1312','13','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1313','13','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('1314','13','profile','23');
INSERT INTO `glpi_profilerights` VALUES ('1315','13','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('1316','13','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('1317','13','queuednotification','31');
INSERT INTO `glpi_profilerights` VALUES ('1318','13','reminder_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1319','13','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('1320','13','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('1321','13','rssfeed_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1322','13','rule_dictionnary_dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1323','13','rule_dictionnary_printer','23');
INSERT INTO `glpi_profilerights` VALUES ('1324','13','rule_dictionnary_software','23');
INSERT INTO `glpi_profilerights` VALUES ('1325','13','rule_import','23');
INSERT INTO `glpi_profilerights` VALUES ('1326','13','rule_ldap','23');
INSERT INTO `glpi_profilerights` VALUES ('1327','13','rule_mailcollector','23');
INSERT INTO `glpi_profilerights` VALUES ('1328','13','rule_softwarecategories','23');
INSERT INTO `glpi_profilerights` VALUES ('1329','13','rule_ticket','1047');
INSERT INTO `glpi_profilerights` VALUES ('1330','13','search_config','3072');
INSERT INTO `glpi_profilerights` VALUES ('1331','13','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('1332','13','slm','23');
INSERT INTO `glpi_profilerights` VALUES ('1333','13','software','0');
INSERT INTO `glpi_profilerights` VALUES ('1334','13','solutiontemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1335','13','state','23');
INSERT INTO `glpi_profilerights` VALUES ('1336','13','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('1337','13','task','0');
INSERT INTO `glpi_profilerights` VALUES ('1338','13','taskcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1339','13','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1340','13','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('1341','13','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('1342','13','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1343','13','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1344','13','transfer','23');
INSERT INTO `glpi_profilerights` VALUES ('1345','13','typedoc','23');
INSERT INTO `glpi_profilerights` VALUES ('1346','13','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('1347','13','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('1350','14','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('1351','14','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1352','14','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('1353','14','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('1354','14','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1355','14','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('1356','14','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('1357','14','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('1358','14','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('1359','14','config','0');
INSERT INTO `glpi_profilerights` VALUES ('1360','14','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('1361','14','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('1362','14','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('1363','14','device','0');
INSERT INTO `glpi_profilerights` VALUES ('1364','14','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('1365','14','document','0');
INSERT INTO `glpi_profilerights` VALUES ('1366','14','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('1367','14','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1368','14','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('1369','14','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('1370','14','group','0');
INSERT INTO `glpi_profilerights` VALUES ('1371','14','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('1372','14','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('1373','14','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1374','14','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('1375','14','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1376','14','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1377','14','line','0');
INSERT INTO `glpi_profilerights` VALUES ('1378','14','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('1379','14','link','0');
INSERT INTO `glpi_profilerights` VALUES ('1380','14','location','0');
INSERT INTO `glpi_profilerights` VALUES ('1381','14','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('1382','14','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('1383','14','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('1384','14','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('1385','14','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('1386','14','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('1387','14','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('1388','14','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('1389','14','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('1390','14','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('1391','14','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1392','14','plugin_comproveedores','0');
INSERT INTO `glpi_profilerights` VALUES ('1393','14','plugin_comproveedores_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1394','14','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1395','14','problem','1151');
INSERT INTO `glpi_profilerights` VALUES ('1396','14','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('1397','14','project','0');
INSERT INTO `glpi_profilerights` VALUES ('1398','14','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('1399','14','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('1400','14','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1401','14','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('1402','14','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('1403','14','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1404','14','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1405','14','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1406','14','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('1407','14','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('1408','14','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('1409','14','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('1410','14','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('1411','14','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1412','14','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('1413','14','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('1414','14','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('1415','14','software','0');
INSERT INTO `glpi_profilerights` VALUES ('1416','14','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1417','14','state','0');
INSERT INTO `glpi_profilerights` VALUES ('1418','14','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('1419','14','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('1420','14','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1421','14','ticket','261151');
INSERT INTO `glpi_profilerights` VALUES ('1422','14','ticketcost','23');
INSERT INTO `glpi_profilerights` VALUES ('1423','14','ticketrecurrent','23');
INSERT INTO `glpi_profilerights` VALUES ('1424','14','tickettemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1425','14','ticketvalidation','15376');
INSERT INTO `glpi_profilerights` VALUES ('1426','14','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('1427','14','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('1428','14','user','0');
INSERT INTO `glpi_profilerights` VALUES ('1429','14','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('1430','15','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('1431','15','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1432','15','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('1433','15','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('1434','15','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1435','15','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('1436','15','change','0');
INSERT INTO `glpi_profilerights` VALUES ('1437','15','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1438','15','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('1439','15','config','0');
INSERT INTO `glpi_profilerights` VALUES ('1440','15','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('1441','15','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('1442','15','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('1443','15','device','0');
INSERT INTO `glpi_profilerights` VALUES ('1444','15','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('1445','15','document','0');
INSERT INTO `glpi_profilerights` VALUES ('1446','15','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('1447','15','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1448','15','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('1449','15','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('1450','15','group','0');
INSERT INTO `glpi_profilerights` VALUES ('1451','15','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('1452','15','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('1453','15','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1454','15','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('1455','15','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1456','15','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1457','15','line','0');
INSERT INTO `glpi_profilerights` VALUES ('1458','15','lineoperator','0');
INSERT INTO `glpi_profilerights` VALUES ('1459','15','link','0');
INSERT INTO `glpi_profilerights` VALUES ('1460','15','location','0');
INSERT INTO `glpi_profilerights` VALUES ('1461','15','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('1462','15','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('1463','15','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('1464','15','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('1465','15','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('1466','15','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('1467','15','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('1468','15','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('1469','15','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('1470','15','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('1471','15','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1472','15','plugin_comproveedores','31');
INSERT INTO `glpi_profilerights` VALUES ('1473','15','plugin_comproveedores_open_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('1474','15','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1475','15','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('1476','15','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('1477','15','project','0');
INSERT INTO `glpi_profilerights` VALUES ('1478','15','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('1479','15','queuednotification','0');
INSERT INTO `glpi_profilerights` VALUES ('1480','15','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1481','15','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('1482','15','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('1483','15','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1484','15','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1485','15','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1486','15','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('1487','15','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('1488','15','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('1489','15','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('1490','15','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('1491','15','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1492','15','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('1493','15','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('1494','15','slm','0');
INSERT INTO `glpi_profilerights` VALUES ('1495','15','software','0');
INSERT INTO `glpi_profilerights` VALUES ('1496','15','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1497','15','state','0');
INSERT INTO `glpi_profilerights` VALUES ('1498','15','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('1499','15','task','0');
INSERT INTO `glpi_profilerights` VALUES ('1500','15','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1501','15','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1502','15','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('1503','15','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('1504','15','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1505','15','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1506','15','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('1507','15','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('1508','15','user','0');
INSERT INTO `glpi_profilerights` VALUES ('1509','15','global_validation','0');
INSERT INTO `glpi_profilerights` VALUES ('1510','16','backup','1045');
INSERT INTO `glpi_profilerights` VALUES ('1511','16','bookmark_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1512','16','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('1513','16','calendar','23');
INSERT INTO `glpi_profilerights` VALUES ('1514','16','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1515','16','certificate','0');
INSERT INTO `glpi_profilerights` VALUES ('1516','16','change','0');
INSERT INTO `glpi_profilerights` VALUES ('1517','16','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1518','16','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('1519','16','config','3');
INSERT INTO `glpi_profilerights` VALUES ('1520','16','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('1521','16','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('1522','16','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('1523','16','device','23');
INSERT INTO `glpi_profilerights` VALUES ('1524','16','devicesimcard_pinpuk','0');
INSERT INTO `glpi_profilerights` VALUES ('1525','16','document','127');
INSERT INTO `glpi_profilerights` VALUES ('1526','16','domain','23');
INSERT INTO `glpi_profilerights` VALUES ('1527','16','dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1528','16','entity','3191');
INSERT INTO `glpi_profilerights` VALUES ('1529','16','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('1530','16','group','119');
INSERT INTO `glpi_profilerights` VALUES ('1531','16','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('1532','16','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('1533','16','itilcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1534','16','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('1535','16','knowbasecategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1536','16','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1537','16','line','0');
INSERT INTO `glpi_profilerights` VALUES ('1538','16','lineoperator','23');
INSERT INTO `glpi_profilerights` VALUES ('1539','16','link','23');
INSERT INTO `glpi_profilerights` VALUES ('1540','16','location','23');
INSERT INTO `glpi_profilerights` VALUES ('1541','16','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('1542','16','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('1543','16','netpoint','23');
INSERT INTO `glpi_profilerights` VALUES ('1544','16','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('1545','16','notification','23');
INSERT INTO `glpi_profilerights` VALUES ('1546','16','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('1547','16','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('1548','16','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('1549','16','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('1550','16','plugin_appliances','0');
INSERT INTO `glpi_profilerights` VALUES ('1551','16','plugin_appliances_open_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1552','16','plugin_comproveedores','31');
INSERT INTO `glpi_profilerights` VALUES ('1553','16','plugin_comproveedores_open_ticket','1');
INSERT INTO `glpi_profilerights` VALUES ('1554','16','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1555','16','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('1556','16','profile','23');
INSERT INTO `glpi_profilerights` VALUES ('1557','16','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('1558','16','projecttask','1121');
INSERT INTO `glpi_profilerights` VALUES ('1559','16','queuednotification','31');
INSERT INTO `glpi_profilerights` VALUES ('1560','16','reminder_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1561','16','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('1562','16','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('1563','16','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1564','16','rule_dictionnary_dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1565','16','rule_dictionnary_printer','23');
INSERT INTO `glpi_profilerights` VALUES ('1566','16','rule_dictionnary_software','23');
INSERT INTO `glpi_profilerights` VALUES ('1567','16','rule_import','23');
INSERT INTO `glpi_profilerights` VALUES ('1568','16','rule_ldap','23');
INSERT INTO `glpi_profilerights` VALUES ('1569','16','rule_mailcollector','23');
INSERT INTO `glpi_profilerights` VALUES ('1570','16','rule_softwarecategories','23');
INSERT INTO `glpi_profilerights` VALUES ('1571','16','rule_ticket','1047');
INSERT INTO `glpi_profilerights` VALUES ('1572','16','search_config','3072');
INSERT INTO `glpi_profilerights` VALUES ('1573','16','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('1574','16','slm','23');
INSERT INTO `glpi_profilerights` VALUES ('1575','16','software','0');
INSERT INTO `glpi_profilerights` VALUES ('1576','16','solutiontemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1577','16','state','23');
INSERT INTO `glpi_profilerights` VALUES ('1578','16','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('1579','16','task','0');
INSERT INTO `glpi_profilerights` VALUES ('1580','16','taskcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1581','16','ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1582','16','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('1583','16','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('1584','16','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1585','16','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1586','16','transfer','23');
INSERT INTO `glpi_profilerights` VALUES ('1587','16','typedoc','23');
INSERT INTO `glpi_profilerights` VALUES ('1588','16','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('1589','16','global_validation','0');

### Dump table glpi_profiles

DROP TABLE IF EXISTS `glpi_profiles`;
CREATE TABLE `glpi_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'helpdesk',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `helpdesk_hardware` int(11) NOT NULL DEFAULT '0',
  `helpdesk_item_type` text COLLATE utf8_unicode_ci,
  `ticket_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `problem_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `create_ticket_on_login` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `change_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_creation` datetime DEFAULT NULL,
  `create_cv_on_login` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `interface` (`interface`),
  KEY `is_default` (`is_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles` VALUES ('1','Self-Service','helpdesk','1','1','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}',NULL,NULL,'[]','0','0',NULL,NULL,'0');
INSERT INTO `glpi_profiles` VALUES ('2','Observer','central','0','1','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL,'0');
INSERT INTO `glpi_profiles` VALUES ('3','Admin','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]','2018-04-10 08:30:18',NULL,'[]','0','0',NULL,NULL,'0');
INSERT INTO `glpi_profiles` VALUES ('4','Super-Admin','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]','2018-04-10 08:32:07',NULL,'[]','0','0',NULL,NULL,'0');
INSERT INTO `glpi_profiles` VALUES ('5','Hotliner','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','1','0',NULL,NULL,'0');
INSERT INTO `glpi_profiles` VALUES ('6','Technician','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL,'0');
INSERT INTO `glpi_profiles` VALUES ('7','Supervisor','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]',NULL,NULL,'[]','0','0',NULL,NULL,'0');
INSERT INTO `glpi_profiles` VALUES ('8','Read-Only','central','0','0','[]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},
                       \"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},
                       \"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0},
                       \"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}',NULL,'This profile defines read-only access. It is used when objects are locked. It can also be used to give to users rights to unlock objects.','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"4\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"5\":0,\"8\":0,\"6\":0},
                      \"5\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"8\":0,\"6\":0},
                      \"8\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},
                      \"6\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0}}','0','0','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"7\":{\"1\":0,\"9\":0,\"10\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"4\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"11\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"12\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"5\":0,\"8\":0,\"6\":0},
                       \"5\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"8\":0,\"6\":0},
                       \"8\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"6\":0},
                       \"6\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0}}','2016-02-08 16:57:46','0');
INSERT INTO `glpi_profiles` VALUES ('9','BOVIS PROVEEDORES','central','0','0','[]',NULL,'2018-04-27 10:05:08','',NULL,'0','1',NULL,'2018-04-10 11:41:05','0');
INSERT INTO `glpi_profiles` VALUES ('10','BOVIS FINANCIERO','central','0','3','[]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}','2018-05-03 08:31:44','','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0}}','0','0','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"9\":0,\"10\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"11\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"12\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0}}','2018-04-17 08:25:43','0');
INSERT INTO `glpi_profiles` VALUES ('11','perfil prueba 1','central','0','0',NULL,NULL,'2018-04-19 08:23:23','',NULL,'0','0',NULL,'2018-04-19 08:22:55','0');
INSERT INTO `glpi_profiles` VALUES ('12','Tecnico_Bovis','central','0','0',NULL,NULL,'2018-04-20 14:21:14','',NULL,'0','0',NULL,'2018-04-20 14:17:26','0');
INSERT INTO `glpi_profiles` VALUES ('14','BOVIS USUARIOS DE PROYECTO','central','0','0','[]','{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}','2018-05-03 08:37:34','','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0}}','0','0','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"9\":0,\"10\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"11\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"12\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0}}','2018-04-26 13:03:14','0');
INSERT INTO `glpi_profiles` VALUES ('15','BOVIS GENERAL','central','0','0',NULL,'{\"1\":{\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"2\":{\"1\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"3\":{\"1\":0,\"2\":0,\"4\":0,\"5\":0,\"6\":0},\"4\":{\"1\":0,\"2\":0,\"3\":0,\"5\":0,\"6\":0},\"5\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"6\":0},\"6\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0}}','2018-04-27 10:19:49','BOVIS: Perfil para el común de los usuarios','{\"1\":{\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"2\":{\"1\":0,\"7\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"3\":{\"1\":0,\"7\":0,\"2\":0,\"4\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"7\":0,\"2\":0,\"3\":0,\"4\":0,\"5\":0,\"8\":0}}','0','0','{\"1\":{\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"9\":{\"1\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"10\":{\"1\":0,\"9\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"7\":{\"1\":0,\"9\":0,\"10\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"4\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"11\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"12\":0,\"5\":0,\"8\":0,\"6\":0},\"12\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"5\":0,\"8\":0,\"6\":0},\"5\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"8\":0,\"6\":0},\"8\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"6\":0},\"6\":{\"1\":0,\"9\":0,\"10\":0,\"7\":0,\"4\":0,\"11\":0,\"12\":0,\"5\":0,\"8\":0}}','2018-04-27 10:00:02','0');
INSERT INTO `glpi_profiles` VALUES ('16','BOVIS ESTRATÉGICO','central','0','0',NULL,NULL,'2018-05-11 12:14:59','',NULL,'0','0',NULL,'2018-04-27 10:04:11','0');

### Dump table glpi_profiles_reminders

DROP TABLE IF EXISTS `glpi_profiles_reminders`;
CREATE TABLE `glpi_profiles_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_rssfeeds

DROP TABLE IF EXISTS `glpi_profiles_rssfeeds`;
CREATE TABLE `glpi_profiles_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_users

DROP TABLE IF EXISTS `glpi_profiles_users`;
CREATE TABLE `glpi_profiles_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `users_id` (`users_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles_users` VALUES ('2','2','4','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('3','3','1','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('4','4','6','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('5','5','2','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('8','7','9','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('7','6','9','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('9','8','1','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('10','9','9','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('12','9','11','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('13','10','12','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('14','11','9','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('15','12','9','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('16','13','16','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('17','14','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('18','15','15','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('19','16','9','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('20','17','14','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('21','18','9','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('23','20','9','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('24','19','9','0','1','0');

### Dump table glpi_projectcosts

DROP TABLE IF EXISTS `glpi_projectcosts`;
CREATE TABLE `glpi_projectcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `projects_id` (`projects_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projects

DROP TABLE IF EXISTS `glpi_projects`;
CREATE TABLE `glpi_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttypes_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `show_on_global_gantt` tinyint(1) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `projecttemplates_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `code` (`code`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttypes_id` (`projecttypes_id`),
  KEY `priority` (`priority`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `show_on_global_gantt` (`show_on_global_gantt`),
  KEY `date_creation` (`date_creation`),
  KEY `projecttemplates_id` (`projecttemplates_id`),
  KEY `is_template` (`is_template`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_projects` VALUES ('1','PROYECTO001','REF XVX800024','3','0','0','0','2','0','2018-05-15 13:17:58','2018-05-21 07:41:32','0','0','2018-08-01 00:00:00','2019-08-01 00:00:00',NULL,NULL,'0','0','','','0','2018-05-15 13:19:17','0','0',NULL);

### Dump table glpi_projectstates

DROP TABLE IF EXISTS `glpi_projectstates`;
CREATE TABLE `glpi_projectstates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_finished` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_finished` (`is_finished`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_projectstates` VALUES ('1','New',NULL,'#06ff00','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('2','Processing',NULL,'#ffb800','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('3','Closed',NULL,'#ff0000','1',NULL,NULL);

### Dump table glpi_projecttasks

DROP TABLE IF EXISTS `glpi_projecttasks`;
CREATE TABLE `glpi_projecttasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT '0',
  `effective_duration` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttasktypes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `is_milestone` tinyint(1) NOT NULL DEFAULT '0',
  `projecttasktemplates_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projecttasks_id` (`projecttasks_id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttasktypes_id` (`projecttasktypes_id`),
  KEY `projecttasktemplates_id` (`projecttasktemplates_id`),
  KEY `is_template` (`is_template`),
  KEY `is_milestone` (`is_milestone`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_projecttasks` VALUES ('1','SEGURIDAD Y SALUD','','','0','0','1','0','2018-05-15 13:20:15','2018-05-15 13:20:15','2018-08-01 00:00:00','2019-08-01 00:00:00',NULL,NULL,'0','0','0','0','13','0','0','0','0',NULL);
INSERT INTO `glpi_projecttasks` VALUES ('2','CIMENTACIÓN','','','0','0','1','0','2018-05-15 13:21:14','2018-05-15 13:21:14','2018-09-01 00:00:00','2018-10-01 00:00:00',NULL,NULL,'0','0','0','0','13','0','0','0','0',NULL);

### Dump table glpi_projecttasks_tickets

DROP TABLE IF EXISTS `glpi_projecttasks_tickets`;
CREATE TABLE `glpi_projecttasks_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`projecttasks_id`),
  KEY `projects_id` (`projecttasks_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttaskteams

DROP TABLE IF EXISTS `glpi_projecttaskteams`;
CREATE TABLE `glpi_projecttaskteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projecttasks_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_projecttaskteams` VALUES ('1','1','Supplier','3');

### Dump table glpi_projecttasktemplates

DROP TABLE IF EXISTS `glpi_projecttasktemplates`;
CREATE TABLE `glpi_projecttasktemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT '0',
  `effective_duration` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttasktypes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `is_milestone` tinyint(1) NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projecttasks_id` (`projecttasks_id`),
  KEY `date_creation` (`date_creation`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttasktypes_id` (`projecttasktypes_id`),
  KEY `is_milestone` (`is_milestone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasktypes

DROP TABLE IF EXISTS `glpi_projecttasktypes`;
CREATE TABLE `glpi_projecttasktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projectteams

DROP TABLE IF EXISTS `glpi_projectteams`;
CREATE TABLE `glpi_projectteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttypes

DROP TABLE IF EXISTS `glpi_projecttypes`;
CREATE TABLE `glpi_projecttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_queuednotifications

DROP TABLE IF EXISTS `glpi_queuednotifications`;
CREATE TABLE `glpi_queuednotifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `sent_try` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `send_time` datetime DEFAULT NULL,
  `sent_time` datetime DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `sender` text COLLATE utf8_unicode_ci,
  `sendername` text COLLATE utf8_unicode_ci,
  `recipient` text COLLATE utf8_unicode_ci,
  `recipientname` text COLLATE utf8_unicode_ci,
  `replyto` text COLLATE utf8_unicode_ci,
  `replytoname` text COLLATE utf8_unicode_ci,
  `headers` text COLLATE utf8_unicode_ci,
  `body_html` longtext COLLATE utf8_unicode_ci,
  `body_text` longtext COLLATE utf8_unicode_ci,
  `messageid` text COLLATE utf8_unicode_ci,
  `documents` text COLLATE utf8_unicode_ci,
  `mode` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT 'See Notification_NotificationTemplate::MODE_* constants',
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`,`notificationtemplates_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `entities_id` (`entities_id`),
  KEY `sent_try` (`sent_try`),
  KEY `create_time` (`create_time`),
  KEY `send_time` (`send_time`),
  KEY `sent_time` (`sent_time`),
  KEY `mode` (`mode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_registeredids

DROP TABLE IF EXISTS `glpi_registeredids`;
CREATE TABLE `glpi_registeredids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `device_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'USB, PCI ...',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `item` (`items_id`,`itemtype`),
  KEY `device_type` (`device_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reminders

DROP TABLE IF EXISTS `glpi_reminders`;
CREATE TABLE `glpi_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `is_planned` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `begin_view_date` datetime DEFAULT NULL,
  `end_view_date` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `users_id` (`users_id`),
  KEY `is_planned` (`is_planned`),
  KEY `state` (`state`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_reminders` VALUES ('1','2018-04-13 13:26:02','7','Construcción del Hospital','&lt;p&gt;Presentar Oferta de Construccion de Hospital.&lt;/p&gt;',NULL,NULL,'0','2018-04-13 13:26:59','0','2018-04-02 00:00:00','2026-04-15 00:00:00','2018-04-13 13:26:02');
INSERT INTO `glpi_reminders` VALUES ('2','2018-05-04 09:25:45','2','NECESIDAD CERTIFICADOS','&lt;p&gt;Es necesario el envío de los certificados de calidad vigentes en la empresa.&lt;/p&gt;',NULL,NULL,'0','2018-05-04 09:25:45','0','2018-05-01 00:00:00','2018-05-31 00:00:00','2018-05-04 09:25:45');
INSERT INTO `glpi_reminders` VALUES ('3','2018-05-15 12:21:29','13','Recordatorio de pruebas','&lt;p&gt;esto es una prueba de recordatorio público&lt;/p&gt;',NULL,NULL,'0','2018-05-15 12:21:29','0',NULL,NULL,'2018-05-15 12:21:29');

### Dump table glpi_reminders_users

DROP TABLE IF EXISTS `glpi_reminders_users`;
CREATE TABLE `glpi_reminders_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_requesttypes

DROP TABLE IF EXISTS `glpi_requesttypes`;
CREATE TABLE `glpi_requesttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_helpdesk_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_followup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mail_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mailfollowup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketheader` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketfollowup` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_helpdesk_default` (`is_helpdesk_default`),
  KEY `is_followup_default` (`is_followup_default`),
  KEY `is_mail_default` (`is_mail_default`),
  KEY `is_mailfollowup_default` (`is_mailfollowup_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `is_active` (`is_active`),
  KEY `is_ticketheader` (`is_ticketheader`),
  KEY `is_ticketfollowup` (`is_ticketfollowup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_requesttypes` VALUES ('1','Helpdesk','1','1','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('2','E-Mail','0','0','1','1','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('3','Phone','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('4','Direct','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('5','Written','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('6','Other','0','0','0','0','1','1','1',NULL,NULL,NULL);

### Dump table glpi_reservationitems

DROP TABLE IF EXISTS `glpi_reservationitems`;
CREATE TABLE `glpi_reservationitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reservations

DROP TABLE IF EXISTS `glpi_reservations`;
CREATE TABLE `glpi_reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservationitems_id` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `group` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `reservationitems_id` (`reservationitems_id`),
  KEY `users_id` (`users_id`),
  KEY `resagroup` (`reservationitems_id`,`group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds

DROP TABLE IF EXISTS `glpi_rssfeeds`;
CREATE TABLE `glpi_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `url` text COLLATE utf8_unicode_ci,
  `refresh_rate` int(11) NOT NULL DEFAULT '86400',
  `max_items` int(11) NOT NULL DEFAULT '20',
  `have_error` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `users_id` (`users_id`),
  KEY `date_mod` (`date_mod`),
  KEY `have_error` (`have_error`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds_users

DROP TABLE IF EXISTS `glpi_rssfeeds_users`;
CREATE TABLE `glpi_rssfeeds_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ruleactions

DROP TABLE IF EXISTS `glpi_ruleactions`;
CREATE TABLE `glpi_ruleactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'VALUE IN (assign, regex_result, append_regex_result, affectbyip, affectbyfqdn, affectbymac)',
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `field_value` (`field`(50),`value`(50))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ruleactions` VALUES ('6','6','fromitem','locations_id','1');
INSERT INTO `glpi_ruleactions` VALUES ('2','2','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('3','3','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('4','4','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('5','5','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('7','7','fromuser','locations_id','1');
INSERT INTO `glpi_ruleactions` VALUES ('8','8','assign','_import_category','1');

### Dump table glpi_rulecriterias

DROP TABLE IF EXISTS `glpi_rulecriterias`;
CREATE TABLE `glpi_rulecriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `condition` (`condition`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulecriterias` VALUES ('9','6','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('2','2','uid','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('3','2','samaccountname','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('4','2','MAIL_EMAIL','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('5','3','subject','6','/.*/');
INSERT INTO `glpi_rulecriterias` VALUES ('6','4','x-auto-response-suppress','6','/\\S+/');
INSERT INTO `glpi_rulecriterias` VALUES ('7','5','auto-submitted','6','/^(?!.*no).+$/i');
INSERT INTO `glpi_rulecriterias` VALUES ('10','6','items_locations','8','1');
INSERT INTO `glpi_rulecriterias` VALUES ('11','7','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('12','7','users_locations','8','1');
INSERT INTO `glpi_rulecriterias` VALUES ('13','8','name','0','*');

### Dump table glpi_rulerightparameters

DROP TABLE IF EXISTS `glpi_rulerightparameters`;
CREATE TABLE `glpi_rulerightparameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulerightparameters` VALUES ('1','(LDAP)Organization','o','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('2','(LDAP)Common Name','cn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('3','(LDAP)Department Number','departmentnumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('4','(LDAP)Email','mail','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('5','Object Class','objectclass','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('6','(LDAP)User ID','uid','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('7','(LDAP)Telephone Number','phone','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('8','(LDAP)Employee Number','employeenumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('9','(LDAP)Manager','manager','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('10','(LDAP)DistinguishedName','dn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('12','(AD)User ID','samaccountname','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('13','(LDAP) Title','title','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('14','(LDAP) MemberOf','memberof','',NULL,NULL);

### Dump table glpi_rules

DROP TABLE IF EXISTS `glpi_rules`;
CREATE TABLE `glpi_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `sub_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ranking` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `sub_type` (`sub_type`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `condition` (`condition`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rules` VALUES ('2','0','RuleRight','1','Root','','OR','1',NULL,NULL,'0','500717c8-2bd6e957-53a12b5fd35745.02608131','0',NULL);
INSERT INTO `glpi_rules` VALUES ('3','0','RuleMailCollector','3','Root','','OR','1',NULL,NULL,'0','500717c8-2bd6e957-53a12b5fd36404.54713349','0',NULL);
INSERT INTO `glpi_rules` VALUES ('4','0','RuleMailCollector','1','X-Auto-Response-Suppress','Exclude Auto-Reply emails using X-Auto-Response-Suppress header','AND','0',NULL,'2011-01-18 11:40:42','1','500717c8-2bd6e957-53a12b5fd36d97.94503423','0',NULL);
INSERT INTO `glpi_rules` VALUES ('5','0','RuleMailCollector','2','Auto-Reply Auto-Submitted','Exclude Auto-Reply emails using Auto-Submitted header','OR','1',NULL,'2011-01-18 11:40:42','1','500717c8-2bd6e957-53a12b5fd376c2.87642651','0',NULL);
INSERT INTO `glpi_rules` VALUES ('6','0','RuleTicket','1','Ticket location from item','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd37f94.10365341','1',NULL);
INSERT INTO `glpi_rules` VALUES ('7','0','RuleTicket','2','Ticket location from user','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd38869.86002585','1',NULL);
INSERT INTO `glpi_rules` VALUES ('8','0','RuleSoftwareCategory','1','Import category from inventory tool','','AND','0','Automatically generated by GLPI 9.2',NULL,'1','500717c8-2bd6e957-53a12b5fd38869.86003425','1',NULL);

### Dump table glpi_savedsearches

DROP TABLE IF EXISTS `glpi_savedsearches`;
CREATE TABLE `glpi_savedsearches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see SavedSearch:: constants',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8_unicode_ci,
  `last_execution_time` int(11) DEFAULT NULL,
  `do_count` tinyint(1) NOT NULL DEFAULT '2' COMMENT 'Do or do not count results on list display see SavedSearch::COUNT_* constants',
  `last_execution_date` datetime DEFAULT NULL,
  `counter` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `is_private` (`is_private`),
  KEY `is_recursive` (`is_recursive`),
  KEY `last_execution_time` (`last_execution_time`),
  KEY `last_execution_date` (`last_execution_date`),
  KEY `do_count` (`do_count`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_savedsearches` VALUES ('1','','1','Supplier','10','1','0','1','front/supplier.php','',NULL,'2',NULL,'0');

### Dump table glpi_savedsearches_alerts

DROP TABLE IF EXISTS `glpi_savedsearches_alerts`;
CREATE TABLE `glpi_savedsearches_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `savedsearches_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `operator` tinyint(1) NOT NULL,
  `value` int(11) NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`savedsearches_id`,`operator`,`value`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_savedsearches_users

DROP TABLE IF EXISTS `glpi_savedsearches_users`;
CREATE TABLE `glpi_savedsearches_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `savedsearches_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`),
  KEY `savedsearches_id` (`savedsearches_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevelactions

DROP TABLE IF EXISTS `glpi_slalevelactions`;
CREATE TABLE `glpi_slalevelactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevelcriterias

DROP TABLE IF EXISTS `glpi_slalevelcriterias`;
CREATE TABLE `glpi_slalevelcriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`),
  KEY `condition` (`condition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevels

DROP TABLE IF EXISTS `glpi_slalevels`;
CREATE TABLE `glpi_slalevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slas_id` int(11) NOT NULL DEFAULT '0',
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `slas_id` (`slas_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevels_tickets

DROP TABLE IF EXISTS `glpi_slalevels_tickets`;
CREATE TABLE `glpi_slalevels_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`slalevels_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `slalevels_id` (`slalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slas

DROP TABLE IF EXISTS `glpi_slas`;
CREATE TABLE `glpi_slas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `number_time` int(11) NOT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `definition_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_of_working_day` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `slms_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `calendars_id` (`calendars_id`),
  KEY `slms_id` (`slms_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slms

DROP TABLE IF EXISTS `glpi_slms`;
CREATE TABLE `glpi_slms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `calendars_id` (`calendars_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwarecategories

DROP TABLE IF EXISTS `glpi_softwarecategories`;
CREATE TABLE `glpi_softwarecategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `softwarecategories_id` (`softwarecategories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarecategories` VALUES ('1','FUSION',NULL,'0','FUSION','1',NULL,NULL);

### Dump table glpi_softwarelicenses

DROP TABLE IF EXISTS `glpi_softwarelicenses`;
CREATE TABLE `glpi_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `softwarelicenses_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `softwarelicensetypes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `softwareversions_id_buy` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id_use` int(11) NOT NULL DEFAULT '0',
  `expire` date DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `expire` (`expire`),
  KEY `softwareversions_id_buy` (`softwareversions_id_buy`),
  KEY `entities_id` (`entities_id`),
  KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`),
  KEY `softwareversions_id_use` (`softwareversions_id_use`),
  KEY `date_mod` (`date_mod`),
  KEY `softwares_id_expire` (`softwares_id`,`expire`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `users_id` (`users_id`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_creation` (`date_creation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwarelicensetypes

DROP TABLE IF EXISTS `glpi_softwarelicensetypes`;
CREATE TABLE `glpi_softwarelicensetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `softwarelicensetypes_id` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarelicensetypes` VALUES ('1','OEM','',NULL,NULL,'0','0',NULL,NULL,'0','1','OEM');

### Dump table glpi_softwares

DROP TABLE IF EXISTS `glpi_softwares`;
CREATE TABLE `glpi_softwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_update` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '1',
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_update` (`is_update`),
  KEY `softwarecategories_id` (`softwarecategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `softwares_id` (`softwares_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwareversions

DROP TABLE IF EXISTS `glpi_softwareversions`;
CREATE TABLE `glpi_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `softwares_id` (`softwares_id`),
  KEY `states_id` (`states_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_solutiontemplates

DROP TABLE IF EXISTS `glpi_solutiontemplates`;
CREATE TABLE `glpi_solutiontemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_solutiontypes

DROP TABLE IF EXISTS `glpi_solutiontypes`;
CREATE TABLE `glpi_solutiontypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ssovariables

DROP TABLE IF EXISTS `glpi_ssovariables`;
CREATE TABLE `glpi_ssovariables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ssovariables` VALUES ('1','HTTP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('2','REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('3','PHP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('4','USERNAME','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('5','REDIRECT_REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('6','HTTP_REMOTE_USER','',NULL,NULL);

### Dump table glpi_states

DROP TABLE IF EXISTS `glpi_states`;
CREATE TABLE `glpi_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_visible_computer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_monitor` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_networkequipment` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_peripheral` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_phone` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_printer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwareversion` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwarelicense` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_line` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_certificate` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`states_id`,`name`),
  KEY `name` (`name`),
  KEY `is_visible_computer` (`is_visible_computer`),
  KEY `is_visible_monitor` (`is_visible_monitor`),
  KEY `is_visible_networkequipment` (`is_visible_networkequipment`),
  KEY `is_visible_peripheral` (`is_visible_peripheral`),
  KEY `is_visible_phone` (`is_visible_phone`),
  KEY `is_visible_printer` (`is_visible_printer`),
  KEY `is_visible_softwareversion` (`is_visible_softwareversion`),
  KEY `is_visible_softwarelicense` (`is_visible_softwarelicense`),
  KEY `is_visible_line` (`is_visible_line`),
  KEY `is_visible_certificate` (`is_visible_certificate`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_states` VALUES ('1','Alta','0','0','','0','Alta','1','[]',NULL,'1','1','1','1','1','1','1','1','1','1','2018-04-12 12:59:03','2018-04-12 12:59:03');

### Dump table glpi_suppliers

DROP TABLE IF EXISTS `glpi_suppliers`;
CREATE TABLE `glpi_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliertypes_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `cv_id` int(11) DEFAULT NULL,
  `cif` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `forma_juridica` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `suppliertypes_id` (`suppliertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_suppliers` VALUES ('2','0','0','Construcciones Lopez','0','sdfg','fgntrybu','ghjkllj','jfgkghjkl','ul','sdfg','dsfg','ulyhuo,lg','0','sdfg','fgdsfg','2018-04-26 08:40:10','2018-04-20 14:37:22','4','sdfgsd','sdfg','0');
INSERT INTO `glpi_suppliers` VALUES ('3','0','0','ACCIONA CONSTRUCCIÓN, S.A.','1','AVENIDA DE EUROPA DE EUROPA, 18, PARQUE EMPRESARIAL LA MORALEJA - ALCOBENDAS','28108','Alcobendas','MADRID','ESPAÑA','','916632850','','0','','','2018-05-04 08:37:33','2018-04-30 13:53:04','5',NULL,NULL,'0');

### Dump table glpi_suppliers_tickets

DROP TABLE IF EXISTS `glpi_suppliers_tickets`;
CREATE TABLE `glpi_suppliers_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliertypes

DROP TABLE IF EXISTS `glpi_suppliertypes`;
CREATE TABLE `glpi_suppliertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_suppliertypes` VALUES ('1','SOCIEDAD ANÓNIMA - SA','','2018-04-30 13:52:34','2018-04-30 13:52:34');
INSERT INTO `glpi_suppliertypes` VALUES ('2','SOCIEDAD LIMITADA - SL','','2018-04-30 13:52:42','2018-04-30 13:52:42');
INSERT INTO `glpi_suppliertypes` VALUES ('3','SOCIEDAD LIMITADA UNIPERSONAL - SLU','','2018-04-30 13:52:56','2018-04-30 13:52:56');

### Dump table glpi_taskcategories

DROP TABLE IF EXISTS `glpi_taskcategories`;
CREATE TABLE `glpi_taskcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tasktemplates

DROP TABLE IF EXISTS `glpi_tasktemplates`;
CREATE TABLE `glpi_tasktemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `is_private` (`is_private`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketcosts

DROP TABLE IF EXISTS `glpi_ticketcosts`;
CREATE TABLE `glpi_ticketcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `tickets_id` (`tickets_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketfollowups

DROP TABLE IF EXISTS `glpi_ticketfollowups`;
CREATE TABLE `glpi_ticketfollowups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `requesttypes_id` (`requesttypes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketrecurrents

DROP TABLE IF EXISTS `glpi_ticketrecurrents`;
CREATE TABLE `glpi_ticketrecurrents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` datetime DEFAULT NULL,
  `periodicity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_before` int(11) NOT NULL DEFAULT '0',
  `next_creation_date` datetime DEFAULT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `tickettemplates_id` (`tickettemplates_id`),
  KEY `next_creation_date` (`next_creation_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets

DROP TABLE IF EXISTS `glpi_tickets`;
CREATE TABLE `glpi_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `slas_ttr_id` int(11) NOT NULL DEFAULT '0',
  `slas_tto_id` int(11) NOT NULL DEFAULT '0',
  `ttr_slalevels_id` int(11) NOT NULL DEFAULT '0',
  `time_to_resolve` datetime DEFAULT NULL,
  `time_to_own` datetime DEFAULT NULL,
  `begin_waiting_date` datetime DEFAULT NULL,
  `sla_waiting_duration` int(11) NOT NULL DEFAULT '0',
  `ola_waiting_duration` int(11) NOT NULL DEFAULT '0',
  `olas_tto_id` int(11) NOT NULL DEFAULT '0',
  `olas_ttr_id` int(11) NOT NULL DEFAULT '0',
  `ttr_olalevels_id` int(11) NOT NULL DEFAULT '0',
  `internal_time_to_resolve` datetime DEFAULT NULL,
  `internal_time_to_own` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `takeintoaccount_delay_stat` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `request_type` (`requesttypes_id`),
  KEY `date_mod` (`date_mod`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `global_validation` (`global_validation`),
  KEY `slas_tto_id` (`slas_tto_id`),
  KEY `slas_ttr_id` (`slas_ttr_id`),
  KEY `time_to_resolve` (`time_to_resolve`),
  KEY `time_to_own` (`time_to_own`),
  KEY `olas_tto_id` (`olas_tto_id`),
  KEY `olas_ttr_id` (`olas_ttr_id`),
  KEY `ttr_slalevels_id` (`ttr_slalevels_id`),
  KEY `internal_time_to_resolve` (`internal_time_to_resolve`),
  KEY `internal_time_to_own` (`internal_time_to_own`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `type` (`type`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `name` (`name`),
  KEY `locations_id` (`locations_id`),
  KEY `date_creation` (`date_creation`),
  KEY `ola_waiting_duration` (`ola_waiting_duration`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets_tickets

DROP TABLE IF EXISTS `glpi_tickets_tickets`;
CREATE TABLE `glpi_tickets_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id_1` int(11) NOT NULL DEFAULT '0',
  `tickets_id_2` int(11) NOT NULL DEFAULT '0',
  `link` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id_1`,`tickets_id_2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets_users

DROP TABLE IF EXISTS `glpi_tickets_users`;
CREATE TABLE `glpi_tickets_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '1',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketsatisfactions

DROP TABLE IF EXISTS `glpi_ticketsatisfactions`;
CREATE TABLE `glpi_ticketsatisfactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `date_begin` datetime DEFAULT NULL,
  `date_answered` datetime DEFAULT NULL,
  `satisfaction` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettasks

DROP TABLE IF EXISTS `glpi_tickettasks`;
CREATE TABLE `glpi_tickettasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_editor` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `tasktemplates_id` int(11) NOT NULL DEFAULT '0',
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `users_id` (`users_id`),
  KEY `users_id_editor` (`users_id_editor`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `state` (`state`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `tasktemplates_id` (`tasktemplates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplatehiddenfields

DROP TABLE IF EXISTS `glpi_tickettemplatehiddenfields`;
CREATE TABLE `glpi_tickettemplatehiddenfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplatemandatoryfields

DROP TABLE IF EXISTS `glpi_tickettemplatemandatoryfields`;
CREATE TABLE `glpi_tickettemplatemandatoryfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplatemandatoryfields` VALUES ('1','1','21');

### Dump table glpi_tickettemplatepredefinedfields

DROP TABLE IF EXISTS `glpi_tickettemplatepredefinedfields`;
CREATE TABLE `glpi_tickettemplatepredefinedfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `tickettemplates_id_id_num` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplates

DROP TABLE IF EXISTS `glpi_tickettemplates`;
CREATE TABLE `glpi_tickettemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplates` VALUES ('1','Default','0','1',NULL);

### Dump table glpi_ticketvalidations

DROP TABLE IF EXISTS `glpi_ticketvalidations`;
CREATE TABLE `glpi_ticketvalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  `timeline_position` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `tickets_id` (`tickets_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_transfers

DROP TABLE IF EXISTS `glpi_transfers`;
CREATE TABLE `glpi_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keep_ticket` int(11) NOT NULL DEFAULT '0',
  `keep_networklink` int(11) NOT NULL DEFAULT '0',
  `keep_reservation` int(11) NOT NULL DEFAULT '0',
  `keep_history` int(11) NOT NULL DEFAULT '0',
  `keep_device` int(11) NOT NULL DEFAULT '0',
  `keep_infocom` int(11) NOT NULL DEFAULT '0',
  `keep_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `clean_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `keep_dc_phone` int(11) NOT NULL DEFAULT '0',
  `clean_dc_phone` int(11) NOT NULL DEFAULT '0',
  `keep_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `clean_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `keep_dc_printer` int(11) NOT NULL DEFAULT '0',
  `clean_dc_printer` int(11) NOT NULL DEFAULT '0',
  `keep_supplier` int(11) NOT NULL DEFAULT '0',
  `clean_supplier` int(11) NOT NULL DEFAULT '0',
  `keep_contact` int(11) NOT NULL DEFAULT '0',
  `clean_contact` int(11) NOT NULL DEFAULT '0',
  `keep_contract` int(11) NOT NULL DEFAULT '0',
  `clean_contract` int(11) NOT NULL DEFAULT '0',
  `keep_software` int(11) NOT NULL DEFAULT '0',
  `clean_software` int(11) NOT NULL DEFAULT '0',
  `keep_document` int(11) NOT NULL DEFAULT '0',
  `clean_document` int(11) NOT NULL DEFAULT '0',
  `keep_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `clean_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `keep_cartridge` int(11) NOT NULL DEFAULT '0',
  `keep_consumable` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `keep_disk` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_transfers` VALUES ('1','complete','2','2','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1',NULL,NULL,'1');

### Dump table glpi_usercategories

DROP TABLE IF EXISTS `glpi_usercategories`;
CREATE TABLE `glpi_usercategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_useremails

DROP TABLE IF EXISTS `glpi_useremails`;
CREATE TABLE `glpi_useremails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`email`),
  KEY `email` (`email`),
  KEY `is_default` (`is_default`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_useremails` VALUES ('1','18','1','0','luis.castilla.camara@acciona.com');
INSERT INTO `glpi_useremails` VALUES ('2','19','1','0','alberto.rey.quintana@acciona.com');
INSERT INTO `glpi_useremails` VALUES ('3','20','1','0','cesaralberto.orozco.reguero@acciona.com');

### Dump table glpi_users

DROP TABLE IF EXISTS `glpi_users`;
CREATE TABLE `glpi_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `language` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php CFG_GLPI[language] array',
  `use_mode` int(11) NOT NULL DEFAULT '0',
  `list_limit` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `auths_id` int(11) NOT NULL DEFAULT '0',
  `authtype` int(11) NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_sync` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `usercategories_id` int(11) NOT NULL DEFAULT '0',
  `date_format` int(11) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `names_format` int(11) DEFAULT NULL,
  `csv_delimiter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_ids_visible` tinyint(1) DEFAULT NULL,
  `use_flat_dropdowntree` tinyint(1) DEFAULT NULL,
  `show_jobs_at_login` tinyint(1) DEFAULT NULL,
  `priority_1` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_2` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_3` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_4` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_5` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_6` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `followup_private` tinyint(1) DEFAULT NULL,
  `task_private` tinyint(1) DEFAULT NULL,
  `default_requesttypes_id` int(11) DEFAULT NULL,
  `password_forget_token` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_forget_token_date` datetime DEFAULT NULL,
  `user_dn` text COLLATE utf8_unicode_ci,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_count_on_tabs` tinyint(1) DEFAULT NULL,
  `refresh_ticket_list` int(11) DEFAULT NULL,
  `set_default_tech` tinyint(1) DEFAULT NULL,
  `personal_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal_token_date` datetime DEFAULT NULL,
  `api_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `api_token_date` datetime DEFAULT NULL,
  `display_count_on_home` int(11) DEFAULT NULL,
  `notification_to_myself` tinyint(1) DEFAULT NULL,
  `duedateok_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_less` int(11) DEFAULT NULL,
  `duedatecritical_less` int(11) DEFAULT NULL,
  `duedatewarning_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_options` text COLLATE utf8_unicode_ci,
  `is_deleted_ldap` tinyint(1) NOT NULL DEFAULT '0',
  `pdffont` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `keep_devices_when_purging_item` tinyint(1) DEFAULT NULL,
  `privatebookmarkorder` longtext COLLATE utf8_unicode_ci,
  `backcreated` tinyint(1) DEFAULT NULL,
  `task_state` int(11) DEFAULT NULL,
  `layout` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `palette` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_timeline` tinyint(1) DEFAULT NULL,
  `ticket_timeline_keep_replaced_tabs` tinyint(1) DEFAULT NULL,
  `set_default_requester` tinyint(1) DEFAULT NULL,
  `lock_autolock_mode` tinyint(1) DEFAULT NULL,
  `lock_directunlock_notification` tinyint(1) DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `highcontrast_css` tinyint(1) DEFAULT '0',
  `plannings` text COLLATE utf8_unicode_ci,
  `sync_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `supplier_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`name`),
  KEY `firstname` (`firstname`),
  KEY `realname` (`realname`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `locations_id` (`locations_id`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `usercategories_id` (`usercategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `authitem` (`authtype`,`auths_id`),
  KEY `is_deleted_ldap` (`is_deleted_ldap`),
  KEY `date_creation` (`date_creation`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `sync_field` (`sync_field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_users` VALUES ('2','glpi','$2y$10$mSUeHItjOf3C07alVMXeAOCNUBiZkhX236./L0D.rBui98p7DuRMa','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2018-05-21 08:17:49','2018-05-11 08:23:11',NULL,'0','4','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,'YG5Hi1XAyAmxQWJVA7rGpt7HDHcGjrkZxTIEJeKI','2018-03-22 11:44:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0');
INSERT INTO `glpi_users` VALUES ('3','post-only','$2y$10$fPS4Nv0I0oYKADHE.EB6xevyeBZf/rDXJy38EttZUx4X84amQAUqy','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','0',NULL,'2018-05-11 08:23:36',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','',NULL,'0');
INSERT INTO `glpi_users` VALUES ('4','tech','$2y$10$7V1V/sQwfbrk9m/5vbta6u2DVbduKbNIdmW54C0n4xFUnuPjIHd6y','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','0',NULL,'2018-05-11 08:24:01',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','',NULL,'0');
INSERT INTO `glpi_users` VALUES ('5','normal','$2y$10$ZF5rz1bfhwzEOjxNfMlldeetzW68l8uxuMbrilehVopF7wO24MbVe','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','0',NULL,'2018-04-23 12:57:54',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','',NULL,'0');
INSERT INTO `glpi_users` VALUES ('6','usuario_proveedor1','$2y$10$J9K9VXXVrm1M08SGKN2PVeplxF6cP3Adl.GXYI3wCB135WCcPKPTe','','','','proveedor uno','pepe','0',NULL,'0',NULL,'1','','0','1','2018-04-23 11:38:43','2018-04-23 11:38:31',NULL,'0','9','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'BH0JvysAHUXZWFsSh9OWzfw7AZMdfBqh9FEZuUoK','2018-04-10 11:42:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-10 11:39:51',NULL,NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('7','prov','$2y$10$NuvVaKhMIxMCDJYfMYiidu0TUhmrMRaiGaYY2Z1rsSiYm4LrItNwa','','','','sánchez sánchez','juan','0',NULL,'0',NULL,'1','','0','1','2018-05-02 08:36:33','2018-04-30 12:36:59',NULL,'0','9','0','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'Lif6GXOyix0tXhj8A4elgINNaQYxr95qajk1eTm8','2018-04-13 09:06:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-13 09:05:56',NULL,NULL,NULL,'2');
INSERT INTO `glpi_users` VALUES ('8','tec','$2y$10$XPbmUhhkw0c53Ork86bvPO2tqu2lx9rolW3qEYBF0lBmT.R5q8/PC','','','','','','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-04-17 08:24:44',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-17 08:24:44','0',NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('9','prov 2','$2y$10$Vi6gsTj/iyKkqjHDfRstZuIFusdTX/5tZekZDSoELBHkdnQx9ydhW','','','','Ortega','Luis','0',NULL,'0',NULL,'1','','0','1','2018-04-26 08:29:49','2018-04-23 12:55:53',NULL,'0','9','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'MvaEciJIhMH5JBGc8npJMrtQrIvSpwV8WCZUSyV4','2018-04-19 08:24:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-19 08:18:25',NULL,NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('10','tec1','$2y$10$dAimrw0YdxteE3XYiGE7Q.b4ps7/mdtNji8GkH/7V19G/qvJKxWdm','','','','Pérez Sánchez','Daniel','0',NULL,'0',NULL,'1','','0','1','2018-04-30 12:09:59','2018-04-26 13:01:24',NULL,'0','12','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'gGhsKblgvrES0HlP7Gxq3cbBht0mD40lLByCwQop','2018-04-20 14:23:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-20 14:22:18',NULL,NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('11','prov 5','$2y$10$cFr4klYsIA4slxysKIjSGu9FDfGPXWz87Qq28SMsbDvKSz88EVllu','','','','Alcazar','Fernando','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-04-23 11:30:28',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-23 11:30:28','0',NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('12','prov 6',NULL,'','','','Perez','Oscar','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-04-23 12:11:05',NULL,'0','9','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-23 12:10:37','0',NULL,NULL,'2');
INSERT INTO `glpi_users` VALUES ('13','usuestrategico1','$2y$10$mfKMyXYywlgnQcyZ6tayXOTPdQjpyCQ7FSpuNCYaDBvH3xEdc6R2a','','','','','','0',NULL,'0',NULL,'1','','0','1','2018-05-21 07:44:21','2018-05-11 11:43:29',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'QaH8NN0azHGiMxJ9nnfbTc1RGmPN6TjqnTHzStT9','2018-05-11 11:43:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-27 10:09:35',NULL,NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('14','usufinanciero1','$2y$10$QqM/nJvGAv7Fm8UpoHh8Nu.j8pdMPfWRujVJM7HkUN8Gjxgk2VAka','','','','','','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-04-27 10:09:55',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-27 10:09:55','0',NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('15','usugeneral1','$2y$10$RelxA.CQCXopfFCTyKfILOIF6QOT2JxYOh3CCFm2DEGd/qK7hTF/O','','','','','','0',NULL,'0',NULL,'1','','0','1','2018-04-27 10:24:09','2018-04-27 10:24:09',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'C15dPu7te3IErOxZ6R16hJ2eNmMBabyBZ3U4ImAO','2018-04-27 10:24:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-27 10:10:18',NULL,NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('16','usuproveedor1','$2y$10$din7TBy.UVwNTVCvPx7u6.mACujulvsr2hPj6zu/J.mcnvI86rXl2','','','','','','0',NULL,'0',NULL,'1','','0','1','2018-04-27 10:26:31','2018-04-27 10:26:31',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'dhMCBZ0XVYoiFX8mKoRfOZCHUPSBtW9s6YM287pj','2018-04-27 10:26:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-27 10:10:38',NULL,NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('17','usuproyecto1','$2y$10$4qlgJs9QUvY5kdGPv54EZ.ZawrhB0Xmbp30ZfWOog9wW3i7N5sLj.','','','','','','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-04-27 10:12:02',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-27 10:12:02','0',NULL,NULL,'0');
INSERT INTO `glpi_users` VALUES ('18','luis.castilla.camara@acciona.com','$2y$10$3YCwH44/IBAQKNKLAqH4PeGUFIPZ4smYCk/YcytoRjtZ61389Rx4u','916632850','','','Castilla Cámara','Luís','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-05-03 13:26:26',NULL,'0','0','0','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'2018-04-30 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-30 14:08:23','0',NULL,NULL,'3');
INSERT INTO `glpi_users` VALUES ('19','alberto.rey.quintana@acciona.com','$2y$10$UsIs2hNWuBIqXO9GdctSJ.WrK4sqhJzIIhOiuJXETbN4PMii2XkxO','916632850','','600514226','Rey Quintana','Alberto','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-05-03 13:32:40',NULL,'0','9','0','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'2018-04-30 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-04-30 14:12:15','0',NULL,NULL,'3');
INSERT INTO `glpi_users` VALUES ('20','cesaralberto.orozco.reguero@acciona.com','$2y$10$Q0tSpHdo9r5rvqnrb2QqmeGXu5TQvxn.5nNbWRtG.HMMO2tRQuy66','914059531','','600514015','Orozco Rozpide','César Álberto','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-05-03 13:32:53',NULL,'0','9','0','5','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-05-03 13:31:58','0',NULL,NULL,'3');

### Dump table glpi_usertitles

DROP TABLE IF EXISTS `glpi_usertitles`;
CREATE TABLE `glpi_usertitles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_usertitles` VALUES ('1','Director Geneal','','2018-04-19 08:16:17','2018-04-19 08:16:17');
INSERT INTO `glpi_usertitles` VALUES ('2','Representante','','2018-04-19 08:18:00','2018-04-19 08:18:00');
INSERT INTO `glpi_usertitles` VALUES ('3','Dpto. Estudios','','2018-04-30 14:09:47','2018-04-30 14:09:47');
INSERT INTO `glpi_usertitles` VALUES ('4','Dpto. Técnico','','2018-04-30 14:09:54','2018-04-30 14:09:54');
INSERT INTO `glpi_usertitles` VALUES ('5','Dpto. Comercial','','2018-04-30 14:10:01','2018-04-30 14:10:01');
INSERT INTO `glpi_usertitles` VALUES ('6','Representante','','2018-04-30 14:10:24','2018-04-30 14:10:24');

### Dump table glpi_virtualmachinestates

DROP TABLE IF EXISTS `glpi_virtualmachinestates`;
CREATE TABLE `glpi_virtualmachinestates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinesystems

DROP TABLE IF EXISTS `glpi_virtualmachinesystems`;
CREATE TABLE `glpi_virtualmachinesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinetypes

DROP TABLE IF EXISTS `glpi_virtualmachinetypes`;
CREATE TABLE `glpi_virtualmachinetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_vlans

DROP TABLE IF EXISTS `glpi_vlans`;
CREATE TABLE `glpi_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `tag` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tag` (`tag`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_wifinetworks

DROP TABLE IF EXISTS `glpi_wifinetworks`;
CREATE TABLE `glpi_wifinetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `essid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, access_point',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `essid` (`essid`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

